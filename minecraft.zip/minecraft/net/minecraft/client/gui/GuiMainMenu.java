package net.minecraft.client.gui;

import java.awt.Font;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import me.Quh.Doragon.GUI.GuiButtonDark;
import org.apache.commons.io.Charsets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GLContext;

import com.google.common.collect.Lists;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Particle.ParticleGenerator;
import me.Quh.Doragon.TTF.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.I18n;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.demo.DemoWorldServer;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;

public class GuiMainMenu extends GuiScreen implements GuiYesNoCallback {

    private static final AtomicInteger field_175373_f = new AtomicInteger(0);
    private static final Logger logger = LogManager.getLogger();
    private static final Random field_175374_h = new Random();

    /**
     * Counts the number of screen updates.
     */
    private float updateCounter;

    /**
     * The splash message.
     */
    private String splashText;
    private GuiButton buttonResetDemo;

    /**
     * Timer used to rotate the panorama, increases every tick.
     */
    private int panoramaTimer;

    /**
     * Texture allocated for the current viewport of the main menu's panorama
     * background.
     */
    private DynamicTexture viewportTexture;
    private boolean field_175375_v = true;
    private final Object field_104025_t = new Object();
    private String field_92025_p;
    private String field_146972_A;
    private String field_104024_v;
    private static final ResourceLocation splashTexts = new ResourceLocation("texts/splashes.txt");
    private static final ResourceLocation minecraftTitleTextures = new ResourceLocation("textures/gui/title/minecraft.png");

    /**
     * An array of all the paths to the panorama pictures.
     */
    private static final ResourceLocation[] titlePanoramaPaths = new ResourceLocation[]{new ResourceLocation("textures/gui/title/background/panorama_0.png"), new ResourceLocation("textures/gui/title/background/panorama_1.png"), new ResourceLocation("textures/gui/title/background/panorama_2.png"), new ResourceLocation("textures/gui/title/background/panorama_3.png"), new ResourceLocation("textures/gui/title/background/panorama_4.png"), new ResourceLocation("textures/gui/title/background/panorama_5.png")};
    public static final String field_96138_a = "Please click " + EnumChatFormatting.UNDERLINE + "here" + EnumChatFormatting.RESET + " for more information.";
    private int field_92024_r;
    private int field_92023_s;
    private int field_92022_t;
    private int field_92021_u;
    private int field_92020_v;
    private int field_92019_w;
    private ResourceLocation field_110351_G;
    private GuiButtonDark field_175372_K;
    private static final String __OBFID = "CL_00001154";

    //TODO: Particle
    private ParticleGenerator particles;
    private Random random = new Random();

    //Client sachen 
    public static GuiTextField TestTextBox;
    /*
	 * Fonts
     */
    public static FontUtils WaterMarkBig = new FontUtils("QUANTIFY", Font.PLAIN, 100);
    public static FontUtils Font1 = new FontUtils("QUANTIFY", Font.PLAIN, 20);
    private static me.Quh.Doragon.TTF.FontUtils Font2 = new me.Quh.Doragon.TTF.FontUtils("Roboto", Font.PLAIN, 24);
    private static FontUtils loggedinas = new FontUtils("Comfortaa Bold", Font.BOLD, 48);

    public GuiMainMenu() {
        this.field_146972_A = field_96138_a;
        this.splashText = "missingno";
        BufferedReader var1 = null;

        try {
            ArrayList var2 = Lists.newArrayList();
            var1 = new BufferedReader(new InputStreamReader(Minecraft.getMinecraft().getResourceManager().getResource(splashTexts).getInputStream(), Charsets.UTF_8));
            String var3;

            while ((var3 = var1.readLine()) != null) {
                var3 = var3.trim();

                if (!var3.isEmpty()) {
                    var2.add(var3);
                }
            }

            if (!var2.isEmpty()) {
                do {
                    this.splashText = (String) var2.get(field_175374_h.nextInt(var2.size()));
                } while (this.splashText.hashCode() == 125780783);
            }
        } catch (IOException var12) {
            ;
        } finally {
            if (var1 != null) {
                try {
                    var1.close();
                } catch (IOException var11) {
                    ;
                }
            }
        }

        this.updateCounter = field_175374_h.nextFloat();
        this.field_92025_p = "";

        if (!GLContext.getCapabilities().OpenGL20 && !OpenGlHelper.areShadersSupported()) {
            this.field_92025_p = I18n.format("title.oldgl1", new Object[0]);
            this.field_146972_A = I18n.format("title.oldgl2", new Object[0]);
            this.field_104024_v = "https://help.mojang.com/customer/portal/articles/325948?ref=game";
        }
    }

    /**
     * Called from the main game loop to update the screen.
     */
    public void updateScreen() {
        ++this.panoramaTimer;
    }

    /**
     * Returns true if this GUI should pause the game when it is displayed in
     * single-player
     */
    public boolean doesGuiPauseGame() {
        return false;
    }

    /**
     * Fired when a key is typed (except F11 who toggle full screen). This is
     * the equivalent of KeyListener.keyTyped(KeyEvent e). Args : character
     * (character on the key), keyCode (lwjgl Keyboard key code)
     */
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
    }

    /**
     * Adds the buttons (and other controls) to the screen in question.
     */
    public void initGui() {
        this.viewportTexture = new DynamicTexture(256, 256);
        this.field_110351_G = this.mc.getTextureManager().getDynamicTextureLocation("background", this.viewportTexture);
        Calendar var1 = Calendar.getInstance();
        var1.setTime(new Date());

        if (var1.get(2) + 1 == 11 && var1.get(5) == 9) {
            this.splashText = "Happy birthday, ez!";
        } else if (var1.get(2) + 1 == 6 && var1.get(5) == 1) {
            this.splashText = "Happy birthday, Notch!";
        } else if (var1.get(2) + 1 == 12 && var1.get(5) == 24) {
            this.splashText = "Merry X-mas!";
        } else if (var1.get(2) + 1 == 1 && var1.get(5) == 1) {
            this.splashText = "Happy new year!";
        } else if (var1.get(2) + 1 == 10 && var1.get(5) == 31) {
            this.splashText = "OOoooOOOoooo! Spooky!";
        }

        boolean var2 = true;
        int var3 = this.height / 4 + 48;

        if (this.mc.isDemo()) {
            this.addDemoButtons(var3, 24);
        } else {
            this.addSingleplayerMultiplayerButtons(var3, 24);
        }

        //this.buttonList.add(new GuiButtonDark(0, this.width / 9 - 106, var3 + 60 + 12, 98, 20, I18n.format("menu.options", new Object[0])));
        //this.buttonList.add(new GuiButtonDark(4, this.width / 8 - 19, var3 + 60 + 12, 98, 20, I18n.format("menu.quit", new Object[0])));
        Object var4 = this.field_104025_t;

        synchronized (this.field_104025_t) {
            this.field_92023_s = this.fontRendererObj.getStringWidth(this.field_92025_p);
            this.field_92024_r = this.fontRendererObj.getStringWidth(this.field_146972_A);
            int var5 = Math.max(this.field_92023_s, this.field_92024_r);
            this.field_92022_t = (this.width - var5) / 2;
            this.field_92021_u = ((GuiButtonDark) this.buttonList.get(0)).yPosition - 24;
            this.field_92020_v = this.field_92022_t + var5;
            this.field_92019_w = this.field_92021_u + 24;
        }

        this.particles = new ParticleGenerator(100, this.width, this.height);
    }

    /**
     * Adds Singleplayer and Multiplayer buttons on Main Menu for players who
     * have bought the game.
     */
    private void addSingleplayerMultiplayerButtons(int p_73969_1_, int p_73969_2_) {
        this.buttonList.add(new GuiButtonDark(1, this.width / 9 - 82, p_73969_1_, I18n.format("menu.singleplayer", new Object[0])));
        this.buttonList.add(new GuiButtonDark(2, this.width / 9 - 82, p_73969_1_ + p_73969_2_ * 1, I18n.format("menu.multiplayer", new Object[0])));
        this.buttonList.add(this.field_175372_K = new GuiButtonDark(14, this.width / 9 - 82, p_73969_1_ + p_73969_2_ * 2, I18n.format("Alt Login", new Object[0])));
        this.buttonList.add(new GuiButtonDark(0, this.width / 9 - 82, p_73969_1_ + p_73969_2_ * 3, I18n.format("menu.options", new Object[0])));
        this.buttonList.add(new GuiButtonDark(4, this.width / 9 - 82, p_73969_1_ + p_73969_2_ * 4, I18n.format("menu.quit", new Object[0])));
    }

    /**
     * Adds Demo buttons on Main Menu for players who are playing Demo.
     */
    private void addDemoButtons(int p_73972_1_, int p_73972_2_) {
        this.buttonList.add(new GuiButton(11, this.width / 2 - 100, p_73972_1_, I18n.format("menu.playdemo", new Object[0])));
        this.buttonList.add(this.buttonResetDemo = new GuiButton(12, this.width / 2 - 100, p_73972_1_ + p_73972_2_ * 1, I18n.format("menu.resetdemo", new Object[0])));
        ISaveFormat var3 = this.mc.getSaveLoader();
        WorldInfo var4 = var3.getWorldInfo("Demo_World");

        if (var4 == null) {
            this.buttonResetDemo.enabled = false;
        }
    }

    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) {
            this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
        }

        if (button.id == 5) {
            this.mc.displayGuiScreen(new GuiLanguage(this, this.mc.gameSettings, this.mc.getLanguageManager()));
        }

        if (button.id == 1) {
            this.mc.displayGuiScreen(new GuiSelectWorld(this));
        }

        if (button.id == 2) {
            this.mc.displayGuiScreen(new GuiMultiplayer(this));
        }

        if (button.id == 14 && this.field_175372_K.visible) {
            mc.displayGuiScreen(new me.Quh.Doragon.GUI.AltManager.GuiAltManager());
        }

        if (button.id == 4) {
            this.mc.shutdown();
        }

        if (button.id == 11) {
            this.mc.launchIntegratedServer("Demo_World", "Demo_World", DemoWorldServer.demoWorldSettings);
        }

        if (button.id == 12) {
            ISaveFormat var2 = this.mc.getSaveLoader();
            WorldInfo var3 = var2.getWorldInfo("Demo_World");

            if (var3 != null) {
                GuiYesNo var4 = GuiSelectWorld.func_152129_a(this, var3.getWorldName(), 12);
                this.mc.displayGuiScreen(var4);
            }
        }
    }

    private void switchToRealms() {
        RealmsBridge var1 = new RealmsBridge();
        var1.switchToRealms(this);
    }

    public void confirmClicked(boolean result, int id) {
        if (result && id == 12) {
            ISaveFormat var6 = this.mc.getSaveLoader();
            var6.flushCache();
            var6.deleteWorldDirectory("Demo_World");
            this.mc.displayGuiScreen(this);
        } else if (id == 13) {
            if (result) {
                try {
                    Class var3 = Class.forName("java.awt.Desktop");
                    Object var4 = var3.getMethod("getDesktop", new Class[0]).invoke((Object) null, new Object[0]);
                    var3.getMethod("browse", new Class[]{URI.class}).invoke(var4, new Object[]{new URI(this.field_104024_v)});
                } catch (Throwable var5) {
                    logger.error("Couldn\'t open link", var5);
                }
            }

            this.mc.displayGuiScreen(this);
        }
    }

    /**
     * Draws the main menu panorama
     */
    /**
     * Draws the screen and all the components in it. Args : mouseX, mouseY,
     * renderPartialTicks
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        ScaledResolution s1 = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        this.mc.getTextureManager().bindTexture(new ResourceLocation("Doragon/MainMenu2.jpg"));
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, s1.getScaledWidth(), s1.getScaledHeight(), s1.getScaledWidth(), s1.getScaledHeight());

        drawRect(0, s1.getScaledHeight() / 10 - 60, s1.getScaledWidth() / 2 - 280, s1.getScaledHeight() + 10, -1728053248);

        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        String timeStamp1 = dateFormat.format(cal.getTime());
        String timeStamp2 = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());
        Font2.drawString(" " + timeStamp2, GuiScreen.width - Font2.getWidth(" " + timeStamp2) - 900, GuiScreen.height / 13 + 450, 0x990000);
        loggedinas.drawCenteredStringWithShadow("Youre logged in as", GuiScreen.width / 2, 0, 0x000000);
        loggedinas.drawCenteredStringWithShadow(Doragon.username, GuiScreen.width / 2, loggedinas.getHeight("Youre Logged in as"), 0x000000);
        Font2.drawString(timeStamp1, 2, GuiScreen.height / 13 - 37, 0x990000);
        WaterMarkBig.drawString("Doragon", width / 7 - 60 - (Font1.getWidth("Doragon B1") / 44 + 75), height + 0 - 475, 0x990000);


        //drawSkinHead(mc.session.getUsername(), 50, 50, 50, 50);
        //Gui.drawRect(12, 12, 0, 0, 0x40000000);
        /*for (Particle p : particles.particles) {

            for (Particle p2 : particles.particles) {

                int xx = (int) (MathHelper.cos(0.1F * (p.x + p.k)) * 10.0F);

                int xx2 = (int) (MathHelper.cos(0.1F * (p2.x + p2.k)) * 10.0F);

                boolean mouseOver = (mouseX >= p.x + xx - 95) && (mouseY >= p.y - 90) && (mouseX <= p.x)
                        && (mouseY <= p.y);

                if (mouseOver) {

                    if (mouseY >= p.y - 80 && mouseX >= p2.x - 100 && mouseY >= p2.y && mouseY <= p2.y + 70
                            && mouseX <= p2.x) {

                        int maxDistance = 100;

                        final int xDif = p.x - mouseX;

                        final int yDif = p.y - mouseY;

                        final int distance = (int) Math.sqrt(xDif * xDif + yDif + yDif);

                        final int xDif1 = p2.x - mouseX;

                        final int yDif1 = p2.y - mouseY;

                        final int distance2 = (int) Math.sqrt(xDif1 * xDif1 + yDif1 + yDif1);

                        if (distance < maxDistance && distance2 < maxDistance) {

                            GL11.glPushMatrix();

                            GL11.glEnable(GL11.GL_LINE_SMOOTH);

                            GL11.glDisable(GL11.GL_DEPTH_TEST);

                            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

                            GL11.glDisable(GL11.GL_TEXTURE_2D);

                            GL11.glDepthMask(false);

                            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

                            GL11.glEnable(GL11.GL_BLEND);

                            GL11.glLineWidth(1.5F);

                            GL11.glBegin(GL11.GL_LINES);

                            GL11.glVertex2d(p.x + xx, p.y);

                            GL11.glVertex2d(p2.x + xx2, p2.y);

                            GL11.glEnd();

                            GL11.glPopMatrix();

                            if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {

                                if (p2.x > mouseX) {

                                    p2.y -= random.nextInt(5);

                                }

                                if (p2.y < mouseY) {

                                    p2.x += random.nextInt(5);

                                }

                            }

                        }

                    }

                }

            }

        }*/

        //this.particles.drawParticles();

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    /**
     * Called when the mouse is clicked. Args : mouseX, mouseY, clickedButton
     */
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        Object var4 = this.field_104025_t;

        synchronized (this.field_104025_t) {
            if (this.field_92025_p.length() > 0 && mouseX >= this.field_92022_t && mouseX <= this.field_92020_v && mouseY >= this.field_92021_u && mouseY <= this.field_92019_w) {
                GuiConfirmOpenLink var5 = new GuiConfirmOpenLink(this, this.field_104024_v, 13, true);
                var5.disableSecurityWarning();
                this.mc.displayGuiScreen(var5);
            }
        }
    }

    /*public void drawSkinHead(String name, int x, int y, int width, int height) {
            try{
                AbstractClientPlayer.getDownloadImageSkin(AbstractClientPlayer.getLocationSkin(name), name).loadTexture(mc.getResourceManager());
                mc.getTextureManager().bindTexture(AbstractClientPlayer.getLocationSkin(name));
                Tessellator tes = Tessellator.getInstance();
                WorldRenderer worldr = tes.getWorldRenderer();
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                //Face
                double fw = 32;
                double fh = 32;
                worldr.startDrawingQuads();
                worldr.addVertexWithUV((double)x, (double)y + height, 0, (float)32 * 0.00390625F, (float)(fh + 32) * 0.00390625F);
                worldr.addVertexWithUV((double)x + width, (double)y + height, 0,(float)(32 + fw) * 0.00390625F, (float)(32 + fh) * 0.00390625F);
		worldr.addVertexWithUV((double)x + width, (double)y + 0, 0,(float)(32 + fw) * 0.00390625F, (float)(32 + 0) * 0.00390625F);
		worldr.addVertexWithUV((double)x + 0, (double)y + 0, 0,(float)(32 + 0) * 0.00390625F, (float)(32 + 0) * 0.00390625F);
                tes.draw();
                //Hat
                worldr.startDrawingQuads();
		worldr.addVertexWithUV((double)x + 0, (double)y + height, 0,(float)(160 + 0) * 0.00390625F, (float)(32 + fh) * 0.00390625F);
		worldr.addVertexWithUV((double)x + width, (double)y + height, 0,(float)(160 + fw) * 0.00390625F, (float)(32+ fh) * 0.00390625F);
		worldr.addVertexWithUV((double)x + width, (double)y + 0, 0,(float)(160 + fw) * 0.00390625F, (float)(32 + 0) * 0.00390625F);
		worldr.addVertexWithUV((double)x + 0, (double)y + 0, 0,(float)(160 + 0) * 0.00390625F, (float)(32 + 0) * 0.00390625F);
		tes.draw();
		GL11.glDisable(GL11.GL_BLEND);
            }catch(Exception e){
                e. printStackTrace();
            }
        }*/
}
