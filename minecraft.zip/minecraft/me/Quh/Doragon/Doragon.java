package me.Quh.Doragon;

import me.Quh.Doragon.GUI.AltManager.AltManager;
import me.Quh.Doragon.IRC.IRC;
import org.lwjgl.opengl.Display;
import me.Quh.Doragon.Command.CommandManager;
import me.Quh.Doragon.GUI.ClickGUI.ClickGUI;
import me.Quh.Doragon.GUI.Setting.SettingsManager;
import me.Quh.Doragon.GUI.TabGui.TabGui;
import me.Quh.Doragon.Module.ModuleManager;
import me.Quh.Doragon.Friend.FriendUtil;
import net.minecraft.client.Minecraft;

import java.io.File;

public class Doragon {

    public static String clientName = "Doragon";
    public static String clientVersion = "B0.9.9";
    public static String clientPrefix = "§7[§cDoragon§7]";
    public static ModuleManager moduleManager;
    public static SettingsManager settingsManager;
    public static ClickGUI clickGui;
    public static TabGui tabGui;
    public static CommandManager commandManager;
    public static AltManager altManager;

    public static String username = "";

    public static void startClient() {
        new IRC().instance.connect();
        settingsManager = new SettingsManager();
        Display.setTitle(clientName + " | " + clientVersion);
        moduleManager = new ModuleManager();
        tabGui = new TabGui();
        clickGui = new ClickGUI();
        commandManager = new CommandManager();
        FriendUtil.setup();
        altManager = new AltManager();
    }

}
