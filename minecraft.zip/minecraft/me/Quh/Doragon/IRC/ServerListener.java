package me.Quh.Doragon.IRC;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ServerListener implements Runnable{

    @Override
    public void run() {
        String msg;
        try {
            while((msg = new BufferedReader(new InputStreamReader(IRC.instance.client.getInputStream())).readLine()) != null){
                if(Minecraft.getMinecraft().thePlayer != null && Minecraft.getMinecraft().theWorld != null) {
                    Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new ChatComponentText(msg));
                }
            }
        }catch (Exception e){

        }
    }
}
