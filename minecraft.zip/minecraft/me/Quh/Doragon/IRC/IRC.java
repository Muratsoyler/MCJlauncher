package me.Quh.Doragon.IRC;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class IRC {

    public static IRC instance;
    public PrintWriter pw;
    public String IRC_PREFIX = "~";

    public IRC(){
        instance = this;
    }

    public Socket client;

    public void connect(){
        try {
            client = new Socket("localhost",1337);
            pw = new PrintWriter(client.getOutputStream());
            new Thread(new ServerListener()).start();
        }catch (UnknownHostException e){
            System.out.println("Unknown Host");
        }catch (IOException e){
            System.out.println("Unknown Out/InPutStream found.");
        }
    }

    public void sendMessage(String msg){
        pw.println(msg);
        pw.flush();
    }
}
