package me.Quh.Doragon.Module;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Filer.Filers.ModuleFile;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class Module {

    public static Minecraft mc = Minecraft.getMinecraft();
    public static final Category Category = null;
    public String name;
    public String suffix;
    private Category category;

    public boolean toggled;

    private int keyBind;

    public Module(String name, int keyBind, Category category) {
        this.name = name;
        this.keyBind = keyBind;
        this.category = category;
        setup();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public boolean isCategory(Category category) {
        return this.category == category;
    }

    public boolean getState() {
        return isEnabled();

    }

    public boolean isToggled() {
        return toggled;
    }

    public void setToggled(boolean toggled) {
        this.toggled = toggled;
    }


    public int getKeyBind() {
        return keyBind;
    }

    public void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
    }

    public boolean isEnabled() {
        return toggled;
    }

    public void toggle() {
        this.toggled = (!this.toggled);
        if (this.toggled) {
            onEnable();
            this.setSuffix("");
        } else {
            onDisable();
        }
        ModuleFile.saveModules();
    }

    public void onEnable() {
    }

    public void onTick() {
    }

    public void onDisable() {
    }

    public void setup() {
    }

    public void onEvent(Event event) {
    }

    public boolean isPressed() {
        if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindRight.pressed || mc.gameSettings.keyBindLeft.pressed) {
            return true;
        }
        return false;
    }

    public void message(String msg, boolean prefix) {
        mc.thePlayer.addChatMessage(new ChatComponentText(prefix ? Doragon.clientPrefix + " " + msg : msg));
    }

}
