package me.Quh.Doragon.Module;

import java.util.ArrayList;
import java.util.List;

import me.Quh.Doragon.Module.Impl.Combat.*;
import me.Quh.Doragon.Module.Impl.Configs.*;
import me.Quh.Doragon.Module.Impl.Fun.*;
import me.Quh.Doragon.Module.Impl.Gui.*;
import me.Quh.Doragon.Module.Impl.Movement.*;
import me.Quh.Doragon.Module.Impl.Player.*;
import me.Quh.Doragon.Module.Impl.Render.*;
import me.Quh.Doragon.Module.Impl.UliaESP.*;

public class ModuleManager {

    public static List<Module> modules = new ArrayList<Module>();

    public ModuleManager() {
        //TODO: Combat
        addModule(new Aura());
        addModule(new AutoArmor());
        addModule(new ChestStealer());
        addModule(new InvCleaner());
        addModule(new TestAura());
        //TODO: Configs
        addModule(new Gomme());
        addModule(new Hypixel());
        addModule(new Rewinside());
        //TODO: Fun
        addModule(new GhostHand());
        addModule(new GommeGod());
        addModule(new HighJump());
        addModule(new MidClickFriends());
        addModule(new Teleport());
        addModule(new Phase());
        addModule(new SlowMotion());
        addModule(new SuperBedBreaker());
        addModule(new Headless());
        //TODO: Gui
        addModule(new ClickGUI());
        addModule(new HUD());
        //TODO: Movement
        addModule(new Fly());
        addModule(new Jesus());
        addModule(new LongJump());
        addModule(new NoSlowDown());
        addModule(new Speed());
        addModule(new Spider());
        addModule(new Sprint());
        addModule(new Step());
        //TODO: Player
        addModule(new AutoRespawn());
        addModule(new BedFucker());
        addModule(new InventoryMove());
        addModule(new FastLadder());
        addModule(new FastUse());
        addModule(new Scaffold());
        addModule(new ScaffoldWalk());
        addModule(new SetBack());
        addModule(new SpeedMine());
        addModule(new Teams());
        addModule(new Tower());
        addModule(new Velocity());
        //TODO: Render
        addModule(new ChestESP());
        addModule(new ESP());
        addModule(new Fullbright());
        addModule(new ItemESP());
        addModule(new NameProtect());
        addModule(new Nametags());
        addModule(new NoInvisibles());
        addModule(new ProphuntESP());
        addModule(new NoBob());
        //TODO: UliaESP
        addModule(new AlmanOMeterESP());
        addModule(new BabyESP());
        addModule(new BilouESP());
        addModule(new BrennendeSpaghettiESP());
        addModule(new DummeJungeESP());
        addModule(new FidgetFingerESP());
        addModule(new GoldFidgetSpinnerESP());
        addModule(new IlluminatenHundESP());
        addModule(new LequitESP());
        addModule(new NiggaESP());
        addModule(new PasuESP());
        addModule(new PatrickESP());
        addModule(new PersilTabsESP());
        addModule(new PferdeKindESP());
        addModule(new PlanktonESP());
        addModule(new RentnerESP());
        addModule(new SpongebobNudesESP());
        addModule(new SpongebobSteinzeitESP());
        addModule(new SteveinRealLifeESP());
        addModule(new ToggoESP());
        addModule(new TrinkendeKuhESP());
        addModule(new VerwundertESP());
        addModule(new YouTubeHurensohnESP());
    }

    public void setup() {
    }

    public void addModule(Module module) {
        this.modules.add(module);

    }

    public List<Module> getModules() {
        return modules;
    }

    public static Module getModuleByName(String moduleName) {
        for (Module mod : modules) {
            if ((mod.getName().trim().equalsIgnoreCase(moduleName))
                    || (mod.toString().trim().equalsIgnoreCase(moduleName
                            .trim()))) {
                return mod;
            }
        }
        return null;
    }

    public Module getModule(Class<? extends Module> clazz) {
        for (Module m : modules) {
            if (m.getClass() == clazz) {
                return m;
            }
        }
        return null;
    }

}
