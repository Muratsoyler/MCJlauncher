package me.Quh.Doragon.Module.Impl.Render;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;

public class Fullbright extends Module {

    public Fullbright() {
        super("Fullbright", Keyboard.KEY_NONE, Category.RENDER);

    }

    public void onUpdate() {
        mc.gameSettings.gammaSetting = 100F;
    }

    public void onDisable() {
        mc.gameSettings.gammaSetting = 1F;
    }

}
