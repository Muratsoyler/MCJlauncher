package me.Quh.Doragon.Module.Impl.Render;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnRender;
import net.minecraft.entity.item.EntityItem;

public class ItemESP extends Module {

	public ItemESP() {
		super("ItemESP", Keyboard.KEY_NONE, Category.RENDER);
	}

	public void onEvent(Event e) {
		if (!this.getState())
			return;
		if (e instanceof EventOnRender) {
			for (Object o : mc.theWorld.loadedEntityList) {
				if (o instanceof EntityItem) {
					EntityItem e1 = (EntityItem) o;
//					renderFour(mc, e1);
				}
			}
		}
	}

}
