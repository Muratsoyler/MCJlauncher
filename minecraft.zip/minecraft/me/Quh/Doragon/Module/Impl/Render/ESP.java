package me.Quh.Doragon.Module.Impl.Render;

import java.awt.Color;
import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.RenderUtils;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnRender;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {

    public ESP() {
        super("ESP", Keyboard.KEY_NONE, Category.RENDER);
    }

    public void setup() {
        final ArrayList<String> mode = new ArrayList<>();
        mode.add("Box");
        mode.add("WireFrame");
        mode.add("2D");
        mode.add("OtherBox");
        mode.add("Outline");
        mode.add("Glow");
        Doragon.settingsManager.rSetting(new Setting("ESP Mode", this, "Box", mode));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnRender) {
            if (Doragon.settingsManager.getSettingByName("ESP Mode").getValString().equalsIgnoreCase("Box")) {
                this.setSuffix(" | Box");
                for (Object o : mc.theWorld.loadedEntityList) {
                    if (o instanceof EntityPlayer) {
                        if (o != mc.thePlayer) {
                            EntityPlayer e = (EntityPlayer) o;
                            passive(e);
                        }
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("ESP Mode").getValString().equalsIgnoreCase("WireFrame")) {
                setSuffix(" | WireFrame");
            }
            if (Doragon.settingsManager.getSettingByName("ESP Mode").getValString().equalsIgnoreCase("2D")) {
                setSuffix(" | 2D");
                for (Object o : mc.theWorld.loadedEntityList) {
                    if (!(o instanceof EntityPlayer)) {
                        continue;
                    }
                    final EntityPlayer player = (EntityPlayer) o;
                    if (player != mc.thePlayer && player != null) {
                        float posX = (float) ((float) player.lastTickPosX + (player.posX - player.lastTickPosX) * mc.timer.renderPartialTicks);
                        float posY = (float) ((float) player.lastTickPosY + (player.posY - player.lastTickPosY) * mc.timer.renderPartialTicks);
                        float posZ = (float) ((float) player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * mc.timer.renderPartialTicks);
                        draw2DCorner(posX - RenderManager.renderPosX, posY - RenderManager.renderPosY, posZ - RenderManager.renderPosZ, 153F, 0.0f, 0.0f, 255.0f);
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("ESP Mode").getValString().equalsIgnoreCase("OtherBox")) {
                setSuffix(" | OtherBox");
                for (Object o : mc.theWorld.loadedEntityList) {
                    if (o instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) o;
                        if (player != mc.thePlayer) {
                            double x = player.lastTickPosX + (player.posX - player.lastTickPosX) * mc.timer.renderPartialTicks - mc.renderManager.renderPosX;
                            double y = player.lastTickPosY + (player.posY - player.lastTickPosY) * mc.timer.renderPartialTicks - mc.renderManager.renderPosY;
                            double z = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * mc.timer.renderPartialTicks - mc.renderManager.renderPosZ;
                            GL11.glPushMatrix();
                            RenderHelper.disableStandardItemLighting();
                            esp(player, x, y, z);
                            RenderHelper.enableStandardItemLighting();
                            GL11.glPopMatrix();
                        }
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("ESP Mode").getValString().equalsIgnoreCase("Outline")) {
                setSuffix(" | Outline");
            }
        }
    }

    public void esp(Entity entity, double x, double y, double z) {
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDepthMask(false);
        GL11.glTranslated(x, y, z);

        GL11.glRotated(-entity.rotationYaw, 0.0, 1.0, 0.0);
        GL11.glTranslated(0.0, entity.height / 2.0F - 0.075F, 0.0);
        GL11.glScalef(entity.height / 2.0F, entity.height / 2.0F, entity.height / 2.0F);
        if (entity.isSneaking()) {
            GL11.glScalef(1.0F, 0.825F, 1.0F);
            GL11.glTranslated(0.0, -0.17749999463558197D, 0.0);
        }
        GL11.glLineWidth(0.75F);
        GL11.glColor4f(153.0F, 0F, 0.0F, 255.0F);
        GL11.glRotated(90.0, 0.0, 1.0, 0.0);
        drawLines(new AxisAlignedBB(-entity.width + 0.22D, -(entity.height / 2.0F), -entity.width + 0.22D, entity.width - 0.22D, entity.height / 2.0F + 0.3D, entity.width - 0.22D));
        GL11.glRotated(90.0, 0.0, 1.0, 0.0);
        drawOutlinedBoundingBox(new AxisAlignedBB(-entity.width + 0.22D, -(entity.height / 2.0F), -entity.width + 0.22D, entity.width - 0.22D, entity.height / 2.0F + 0.3D, entity.width - 0.22D));

        GL11.glDepthMask(true);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LIGHTING);
    }

    public void drawOutlinedBoundingBox(AxisAlignedBB boundingBox) {
        Tessellator var2 = Tessellator.getInstance();
        WorldRenderer var3 = var2.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_CURRENT_BIT, GL11.GL_POINTS);
        GlStateManager.func_179090_x();
        GlStateManager.depthMask(false);
        var3.startDrawing(3);
        var3.addVertex(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.minY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.minY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.minY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
        var2.draw();
        var3.startDrawing(3);
        var3.addVertex(boundingBox.minX, boundingBox.maxY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.maxY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.maxY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.maxY, boundingBox.minZ);
        var2.draw();
        var3.startDrawing(1);
        var3.addVertex(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
        var3.addVertex(boundingBox.minX, boundingBox.maxY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.minY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.maxY, boundingBox.minZ);
        var3.addVertex(boundingBox.maxX, boundingBox.minY, boundingBox.maxZ);
        var3.addVertex(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.minY, boundingBox.maxZ);
        var3.addVertex(boundingBox.minX, boundingBox.maxY, boundingBox.maxZ);
        var2.draw();
        GlStateManager.depthMask(true);
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
    }

    public void drawLines(AxisAlignedBB par1AxisAlignedBB) {
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.minY, par1AxisAlignedBB.minZ);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.maxZ);
        GL11.glEnd();
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.minY, par1AxisAlignedBB.minZ);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.maxZ);
        GL11.glEnd();
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.minY, par1AxisAlignedBB.maxZ);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.maxZ);
        GL11.glEnd();
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.minY, par1AxisAlignedBB.minZ);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.minZ);
        GL11.glEnd();
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.minY, par1AxisAlignedBB.minZ);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.minY, par1AxisAlignedBB.maxZ);
        GL11.glEnd();
        GL11.glBegin(2);
        GL11.glVertex3d(par1AxisAlignedBB.maxX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.minZ);
        GL11.glVertex3d(par1AxisAlignedBB.minX, par1AxisAlignedBB.maxY, par1AxisAlignedBB.maxZ);
        GL11.glEnd();
    }

    public void draw2DCorner(double posX, double posY, double posZ, float alpha, float red, float green,
                             float blue) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.8F);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(2848);
        GlStateManager.translate(posX, posY, posZ);
        GL11.glNormal3f(0.0f, 0.0f, 0.0f);
        GlStateManager.rotate(-RenderManager.playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.scale(-0.1, -0.1, 0.1);
        GlStateManager.func_179098_w();
        drawRectColor(4.0, -20.0, 7.0, -19.5, alpha, red, green, blue);
        drawRect(-7.0, -20.0, -4.0, -19.5, alpha, red, green, blue);
        drawRect(6.5, -20.0, 7.0, -17.5, alpha, red, green, blue);
        drawRect(-7.0, -20.0, -6.5, -17.5, alpha, red, green, blue);
        drawRect(-7.0, 2.5, -4.0, 3.0, alpha, red, green, blue);
        drawRect(4.0, 2.5, 7.0, 3.0, alpha, red, green, blue);
        drawRect(-7.0, 0.5, -6.5, 3.0, alpha, red, green, blue);
        drawRect(6.5, 0.5, 7.0, 3.0, alpha, red, green, blue);
        drawRect(7.0, -20.0, 7.300000190734863, -17.5, Integer.MIN_VALUE);
        drawRect(-7.300000190734863, -20.0, -7.0, -17.5, Integer.MIN_VALUE);
        drawRect(4.0, -20.299999237060547, 7.300000190734863, -20.0, Integer.MIN_VALUE);
        drawRect(-7.300000190734863, -20.299999237060547, -4.0, -20.0, Integer.MIN_VALUE);
        drawRect(-7.0, 3.0, -4.0, 3.299999952316284, Integer.MIN_VALUE);
        drawRect(4.0, 3.0, 7.0, 3.299999952316284, Integer.MIN_VALUE);
        drawRect(-7.300000190734863, 0.5, -7.0, 3.299999952316284, Integer.MIN_VALUE);
        drawRect(7.0, 0.5, 7.300000190734863, 3.299999952316284, Integer.MIN_VALUE);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
        GL11.glPopMatrix();
    }

    public static void drawRectColor(double left, double top, double right, double bottom, float alpha, float red,
                                     float green, float blue) {
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_CURRENT_BIT, GL11.GL_POINTS);
        GL11.glPushMatrix();
        GL11.glColor4f(alpha, red, green, blue);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2d(right, top);
        GL11.glVertex2d(left, top);
        GL11.glVertex2d(left, bottom);
        GL11.glVertex2d(right, bottom);
        GL11.glEnd();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
    }

    public static void drawRect(final double d, final double e, final double f2, final double f3,
                                final int paramColor) {
        final float alpha = (paramColor >> 24 & 0xFF) / 255.0f;
        final float red = (paramColor >> 16 & 0xFF) / 255.0f;
        final float green = (paramColor >> 8 & 0xFF) / 255.0f;
        final float blue = (paramColor & 0xFF) / 255.0f;
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_CURRENT_BIT, GL11.GL_POINTS);
        GL11.glPushMatrix();
        GL11.glColor4f(red, green, blue, alpha);
        GL11.glBegin(7);
        GL11.glVertex2d(f2, e);
        GL11.glVertex2d(d, e);
        GL11.glVertex2d(d, f3);
        GL11.glVertex2d(f2, f3);
        GL11.glEnd();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
    }

    public static void drawRect(double d, double e, double f2, double f3, float red,
                                float green, float blue, float alpha) {
        GlStateManager.enableBlend();
        GlStateManager.func_179090_x();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_CURRENT_BIT, GL11.GL_POINTS);
        GL11.glPushMatrix();
        GL11.glColor4f(red, green, blue, alpha);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2d(f2, e);
        GL11.glVertex2d(d, e);
        GL11.glVertex2d(d, f3);
        GL11.glVertex2d(f2, f3);
        GL11.glEnd();
        GlStateManager.func_179098_w();
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
    }

    public void passive(EntityPlayer entityPlayer) {
        Color color = Color.ORANGE;
        double x = entityPlayer.lastTickPosX
                + (entityPlayer.posX - entityPlayer.lastTickPosX) * mc.timer.renderPartialTicks
                - RenderManager.renderPosX;
        double y = entityPlayer.lastTickPosY
                + (entityPlayer.posY - entityPlayer.lastTickPosY) * mc.timer.renderPartialTicks
                - RenderManager.renderPosY;
        double z = entityPlayer.lastTickPosZ
                + (entityPlayer.posZ - entityPlayer.lastTickPosZ) * mc.timer.renderPartialTicks
                - RenderManager.renderPosZ;
        render(color, x, y, z, entityPlayer.width);
    }

    private void render(Color color, double x, double y, double z, float width) {
        RenderUtils.drawOutlinedEntityESP(x, y, z, 0.5, 2F, color.getRed(), color.getRed(), color.getBlue(),
                color.getAlpha());

    }

}
