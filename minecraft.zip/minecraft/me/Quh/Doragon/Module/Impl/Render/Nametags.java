package me.Quh.Doragon.Module.Impl.Render;

import me.Quh.Doragon.Module.Module;
import org.lwjgl.input.Keyboard;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnRender;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class Nametags extends Module {

    public Nametags() {
        super("Nametags", Keyboard.KEY_NONE, Category.RENDER);
    }
    
    public void renderNameTag(EntityPlayer entity, String tag, double pX, double pY, double pZ) {
        FontRenderer var12 = this.mc.fontRendererObj;
        pY += 0.9D;
        float var13 = mc.thePlayer.getDistanceToEntity(entity) / 4.0F;
        if (var13 < 1.6F) {
            var13 = 1.6F;
        }
        if ((entity instanceof EntityLivingBase)) {
            if ((entity instanceof EntityPlayer)) {
                double health = Math.ceil(entity.getHealth()) / 2.0;
                if (health >= 7D) {
                    tag = tag + " §7[§a" + (int) health + "§4♥§7]";
                } else if (health >= 3) {
                    tag = tag + " §7[§e" + (int) health + "§4♥§7]";
                } else if (health >= 0) {
                    tag = tag + " §7[§e" + (int) health + "§4♥§7]";
                }
            }
            RenderManager renderManager = this.mc.getRenderManager();
            int color = 16776960;
            float scale = var13 * 2F;
            scale /= 100F;
            GL11.glPushMatrix();
            GL11.glTranslatef((float) pX, (float) pY + 1.5F, (float) pZ);
            GL11.glNormal3f(0F, 1F, 0F);
            GL11.glRotatef(-RenderManager.playerViewY, 0F, 1F, 0F);
            GL11.glRotatef(RenderManager.playerViewX, 1F, 0F, 0F);
            GL11.glScalef(-scale, -scale, scale);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            Tessellator var14 = Tessellator.getInstance();
            WorldRenderer var15 = var14.getWorldRenderer();
            int width = this.mc.fontRendererObj.getStringWidth(tag) / 2;
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            Gui.drawRect(-width - 1, -1, width + 1, this.mc.fontRendererObj.FONT_HEIGHT, 1275068416);
            var12.func_175065_a(tag, -width, 0F, 16777215, true);
            GL11.glDisable(3042);
            GL11.glEnable(2896);
            GL11.glEnable(2929);
            GL11.glColor4f(1F, 1F, 1F, 1F);
            GL11.glPopMatrix();
        }
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnRender) {
            if (!isEnabled()) {
                return;
            }
            if ((mc.thePlayer == null) || (mc.theWorld == null)) {
                return;
            }
            for (Object o : mc.theWorld.playerEntities) {
                EntityPlayer p = (EntityPlayer) o;
                if ((p != this.mc.func_175606_aa()) && (p.isEntityAlive())) {
                    this.mc.getRenderManager();
                    double pX = p.lastTickPosX + (p.posX - p.lastTickPosX) * this.mc.timer.renderPartialTicks
                            - RenderManager.renderPosX;
                    this.mc.getRenderManager();
                    double pY = p.lastTickPosY + (p.posY - p.lastTickPosY) * this.mc.timer.renderPartialTicks
                            - RenderManager.renderPosY;
                    this.mc.getRenderManager();
                    double pZ = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * this.mc.timer.renderPartialTicks
                            - RenderManager.renderPosZ;

                    renderNameTag(p, p.getDisplayName().getUnformattedTextForChat(), pX, pY, pZ);
                }
            }
        }
    }

}
