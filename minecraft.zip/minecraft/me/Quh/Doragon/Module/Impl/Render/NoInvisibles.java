package me.Quh.Doragon.Module.Impl.Render;


import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import net.minecraft.entity.EntityLivingBase;

public class NoInvisibles extends Module {

	public NoInvisibles() {
		super("NoInvisibles", Keyboard.KEY_NONE,  Category.RENDER);
		
	}
	
	public void onTick() {
		for(Object o : mc.theWorld.loadedEntityList) {
			if(o instanceof EntityLivingBase) {
				if(o != mc.thePlayer) {
					EntityLivingBase e = (EntityLivingBase) o;
					if(e.isInvisible()) {
						e.setInvisible(false);
					}
				}
			}
		}
	}

}
