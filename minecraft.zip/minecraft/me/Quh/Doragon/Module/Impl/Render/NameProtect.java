package me.Quh.Doragon.Module.Impl.Render;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;

public class NameProtect extends Module {

    public NameProtect() {
        super("NameProtect", Keyboard.KEY_NONE, Category.RENDER);
    }

}
