package me.Quh.Doragon.Module.Impl.Render;

import me.Quh.Doragon.Module.Module;
import org.lwjgl.input.Keyboard;

public class NoBob extends Module{
    public NoBob() {
        super("NoBob", Keyboard.KEY_NONE, Category.RENDER);
    }
}
