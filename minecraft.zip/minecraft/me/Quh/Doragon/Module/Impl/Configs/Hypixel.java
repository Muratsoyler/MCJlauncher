/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Configs;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import net.minecraft.util.ChatComponentText;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class Hypixel extends Module {

    public Hypixel() {
        super("Hypixel", Keyboard.KEY_NONE, Category.CONFIG);
    }

    public void onEnable() {
        Doragon.settingsManager.getSettingByName("Speed Mode").setValString("HypixelBhop");
        Doragon.settingsManager.getSettingByName("Hypixel").setValBoolean(true);
        Doragon.settingsManager.getSettingByName("Tablist Check").setValBoolean(true);
        Doragon.settingsManager.getSettingByName("Burst").setValBoolean(true);
        Doragon.settingsManager.getSettingByName("EntityID").setValBoolean(true);
        Doragon.settingsManager.getSettingByName("CPS").setValDouble(12D);
        Doragon.settingsManager.getSettingByName("Range").setValDouble(5.1D);
        Doragon.settingsManager.getSettingByName("Stealer Delay").setValDouble(50D);
        Doragon.settingsManager.getSettingByName("AutoArmor Mode").setValString("OpenInv");
        Doragon.settingsManager.getSettingByName("Equip Delay").setValDouble(150D);
        Doragon.settingsManager.getSettingByName("NoSlowDown Mode").setValString("Packets");
        Doragon.settingsManager.getSettingByName("Sneak").setValBoolean(false);
        Doragon.settingsManager.getSettingByName("Knockback Mode").setValString("No Knockback");
        this.toggle();
    }

    public void onDisable() {
        mc.thePlayer.addChatMessage(new ChatComponentText("Config set to : Hypixel"));
    }

}
