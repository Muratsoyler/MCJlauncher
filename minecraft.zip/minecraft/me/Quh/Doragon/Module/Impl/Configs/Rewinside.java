package me.Quh.Doragon.Module.Impl.Configs;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import net.minecraft.util.ChatComponentText;

public class Rewinside extends Module {

	public Rewinside() {
		super("Rewinside", Keyboard.KEY_NONE,  Category.CONFIG);
		
	}
	
	public void onEnable() {
		Doragon.settingsManager.getSettingByName("Range").setValDouble(4);
		Doragon.settingsManager.getSettingByName("CPS").setValDouble(9);
		Doragon.settingsManager.getSettingByName("NoSlowDown Mode").setValString("Packets");
		Doragon.settingsManager.getSettingByName("MultiDir").setValBoolean(false);
		Doragon.settingsManager.getSettingByName("Auto Close").setValBoolean(true);
		Doragon.settingsManager.getSettingByName("Stealer Delay").setValDouble(200);
		Doragon.settingsManager.getSettingByName("Equip Delay").setValDouble(100);
		Doragon.settingsManager.getSettingByName("AutoArmor Mode").setValString("OpenInv");
		Doragon.settingsManager.getSettingByName("Rewinside").setValBoolean(true);
		Doragon.settingsManager.getSettingByName("Speed Mode").setValString("RewiBhop");
		Doragon.settingsManager.getSettingByName("BetterAngles").setValBoolean(true);
		mc.thePlayer.playSound("random.fizz", 0.5f, 0.5f);
		this.toggle();
	}
	
	public void onDisable() {
		mc.thePlayer.addChatMessage(new ChatComponentText("Config set to : Rewinside"));
	}

}
