package me.Quh.Doragon.Module.Impl.Configs;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import net.minecraft.util.ChatComponentText;

public class Gomme extends Module {

	public Gomme() {
		super("Gomme", Keyboard.KEY_NONE,  Category.CONFIG);
		
	}
	
	public void onEnable() {
		Doragon.settingsManager.getSettingByName("Range").setValDouble(4.5);
		Doragon.settingsManager.getSettingByName("CPS").setValDouble(9);
		Doragon.settingsManager.getSettingByName("AAC").setValBoolean(true);
		Doragon.settingsManager.getSettingByName("Speed Mode").setValString("GommeBhop1");
		Doragon.settingsManager.getSettingByName("NoSlowDown Mode").setValString("Packets");
		Doragon.settingsManager.getSettingByName("Strafe").setValBoolean(true);
		Doragon.settingsManager.getSettingByName("Step Height").setValDouble(1.0);
		Doragon.settingsManager.getSettingByName("Auto Close").setValBoolean(true);
		Doragon.settingsManager.getSettingByName("Stealer Delay").setValDouble(200);
		Doragon.settingsManager.getSettingByName("Equip Delay").setValDouble(1000);
		Doragon.settingsManager.getSettingByName("AutoArmor Mode").setValString("OpenInv");
		this.toggle();
	}
	
	public void onDisable() {
		mc.thePlayer.addChatMessage(new ChatComponentText("Config set to : Gomme"));
	}

}
