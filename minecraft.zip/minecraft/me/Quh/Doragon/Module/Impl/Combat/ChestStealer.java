package me.Quh.Doragon.Module.Impl.Combat;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemSword;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.TimeHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.ItemStack;

public class ChestStealer extends Module {

	public ChestStealer() {
		super("ChestStealer", Keyboard.KEY_NONE,  Category.COMBAT);

	}

	public void setup() {
		Doragon.settingsManager.rSetting(new Setting("Stealer Delay", this, 100.0, 0.0, 1000.0, false));
		Doragon.settingsManager.rSetting(new Setting("Auto Close", this, false));
	}
	TimeHelper delay = new TimeHelper();

	public void onEvent(Event event) {
		setSuffix(" | " + Doragon.settingsManager.getSettingByName("Stealer Delay").getValDouble());
		if (mc.currentScreen instanceof GuiChest && event instanceof EventOnUpdate
				&& !(mc.currentScreen instanceof GuiInventory) && !(mc.currentScreen instanceof GuiContainerCreative)) {

				GuiChest chest = (GuiChest) mc.currentScreen;

				boolean empty = true;
				for (int i = 0; i < chest.lowerChestInventory.getSizeInventory(); i++) {
					ItemStack stack = chest.lowerChestInventory.getStackInSlot(i);
					if (stack != null) {
						empty = false;
						break;
					}
				}
				if (empty && Doragon.settingsManager.getSettingByName("Auto Close").getValBoolean()) {
					mc.thePlayer.closeScreen();
					return;
				}
				for (int i = 0; i < chest.lowerChestInventory.getSizeInventory(); i++) {
					ItemStack stack = chest.lowerChestInventory.getStackInSlot(i);
					if (stack != null) {
						if ((delay.isDelayComplete((long) Doragon.settingsManager.getSettingByName("Stealer Delay").getValDouble() / 2))) {
							mc.playerController.windowClick(chest.inventorySlots.windowId, Integer.valueOf(i).intValue(), 0,
									1, mc.thePlayer);
							delay.setLastMS();
					}
				}
			}
		}
	}

}
