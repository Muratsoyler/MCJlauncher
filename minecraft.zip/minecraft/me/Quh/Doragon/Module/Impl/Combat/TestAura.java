package me.Quh.Doragon.Module.Impl.Combat;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Event.Events.EventPreMotion;
import me.Quh.Doragon.Friend.FriendUtil;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Impl.Player.Teams;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.KillauraHelper;
import me.Quh.Doragon.Utils.TimeHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import me.Quh.Doragon.Event.Events.EventSendPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.*;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author admin
 */
public class TestAura extends Module {

    public TestAura() {
        super("TestAura", Keyboard.KEY_NONE, Category.COMBAT);
    }

    public TimeHelper time = new TimeHelper();
    public TimeHelper burstTime = new TimeHelper();
    public static EntityLivingBase target;
    public static List targets = new CopyOnWriteArrayList();

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("TestIgnoreInvisibles", this, false));
        Doragon.settingsManager.rSetting(new Setting("TestWallcheck", this, false));
        Doragon.settingsManager.rSetting(new Setting("TestAutoblock", this, false));
        Doragon.settingsManager.rSetting(new Setting("TestAutosword", this, false));
        Doragon.settingsManager.rSetting(new Setting("TestCrack", this, false));
        Doragon.settingsManager.rSetting(new Setting("TestCrackAmount", this, 3, 1, 5, false));
        Doragon.settingsManager.rSetting(new Setting("TestDelay", this, 100, 1, 500, false));
        Doragon.settingsManager.rSetting(new Setting("TestRange", this, 4.5, 0.5, 7, false));
    }


    public void onEvent(Event event){
        if(event instanceof EventPreMotion){
            if(targets.isEmpty()){
                KillauraHelper.findTargets();
            }
            if(!targets.isEmpty()){
                KillauraHelper.filterTargets();
            }
            if(KillauraHelper.check(target)){
                if(Doragon.settingsManager.getSettingByName("TestAutoblock").getValBoolean() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword){
                    mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(),100);
                }
            }else{
                targets.remove(target);
            }
        }
        if(event instanceof EventOnUpdate){
            if(KillauraHelper.check(target) && time.isDelayComplete(Doragon.settingsManager.getSettingByName("TestDelay").getValDouble() + ThreadLocalRandom.current().nextInt(1,50))){
                KillauraHelper.attack(target);
                if(burstTime.isDelayComplete(1000L)){
                    KillauraHelper.burst(target);
                    burstTime.setLastMS();
                }
                time.setLastMS();
            }
        }
    }
}