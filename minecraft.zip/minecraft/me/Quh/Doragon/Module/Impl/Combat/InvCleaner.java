package me.Quh.Doragon.Module.Impl.Combat;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import org.lwjgl.input.Keyboard;

public class InvCleaner extends Module {

    public InvCleaner() {
        super("InvCleaner", Keyboard.KEY_NONE, Category.COMBAT);
    }

    @Override
    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("OnlyInv", this, true));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (Doragon.settingsManager.getSettingByName("OnlyInv").getValBoolean() && !(mc.currentScreen instanceof GuiInventory)) {
                return;
            }
            for (int i = 5; i < 9; i++) {
                for (int inv = 0; inv < 45; inv++) {
                    ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(inv).getStack();
                    if (stack != null && stack.getItem() != null && shouldIDropThisItem(stack,getItemType(stack))) {
                        mc.playerController.windowClick(0, inv, 0, 4, mc.thePlayer);
                    }
                }
            }
        }
    }

    public boolean shouldIDropThisItem(ItemStack stack, int itemType) {
        //Swords
        if (stack.getItem() != null && stack != null && stack.getItem() instanceof ItemSword) {
            for (int i = 0; i < 45; i++) {
                ItemStack invStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (invStack != null && invStack.getItem() != null && invStack.getItem() instanceof ItemSword) {
                    int invStackValue = ((ItemSword) invStack.getItem()).getMaxDamage() + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180314_l.effectId, invStack);
                    int stackValue = ((ItemSword) stack.getItem()).getMaxDamage() + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180314_l.effectId, stack);
                    if (stackValue < invStackValue) {
                        return true;
                    }
                }
            }
        }
        //Armor
        if (stack.getItem() != null && stack != null && stack.getItem() instanceof ItemArmor) {
            for (int i = 0; i < 45; i++) {
                ItemStack invStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (invStack != null && invStack.getItem() != null && invStack.getItem() instanceof ItemArmor && ((ItemArmor) invStack.getItem()).armorType == itemType) {
                    int invStackValue = ((ItemArmor) invStack.getItem()).getArmorMaterial().getDamageReductionAmount(((ItemArmor) invStack.getItem()).armorType) + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180310_c.effectId, invStack);
                    int stackValue = ((ItemArmor) invStack.getItem()).getArmorMaterial().getDamageReductionAmount(((ItemArmor) invStack.getItem()).armorType) + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180310_c.effectId, stack);
                    if (stackValue < invStackValue) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public int getItemType(ItemStack stack){
        if(stack.getItem() instanceof ItemArmor){
            return ((ItemArmor) stack.getItem()).armorType;
        }
        return -1;
    }
}
