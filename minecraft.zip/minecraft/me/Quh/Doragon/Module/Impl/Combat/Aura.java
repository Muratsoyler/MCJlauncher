package me.Quh.Doragon.Module.Impl.Combat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import me.Quh.Doragon.Utils.TimeHelper;
import net.minecraft.util.*;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Module.Impl.Player.Teams;
import me.Quh.Doragon.Utils.EntityHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Friend.FriendUtil;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import me.Quh.Doragon.Event.Events.EventPostMotion;
import me.Quh.Doragon.Event.Events.EventPreMotion;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public class Aura extends Module {

    private List<EntityLivingBase> entities = new ArrayList<>();
    private TimeHelper auraHitDelay = new TimeHelper();
    private TimeHelper tpDelay = new TimeHelper();
    private EntityLivingBase target = null;
    private boolean hitting_Animals = true;
    private boolean hitting_Player = true;
    private boolean hitting_Mobs = true;
    private Random r = new Random();
    public static double range;
    public static int cps;
    private int random;
    private int random1;
    private int random2;

    public Aura() {
        super("Aura", Keyboard.KEY_NONE, Category.COMBAT);
    }

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("CPS", this, 1.0, 1.0, 20.0, false));
        Doragon.settingsManager.rSetting(new Setting("Range", this, 1.0, 1.0, 10.0, false));
        Doragon.settingsManager.rSetting(new Setting("Crack Amount", this, 3, 1, 5, false));
        Doragon.settingsManager.rSetting(new Setting("Rewinside", this, false));
        Doragon.settingsManager.rSetting(new Setting("Dealer", this, false));
        Doragon.settingsManager.rSetting(new Setting("Hypixel", this, false));
        Doragon.settingsManager.rSetting(new Setting("AntiVillager", this, false));
        Doragon.settingsManager.rSetting(new Setting("HurtTime", this, false));
        Doragon.settingsManager.rSetting(new Setting("Burst", this, false));
        Doragon.settingsManager.rSetting(new Setting("AAC", this, false));
        Doragon.settingsManager.rSetting(new Setting("BetterAngles", this, false));
        Doragon.settingsManager.rSetting(new Setting("Invisibles", this, false));
        Doragon.settingsManager.rSetting(new Setting("AutoBlock", this, false));
        Doragon.settingsManager.rSetting(new Setting("Swing Check", this, false));
        Doragon.settingsManager.rSetting(new Setting("Health Check", this, false));
        Doragon.settingsManager.rSetting(new Setting("Ping Check", this, false));
        Doragon.settingsManager.rSetting(new Setting("Tablist Check", this, false));
        Doragon.settingsManager.rSetting(new Setting("Tick Check", this, false));
        Doragon.settingsManager.rSetting(new Setting("EntityID", this, false));
        Doragon.settingsManager.rSetting(new Setting("FaceEntity", this, false));
        Doragon.settingsManager.rSetting(new Setting("Crack", this, false));
        Doragon.settingsManager.rSetting(new Setting("TP", this, false));
    }

    @Override
    public void onEvent(Event e) {
        if (e instanceof EventPreMotion) {
            range = ((int) Doragon.settingsManager.getSettingByName("Range").getValDouble());
            cps = ((int) Doragon.settingsManager.getSettingByName("CPS").getValDouble());
            EventPreMotion event = (EventPreMotion) e;
            List<EntityLivingBase> targets = new ArrayList<>();
            mc.theWorld.loadedEntityList.stream().filter(entity -> entity instanceof EntityLivingBase)
                    .filter(entity -> check((EntityLivingBase) entity))
                    .forEach(entity -> targets.add((EntityLivingBase) entity));
            if (Doragon.settingsManager.getSettingByName("HurtTime").getValBoolean()) {
                setSuffix(" | HurtTime[" + targets.size() + "]");
            } else {
                setSuffix(" | Switch[" + targets.size() + "]");
            }

            if (check(target)) {
                if (target != null) {
                    target = (EntityLivingBase) rangeSwitch();
                    if (mc.thePlayer.getDistanceToEntity(target) < range) {
                        if (!Doragon.settingsManager.getSettingByName("BetterAngles").getValBoolean()) {
                            float[] rotations = getRotations(target);
                            event.yaw = rotations[0] + random;
                            event.pitch = rotations[1] + random1;
                        } else {
                            if (Doragon.settingsManager.getSettingByName("BetterAngles").getValBoolean()) {
                                float[] roations = EntityHelper.getAngles(target);
                                event.yaw = roations[0] + random;
                                event.pitch = roations[1] + random1;
                            }
                        }
                        random = (1 + r.nextInt(10 - 1));
                        random1 = (1 + r.nextInt(20 - 1));
                        if (Doragon.settingsManager.getSettingByName("AAC").getValBoolean()) {
                            mc.thePlayer.swingItem();
                        }
                    }
                }
            }
        }
        if (e instanceof EventOnUpdate) {
            if (!(entities.isEmpty())) {
                filterTargets();
            } else {
                mc.theWorld.loadedEntityList.stream().filter(entity -> entity instanceof EntityLivingBase)
                        .filter(entity -> check((EntityLivingBase) entity))
                        .forEach(entity -> entities.add((EntityLivingBase) entity));
            }
            random2 = (1 + r.nextInt(100 - 1));
            int i = 5;
            if (check(target) && (auraHitDelay.isDelayComplete(1000 / cps + random2 + i))) {
                i++;
                i++;
                if (Doragon.settingsManager.getSettingByName("TP").getValBoolean() && tpDelay.isDelayComplete(300)) {
                    mc.thePlayer.setPosition(target.posX, target.posY + 1, target.posZ);
                }
                attack(target);
                if (Doragon.settingsManager.getSettingByName("TP").getValBoolean() && tpDelay.isDelayComplete(300)) {
                    mc.thePlayer.setPosition(target.posX, target.posY + 1, target.posZ);
                }
                tpDelay.setLastMS();
                auraHitDelay.setLastMS();
            }
        }
        if (e instanceof EventPostMotion) {
            EventPostMotion event = (EventPostMotion) e;
            event.yaw = mc.thePlayer.rotationYaw;
            event.pitch = mc.thePlayer.rotationPitch;
        }
        super.onEvent(e);
    }

    private EntityLivingBase healthSwitch() {
        EntityLivingBase healthiest = null;
        for (Object o : mc.theWorld.loadedEntityList) {
            EntityLivingBase e = (EntityLivingBase) o;
            if (e instanceof EntityLivingBase && e != mc.thePlayer && check(e)) {
                if (healthiest == null || e.getHealth() > healthiest.getHealth()) {
                    healthiest = e;
                }
            }
        }
        return healthiest;
    }

    private Entity rangeSwitch() {
        Entity nearest = null;
        for (Object o : mc.theWorld.loadedEntityList) {
            Entity e = (Entity) o;
            if (!(e == mc.thePlayer) && e.isEntityAlive() && !e.isDead && e instanceof EntityLivingBase && check((EntityLivingBase) e)) {
                if (nearest == null
                        || mc.thePlayer.getDistanceToEntity(e) < mc.thePlayer.getDistanceToEntity(nearest)) {
                    nearest = e;
                }
            }
        }
        return nearest;

    }

    private void attack(Entity target) {
        double motionX = mc.thePlayer.motionX;
        double motionZ = mc.thePlayer.motionZ;
        boolean wasSneaking = mc.thePlayer.isSneaking();
        if (wasSneaking) {
            mc.thePlayer.sendQueue.addToSendQueue(
                    new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }
        if (Doragon.settingsManager.getSettingByName("Burst").getValBoolean()) {
            mc.thePlayer.attackTargetEntityWithCurrentItem(target);
            mc.thePlayer.swingItem();
            mc.thePlayer.attackTargetEntityWithCurrentItem(target);
            mc.thePlayer.swingItem();
        }
        if (target != null) {
            target = rangeSwitch();
            // mc.thePlayer.sendQueue.addToSendQueue(new
            // C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
            mc.playerController.attackEntity(mc.thePlayer, target);
            mc.thePlayer.swingItem();

            if (Doragon.settingsManager.getSettingByName("Crack").getValBoolean()) {
                if ((int) Doragon.settingsManager.getSettingByName("Crack Amount").getValDouble() == 1) {
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                }
                if ((int) Doragon.settingsManager.getSettingByName("Crack Amount").getValDouble() == 2) {
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                }
                if ((int) Doragon.settingsManager.getSettingByName("Crack Amount").getValDouble() == 3) {
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                }
                if ((int) Doragon.settingsManager.getSettingByName("Crack Amount").getValDouble() == 4) {
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                }
                if ((int) Doragon.settingsManager.getSettingByName("Crack Amount").getValDouble() == 5) {
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                    mc.effectRenderer.func_178926_a(target, EnumParticleTypes.CRIT);
                }
            }
            if (Doragon.settingsManager.getSettingByName("AutoBlock").getValBoolean()
                    && this.mc.thePlayer.getCurrentEquippedItem() != null && this.target != null
                    && this.mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword) {
                ((ItemSword) this.mc.thePlayer.getCurrentEquippedItem().getItem()).onItemRightClick(
                        this.mc.thePlayer.getCurrentEquippedItem(), this.mc.theWorld, this.mc.thePlayer);
            }
            mc.thePlayer.setSprinting(true);
            mc.thePlayer.motionX = motionX;
            mc.thePlayer.motionZ = motionZ;
            if (wasSneaking) {
                mc.thePlayer.sendQueue.addToSendQueue(
                        new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
            }
        }
    }

    private boolean isInTablist(EntityLivingBase entity) {
        if (mc.isSingleplayer()) {
            return false;
        } else {
            java.util.Iterator var3 = mc.getNetHandler().func_175106_d().iterator();

            while (var3.hasNext()) {
                NetworkPlayerInfo playerInfo = (NetworkPlayerInfo) var3.next();
                if (playerInfo.func_178845_a().getName().equalsIgnoreCase(entity.getName())) {
                    return true;
                }
            }
            return false;
        }
    }

    private boolean check(EntityLivingBase entity) {
        try {
            boolean isAnimals = (((entity instanceof EntityAnimal)) || ((entity instanceof EntityAmbientCreature))
                    || ((entity instanceof EntityWaterMob)) || ((entity instanceof EntityAgeable)))
                    && hitting_Animals == false;
            boolean isPlayers = ((entity instanceof EntityPlayer) && (hitting_Player == false));
            boolean isMobs = ((entity instanceof IMob)) && ((entity instanceof IEntityMultiPart)) && (hitting_Mobs);
            if (entity == null) {
                return false;
            }
            if (isPlayers) {
                return false;
            }
            if (isMobs) {
                return false;
            }
            if (isAnimals) {
                return false;
            }
            if (FriendUtil.isAFriend(entity.getName())) {
                return false;
            }
            if (entity.getName().equalsIgnoreCase(mc.session.getUsername())) {
                return false;
            }
            if (!entity.isEntityAlive()) {
                return false;
            }
            if (!mc.thePlayer.isEntityAlive()) {
                return false;
            }
            if (Doragon.settingsManager.getSettingByName("Hypixel").getValBoolean() && entity.getName().startsWith("§")) {
                return false;
            }
            if (!mc.thePlayer.canEntityBeSeen(entity)) {
                return false;
            }
            if (entity == mc.thePlayer) {
                return false;
            }
            if (entity.getName().equalsIgnoreCase("Delay") || entity.getDisplayName().getUnformattedText().equalsIgnoreCase("§6Dealer")
                    && Doragon.settingsManager.getSettingByName("Dealer").getValBoolean()) {
                return false;
            }
            if (entity.getEntityId() > 1070000000 || entity.getEntityId() <= -1
                    && Doragon.settingsManager.getSettingByName("EntityID").getValBoolean()) {
                return false;
            }
            if (mc.thePlayer.getDistanceToEntity(entity) > range) {
                return false;
            }
            if (!entity.isSwingInProgress && Doragon.settingsManager.getSettingByName("Swing Check").getValBoolean()) {
                return false;
            }
            if (entity.hurtTime > 1 && Doragon.settingsManager.getSettingByName("HurtTime").getValBoolean()) {
                return false;
            }
            if (!(mc.currentScreen == null) && Doragon.settingsManager.getSettingByName("Rewinside").getValBoolean()) {
                return false;
            }
            if (entity instanceof EntityVillager
                    && Doragon.settingsManager.getSettingByName("AntiVillager").getValBoolean()) {
                return false;
            }
            if (entity.getHealth() <= 0 && Doragon.settingsManager.getSettingByName("Health Check").getValBoolean()) {
                return false;
            }
            if (entity.ticksExisted <= 300 && Doragon.settingsManager.getSettingByName("Tick Check").getValBoolean()) {
                return false;
            }
            if (entity.isInvisible() && Doragon.settingsManager.getSettingByName("Invisibles").getValBoolean()) {
                return false;
            }
            if (Doragon.moduleManager.getModule(Teams.class).isEnabled() && Teams.isinTeam(entity)) {
                return false;
            }
            if (mc.getNetHandler().func_175102_a(entity.getUniqueID()).getResponseTime() <= 1
                    && Doragon.settingsManager.getSettingByName("Ping Check").getValBoolean()) {
                return false;
            }
            if (!(isInTablist(entity)) && Doragon.settingsManager.getSettingByName("Tablist Check").getValBoolean()) {
                return false;
            }
            if (Doragon.settingsManager.getSettingByName("FaceEntity").getValBoolean()) {
                faceEntity(entity);
            }
        } catch (Exception ex) {
        }
        return true;
    }

    private static float[] getRotations(EntityLivingBase target) {
        if (target == null) {
            return null;
        }
        double diffX = target.posX - mc.getMinecraft().thePlayer.posX;
        double diffZ = target.posZ - mc.getMinecraft().thePlayer.posZ;
        double diffY;
        if (target instanceof EntityLivingBase) {
            EntityLivingBase entityLivingBase = (EntityLivingBase) target;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight()
                    - (mc.getMinecraft().thePlayer.posY + mc.getMinecraft().thePlayer.getEyeHeight());
        } else {
            diffY = (target.boundingBox.minY + target.boundingBox.maxY) / 2.0
                    - (mc.getMinecraft().thePlayer.posY + mc.getMinecraft().thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[]{
                mc.getMinecraft().thePlayer.rotationYaw
                        + MathHelper.wrapAngleTo180_float(yaw - mc.getMinecraft().thePlayer.rotationYaw),
                mc.getMinecraft().thePlayer.rotationPitch
                        + MathHelper.wrapAngleTo180_float(pitch - mc.getMinecraft().thePlayer.rotationPitch)};

    }



    private void filterTargets() {
        if (entities.isEmpty()) {
            return;
        }
        if (entities.size() > 1) {
            EntityLivingBase rotations = entities.stream().sorted((entity1, entity2) -> {
                float firstYaw = getYawChangeToEntity(entity1);
                float firstPitch = getPitchChangeToEntity(entity1);
                double firstEntityDistance = (firstYaw + firstPitch) / 2.0f;
                float secondYaw = getYawChangeToEntity(entity2);
                float secondPitch = getPitchChangeToEntity(entity2);
                double secondEntityDistance = (secondYaw + secondPitch) / 2.0f;
                return (firstEntityDistance > secondEntityDistance) ? 1
                        : ((secondEntityDistance > firstEntityDistance) ? -1 : 0);
            }).findFirst().get();
            if (check(rotations)) {
                target = rotations;
            } else {
                entities.removeIf(string -> string.equals(rotations));
            }
        } else {
            EntityLivingBase first = entities.stream().findFirst().get();
            if (check(first)) {
                target = first;
            } else {
                entities.removeIf(string -> string.equals(first));
            }
        }
    }

    public static synchronized void faceEntity(EntityLivingBase entity) {
        final float[] rotations = getRotations(entity);

        if (rotations != null) {
            Minecraft.getMinecraft().thePlayer.rotationYaw = rotations[0];
            Minecraft.getMinecraft().thePlayer.rotationPitch = rotations[1] + 1.0F;
        }
    }

    private float getYawChangeToEntity(EntityLivingBase entity) {
        double posX = entity.posX;
        double deltaX = posX - mc.thePlayer.posX;
        double posZ = entity.posZ;
        double deltaZ = posZ - mc.thePlayer.posZ;
        double yawToEntity1 = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            yawToEntity1 = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            double yawToEntity2 = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else {
            Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(mc.thePlayer.rotationYaw - (float) yawToEntity1));
    }

    private float getPitchChangeToEntity(EntityLivingBase entity) {
        double posX = entity.posX;
        double deltaX = posX - mc.thePlayer.posX;
        double posZ = entity.posZ;
        double deltaZ = posZ - mc.thePlayer.posZ;
        double n = entity.posY - 1.6 + entity.getEyeHeight();
        double deltaY = n - mc.thePlayer.posY;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationPitch - (float) pitchToEntity);
    }

    public boolean isHitting_Animals() {
        return hitting_Animals;
    }

    public void setHitting_Animals(boolean hitting_Animals) {
        this.hitting_Animals = hitting_Animals;
    }

    public boolean isHitting_Player() {
        return hitting_Player;
    }

    public void setHitting_Player(boolean hitting_Player) {
        this.hitting_Player = hitting_Player;
    }

    public boolean isHitting_Mobs() {
        return hitting_Mobs;
    }

    public void setHitting_Mobs(boolean hitting_Mobs) {
        this.hitting_Mobs = hitting_Mobs;
    }

}
