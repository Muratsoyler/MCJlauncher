package me.Quh.Doragon.Module.Impl.Combat;

import java.util.ArrayList;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.TimeHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class AutoArmor extends Module {

    public TimeHelper equipDelay = new TimeHelper();

    public AutoArmor() {
        super("AutoArmor", Keyboard.KEY_NONE, Category.COMBAT);
    }

    public void setup() {
        ArrayList<String> mode = new ArrayList();
        mode.add("OpenInv");
        mode.add("Normal");
        Doragon.settingsManager.rSetting(new Setting("Equip Delay", this, 100.0, 1.0, 1000.0, false));
        Doragon.settingsManager.rSetting(new Setting("AutoArmor Mode", this, "OpenInv", mode));
    }

    public void onEvent(Event event) {
        if ((equipDelay
                .isDelayComplete((long) Doragon.settingsManager.getSettingByName("Equip Delay").getValDouble()))) {
            if (event instanceof EventOnUpdate) {
                if (Doragon.settingsManager.getSettingByName("AutoArmor Mode").getValString()
                        .equalsIgnoreCase("OpenInv")) {
                    setSuffix(" | OpenInv");
                    if (this.mc.currentScreen instanceof GuiInventory) {
                        if (this.mc.thePlayer.openContainer != null
                                && this.mc.thePlayer.openContainer.windowId != 0) {
                            return;
                        }
                        for (int i = 5; i < 9; i++) {
                            ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                            int value = getBestArmor(stack);
                            int type = i - 5;
                            int bestSlot = -1;
                            int highestValue = 0;
                            for (int inv = 9; inv < 45; inv++) {
                                ItemStack invStack = mc.thePlayer.inventoryContainer.getSlot(inv).getStack();
                                if (invStack != null && invStack.getItem() instanceof ItemArmor) {
                                    ItemArmor armor = (ItemArmor) invStack.getItem();
                                    int armorProtection = armor.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180310_c.effectId, invStack);
                                    if (armor.armorType == type && armorProtection > value && armorProtection > highestValue) {
                                        highestValue = armorProtection;
                                        bestSlot = inv;
                                    }
                                }
                            }
                            if (bestSlot != -1) {
                                if (stack == null) {
                                    mc.playerController.windowClick(0, bestSlot, 0, 1, mc.thePlayer);
                                } else {
                                    mc.playerController.windowClick(0, bestSlot, 0, 0, mc.thePlayer);
                                    mc.playerController.windowClick(0, i, 0, 0, mc.thePlayer);
                                    mc.playerController.windowClick(0, bestSlot, 0, 0, mc.thePlayer);
                                }
                            }
                            equipDelay.setLastMS();
                        }
                    }
                }
                if (Doragon.settingsManager.getSettingByName("AutoArmor Mode").getValString().equalsIgnoreCase("Normal")) {
                    setSuffix(" | Normal");
                    if (this.mc.thePlayer != null) {
                        if ((equipDelay.isDelayComplete((long) Doragon.settingsManager.getSettingByName("Equip Delay").getValDouble()))) {
                            if (mc.thePlayer.openContainer.windowId != 0) {
                                return;
                            }
                            for (int i = 5; i < 9; i++) {
                                ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                                int value = getBestArmor(stack);
                                int type = i - 5;
                                int bestSlot = -1;
                                int highestValue = 0;
                                for (int inv = 9; inv < 45; inv++) {
                                    ItemStack invStack = mc.thePlayer.inventoryContainer.getSlot(inv).getStack();
                                    if (invStack != null && invStack.getItem() instanceof ItemArmor) {
                                        ItemArmor armor = (ItemArmor) invStack.getItem();
                                        int armorProtection = armor.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180310_c.effectId, invStack);
                                        if (armor.armorType == type && armorProtection > value && armorProtection > highestValue) {
                                            highestValue = armorProtection;
                                            bestSlot = inv;
                                        }
                                    }
                                }
                                if (bestSlot != -1) {
                                    if (stack == null) {
                                        mc.playerController.windowClick(0, bestSlot, 0, 1, mc.thePlayer);
                                    } else {
                                        mc.playerController.windowClick(0, bestSlot, 0, 0, mc.thePlayer);
                                        mc.playerController.windowClick(0, i, 0, 0, mc.thePlayer);
                                        mc.playerController.windowClick(0, bestSlot, 0, 0, mc.thePlayer);
                                    }
                                }
                                equipDelay.setLastMS();
                            }
                        }
                    }
                }
                //equipDelay.reset();
            }
        }
    }

    public int getBestArmor(ItemStack itemStack) {
        if (itemStack != null && itemStack.getItem() instanceof ItemArmor) {
            int normal = ((ItemArmor) itemStack.getItem()).damageReduceAmount;
            int enchantment = EnchantmentHelper.getEnchantmentLevel(Enchantment.field_180310_c.effectId, itemStack);
            return normal + enchantment;
        }
        return -1;
    }

}

