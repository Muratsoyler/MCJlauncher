package me.Quh.Doragon.Module.Impl.Gui;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Filer.Filers.ClickGuiFile;


public class ClickGUI extends Module {

	public ClickGUI() {
		super("ClickGUI", Keyboard.KEY_RSHIFT,  Category.GUI);
		
	}
	
	public void setup() {
		Doragon.settingsManager.rSetting(new Setting("Show KeyBinds", this, false));
		Doragon.settingsManager.rSetting(new Setting("Blur", this, false));
	}
	
	public void onEnable() {
		mc.displayGuiScreen(new me.Quh.Doragon.GUI.ClickGUI.ClickGUI());
		ClickGuiFile.loadClickGui();
	}

}
