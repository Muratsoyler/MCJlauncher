package me.Quh.Doragon.Module.Impl.Gui;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;

public class HUD extends Module {

	public HUD() {
		super("HUD", Keyboard.KEY_NONE,  Category.GUI);
		
	}
	
	public void setup() {
        ArrayList<String> mode = new ArrayList();
		Doragon.settingsManager.rSetting(new Setting("Watermark", this, false));
		Doragon.settingsManager.rSetting(new Setting("ArrayList", this, false));
		Doragon.settingsManager.rSetting(new Setting("TabGUI", this, false));
		Doragon.settingsManager.rSetting(new Setting("BlackBar", this, false));
		Doragon.settingsManager.rSetting(new Setting("Rectangles", this, false));
		Doragon.settingsManager.rSetting(new Setting("HUD Design", this,"Normal", mode));
        mode.add("Simple");
        mode.add("Normal");
		mode.add("Other");
		mode.add("Future");
	}
	
	public void onDisable(){
		this.toggle();
	}

}
