package me.Quh.Doragon.Module.Impl.Movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;

public class Jesus extends Module {

    public Jesus() {
        super("Jesus", Keyboard.KEY_NONE, Category.MOVEMENT);

    }

    public void setup() {
        ArrayList<String> mode = new ArrayList<>();
        mode.add("GommeJesus");
        mode.add("VanillaJesus");
        Doragon.settingsManager.rSetting(new Setting("Jesus Mode", this, "GommeJesus", mode));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (Doragon.settingsManager.getSettingByName("Jesus Mode").getValString().equalsIgnoreCase("GommeJesus")) {
                mc.thePlayer.jumpMovementFactor *= 0.9F;
                if (mc.thePlayer.isInWater()) {
                    mc.thePlayer.motionY = 0.2F;
                    mc.timer.timerSpeed = 1F;
                }
            }
            if (Doragon.settingsManager.getSettingByName("Jesus Mode").getValString().equalsIgnoreCase("VanillaJesus")) {
                if (mc.thePlayer.isInWater()) {
                    if (!mc.thePlayer.onGround) {
                        mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.01, mc.thePlayer.posZ);
                    }
                    //mc.thePlayer.motionY *= 0.0;
                    mc.thePlayer.motionX *= 1.21;
                    mc.thePlayer.motionZ *= 1.21;
                }
            }
        }
    }

}
