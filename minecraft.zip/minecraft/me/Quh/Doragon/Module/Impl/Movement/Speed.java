package me.Quh.Doragon.Module.Impl.Movement;

import java.util.ArrayList;

import net.minecraft.potion.PotionEffect;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnMove;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public class Speed extends Module {

    private EntityLivingBase e;

    public Speed() {
        super("Speed", Keyboard.KEY_NONE, Category.MOVEMENT);
    }

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("Strafe", this, false));
        ArrayList<String> mode = new ArrayList();
        mode.add("GommeBhop1");
        mode.add("GommeBhop2");
        mode.add("GommeBhop3");
        mode.add("GommeCombat");
        mode.add("Mineplex");
        mode.add("YPort");
        mode.add("RewiBhop");
        mode.add("Hypixel OnGround");
        mode.add("HypixelBhop");
        mode.add("SearchSpeed");
        mode.add("Killswitch");
        mode.add("Test");
        Doragon.settingsManager.rSetting(new Setting("Speed Mode", this, "GommeBhop1", mode));
    }

    public static boolean jumped;
    public static int i = 0;
    public static boolean nextTick;

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (mc.theWorld == null || mc.thePlayer == null) {
                return;
            }
            if (!(Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("GommeBhop1"))
                    || !(Doragon.settingsManager.getSettingByName("Speed Mode").getValString()
                            .equalsIgnoreCase("GommeCombat"))) {
                mc.timer.timerSpeed = 1F;
            }
            if (Doragon.settingsManager.getSettingByName("Strafe").getValBoolean()) {
                double currentSpeed = Math
                        .sqrt(Math.pow(mc.thePlayer.motionX, 2.0D) + Math.pow(mc.thePlayer.motionZ, 2.0D));
                MovementInput movementInput = mc.thePlayer.movementInput;
                float forward = movementInput.moveForward;
                float strafe = movementInput.moveStrafe;
                float yaw = mc.thePlayer.rotationYaw;

                if ((forward == 0.0F) && (strafe == 0.0F)) {
                    mc.thePlayer.motionX = 0.0D;
                    mc.thePlayer.motionZ = 0.0D;
                } else if (forward != 0.0F) {
                    if (strafe >= 1.0F) {
                        yaw += (forward > 0.0F ? -45 : 45);
                        strafe = 0.0F;
                    } else if (strafe <= -1.0F) {
                        yaw += (forward > 0.0F ? 45 : -45);
                        strafe = 0.0F;
                    }
                    if (forward > 0.0F) {
                        forward = 1.0F;
                    } else if (forward < 0.0F) {
                        forward = -1.0F;
                    }
                }

                double mx = Math.cos(Math.toRadians(yaw + 90.0F));
                double mz = Math.sin(Math.toRadians(yaw + 90.0F));

                double ms = currentSpeed;

                mc.thePlayer.motionX = (forward * ms * mx + strafe * ms * mz);
                mc.thePlayer.motionZ = (forward * ms * mz - strafe * ms * mx);
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("GommeBhop1")) {
                setSuffix(" | GommeBhop1");
                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.thePlayer.motionY = 0.4;
                        mc.timer.timerSpeed = 1.25F;
                        combatMode();
                        mc.thePlayer.landMovementFactor *= 7F;
                        mc.thePlayer.jumpMovementFactor = 0.03F;
                        mc.thePlayer.cameraPitch = 0F;
                        mc.thePlayer.cameraYaw = 0F;
                        mc.thePlayer.moveStrafing += 0.1F;
                    } else {
                        mc.thePlayer.moveStrafing += 0.5F;
                        mc.thePlayer.motionX *= 1.001f;
                        mc.thePlayer.motionZ *= 1.001f;
                        mc.timer.timerSpeed = 1.03F;
                        mc.thePlayer.jumpMovementFactor *= 1.07F;
                        mc.thePlayer.speedInAir = 0.02F;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("Killswitch")) {
                setSuffix(" | Killswitch");
                double offset = (mc.thePlayer.rotationYaw + 90.0f + ((mc.thePlayer.moveForward > 0.0f) ? ((mc.thePlayer.moveStrafing > 0.0f) ? -45 : ((mc.thePlayer.moveStrafing < 0.0f) ? 45 : 0)) : ((mc.thePlayer.moveForward < 0.0f) ? (180 + ((mc.thePlayer.moveStrafing > 0.0f) ? 45 : ((mc.thePlayer.moveStrafing < 0.0f) ? -45 : 0))) : ((mc.thePlayer.moveStrafing > 0.0f) ? -90 : ((mc.thePlayer.moveStrafing < 0.0f) ? 90 : 0))))) * 3.141592653589793 / 180.0;
                double x = Math.cos(offset) * 0.25;
                double z = Math.sin(offset) * 0.25;
                if(mc.thePlayer != null && !mc.thePlayer.isInWater() && !mc.thePlayer.isCollidedHorizontally && !mc.thePlayer.isOnLadder() && !mc.thePlayer.isSneaking() && mc.thePlayer.onGround && isPressed()){
                    mc.thePlayer.motionX += x;
                    mc.thePlayer.motionY = 0.017500000074505806;
                    mc.thePlayer.motionZ += z;
                    if(mc.thePlayer.movementInput.moveStrafe != 0F){
                        mc.thePlayer.motionX *= 0.9750000238418579;
                        mc.thePlayer.motionZ *= 0.9750000238418579;
                    }
                    mc.timer.timerSpeed = 1.05F;
                    this.jumped = true;
                }else{
                    mc.timer.timerSpeed = 1F;
                }
                if(this.jumped && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder()){
                    mc.thePlayer.motionY = -0.10000000149011612;
                    this.jumped = false;
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("Test")) {
                setSuffix(" | Test");
                boolean strafe = mc.thePlayer.moveStrafing != 0F;
                double speed = 2.433;
                if(!mc.thePlayer.isSprinting()){
                    speed += 0.4;
                }
                if(strafe){
                    speed -= 0.03999999910593033;
                }
                if(mc.thePlayer.isPotionActive(Potion.moveSpeed)){
                    PotionEffect effect = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed);
                    switch(effect.getAmplifier()){
                        case 0:{
                                speed -=0.2975;
                                break;
                            }
                        case 1:{
                            speed -= 0.5575;
                            break;
                        }
                        case 2: {
                            speed -= 0.7858;
                            break;
                        }
                        case 3: {
                            speed -= 0.7858;
                            break;
                        }
                    }
                }
                if(mc.thePlayer != null && !mc.thePlayer.isInWater() && !mc.thePlayer.isCollidedHorizontally && !mc.thePlayer.isOnLadder() && !mc.thePlayer.isSneaking() && mc.thePlayer.onGround && isPressed()){
                    boolean nextTick = !this.nextTick;
                    this.nextTick = nextTick;
                    if(nextTick){
                        mc.thePlayer.motionX *= speed;
                        mc.thePlayer.motionZ *= speed;
                    }else{
                        mc.thePlayer.motionX /= 3;
                        mc.thePlayer.motionZ /= 3;
                    }
                }else if(this.nextTick){
                    mc.thePlayer.motionX *= speed;
                    mc.thePlayer.motionZ *= speed;
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("GommeBhop2")) {
                setSuffix(" | GommeBhop2");
                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                    mc.thePlayer.setSprinting(true);
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.timer.timerSpeed = 1.17F;
                        mc.thePlayer.motionY = 0.4D;
                        mc.thePlayer.motionX *= 1.01D;
                        mc.thePlayer.motionZ *= 1.01D;
                        mc.thePlayer.jumpMovementFactor = 3.0F;
                        mc.thePlayer.moveStrafing = 2.0F;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("GommeCombat")) {
                setSuffix(" | GommeCombat");
                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                    if (mc.thePlayer.onGround) {
                        mc.timer.timerSpeed = 1.4F;
                        mc.thePlayer.jump();
                    } else {
                        mc.timer.timerSpeed = 1.2F;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("Mineplex")) {
                setSuffix(" | Mineplex");
                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.thePlayer.motionY = -1D;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("RewiBhop")) {
                setSuffix(" | Rewi Bhop");
                if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
                        || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.timer.timerSpeed = 1.13F;
                        mc.thePlayer.motionX *= 1.008D;
                        mc.thePlayer.motionZ *= 1.008D;
                        mc.thePlayer.moveStrafing = 2.0F;
                        mc.thePlayer.jumpMovementFactor = 6.0F;
                    } else {
                        mc.thePlayer.jumpMovementFactor = 0.028F;
                        mc.thePlayer.moveStrafing = 2.0F;
                        mc.timer.timerSpeed = 1.02F;
                        mc.thePlayer.motionX *= 1.0003D;
                        mc.thePlayer.motionZ *= 1.0003D;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("YPort")) {
                setSuffix(" | YPort");
                mc.thePlayer.distanceWalkedModified = 0.0F;
                if ((mc.gameSettings.keyBindForward.pressed) || (mc.gameSettings.keyBindLeft.pressed)
                        || (mc.gameSettings.keyBindRight.pressed) || (mc.gameSettings.keyBindBack.pressed)) {
                    if (mc.thePlayer.motionY > 0.2D) {
                        mc.thePlayer.motionY = -1.0D;
                    } else if (mc.thePlayer.motionY > -0.125D) {
                        mc.thePlayer.jump();
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("Hypixel OnGround")) {
                setSuffix(" | Hypixel OnGround");
                doSpeed();
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("GommeBhop3")) {
                if (isPressed()) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                    }
                    mc.thePlayer.speedInAir = 0.0235F;
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("HypixelBhop")) {
                if (isPressed()) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.timer.timerSpeed = 1.25F;
                        mc.thePlayer.motionY = 0.4D;
                        mc.thePlayer.motionX *= 1.001D;
                        mc.thePlayer.motionZ *= 1.001D;
                        mc.thePlayer.jumpMovementFactor = 3F;
                        mc.thePlayer.moveStrafing = 2F;
                    }else{
                        mc.thePlayer.speedInAir = 0.05F;
                        mc.thePlayer.jumpMovementFactor = 0.02F;
                        mc.thePlayer.jumpMovementFactor *= 1.05F;
                    }
                }
            }
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("SearchSpeed")) {
                setSuffix(" | SearchSpeed");
                if (mc.thePlayer.onGround) {
                    mc.timer.timerSpeed = 1.1F;
                    mc.thePlayer.jump();
                    mc.thePlayer.cameraPitch = 0F;
                    mc.thePlayer.cameraYaw = 0F;
                    mc.thePlayer.landMovementFactor = 0.05F;
                } else {
                    mc.timer.timerSpeed = 1F;
                    mc.thePlayer.jumpMovementFactor = 0.04F;
                    mc.thePlayer.moveStrafing = 2.0F;
                    mc.thePlayer.motionX *= 1.001D;
                    mc.thePlayer.motionZ *= 1.001D;
                }
            }
        }
        if (event instanceof EventOnMove) {
            EventOnMove e = (EventOnMove) event;
            if (Doragon.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("Hypixel OnGround")) {
                if (!checker()) {
                    return;
                }
                if (mc.thePlayer.isInWater()) {
                    return;
                }
                if ((mc.thePlayer.fallDistance > 0.4D) && (!mc.thePlayer.movementInput.jump)) {
                    return;
                }
                if ((!mc.thePlayer.movementInput.jump) && (this.var12 < 1) && (!mc.thePlayer.isCollidedHorizontally)) {
                    mc.thePlayer.posY = mc.thePlayer.posY + 1 - 1;
                }
                this.var8 = (!this.var8);
                this.var10 += 1;
                this.var10 %= 5;
                if (this.var10 != 0) {
                    mc.timer.timerSpeed = 1.0F;
                } else {
                    if (isPressed()) {
                        mc.timer.timerSpeed = 32767.0F;
                    }
                    if (isPressed()) {
                        mc.timer.timerSpeed = this.var9;
                        mc.thePlayer.motionX *= 1.0199999809265137D;
                        mc.thePlayer.motionZ *= 1.0199999809265137D;
                    }
                }
                if ((mc.thePlayer.onGround) && (isPressed())) {
                    this.var1 = 2;
                }
                if ((this.var1 == 1) && ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F))) {
                    if (!mc.thePlayer.onGround) {
                        return;
                    }
                    this.var1 = 2;
                    this.var3 = (1.38D * getBaseMoveSpeed() - 0.01D);
                } else if (this.var1 == 2) {
                    this.var1 = 3;
                    mc.thePlayer.motionY = 0.399399995803833D;
                    e.y = 0.399399995803833D;
                    this.var3 *= 2.149D;
                } else if (this.var1 == 3) {
                    this.var1 = 4;
                    double difference = 0.66D * (this.var5 - getBaseMoveSpeed());
                    this.var3 = (this.var5 - difference);
                } else {
                    //if ((mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, axb.expand(0.0D, mc.thePlayer.motionY, 0.0D))
                    //        .size() > 0) || (mc.thePlayer.isCollidedVertically)) {
                    //    this.var1 = 1;
                    //}
                    this.var3 = (this.var5 - this.var5 / 159.0D);
                }
                this.var3 = Math.max(this.var3, getBaseMoveSpeed());
                MovementInput movementInput = mc.thePlayer.movementInput;
                float forward = movementInput.moveForward;
                float strafe = movementInput.moveStrafe;
                float yaw = mc.thePlayer.rotationYaw;
                if ((forward == 0.0F) && (strafe == 0.0F)) {
                    e.x = 0.0D;
                    e.z = 0.0D;
                } else if (forward != 0.0F) {
                    if (strafe >= 1.0F) {
                        yaw += (forward > 0.0F ? -45 : 45);
                        strafe = 0.0F;
                    } else if (strafe <= -1.0F) {
                        yaw += (forward > 0.0F ? 45 : -45);
                        strafe = 0.0F;
                    }
                    if (forward > 0.0F) {
                        forward = 1.0F;
                    } else if (forward < 0.0F) {
                        forward = -1.0F;
                    }
                }
                double mx2 = Math.cos(Math.toRadians(yaw + 90.0F));
                double mz2 = Math.sin(Math.toRadians(yaw + 90.0F));
                double motionX = forward * this.var3 * mx2 + strafe * this.var3 * mz2;
                double motionZ = forward * this.var3 * mz2 - strafe * this.var3 * mx2;
                e.x = (forward * this.var3 * mx2 + strafe * this.var3 * mz2);
                e.z = (forward * this.var3 * mz2 - strafe * this.var3 * mx2);
                var4 = true;
                mc.thePlayer.stepHeight = 0.6F;
                if ((forward == 0.0F) && (strafe == 0.0F)) {
                    e.x = 0.0D;
                    e.z = 0.0D;
                } else {
                    if (forward != 0.0F) {
                        if (strafe >= 1.0F) {
                            yaw += (forward > 0.0F ? -45 : 45);
                            strafe = 0.0F;
                        } else if (strafe <= -1.0F) {
                            yaw += (forward > 0.0F ? 45 : -45);
                            strafe = 0.0F;
                        }
                        if (forward > 0.0F) {
                            forward = 1.0F;
                        } else if (forward < 0.0F) {
                            forward = -1.0F;
                        }
                    }
                }
            }
        }
    }

    public static AxisAlignedBB axb;

    public static int var1 = 1;
    public static boolean var2;
    public static double var3 = 0.2873D;
    public static boolean var4;
    public static double var5;
    public static double var6;
    public static boolean var7;
    public static boolean var8;
    public static float var9 = 1.3F;
    public static int var10;
    public static boolean var11 = true;
    public static int var12;
    public static int var13;

    public static boolean checker() {
        if ((mc.thePlayer.isCollidedHorizontally) && (!mc.thePlayer.movementInput.jump)) {
            return false;
        }
        return true;
    }

    public void doSpeed() {
        if (!checker()) {
            return;
        }
        if (mc.thePlayer.isInWater()) {
            return;
        }
        if ((mc.thePlayer.fallDistance > 0.4D) && (!mc.thePlayer.movementInput.jump)) {
            return;
        }
        if ((!mc.thePlayer.movementInput.jump) && (this.var12 < 1) && (!mc.thePlayer.isCollidedHorizontally)) {
            mc.thePlayer.posY = mc.thePlayer.posY + 1 - 1;
        }
        if ((this.var11) && (!mc.gameSettings.keyBindJump.pressed) && (!mc.thePlayer.isOnLadder())
                && (!mc.thePlayer.isInWater()) && (!mc.thePlayer.isInsideOfMaterial(Material.lava))
                && (!mc.thePlayer.isInWater())
                && ((!(Block(-1.1D) instanceof BlockAir))
                || ((!(Block(-0.1D) instanceof BlockAir)) && (mc.thePlayer.motionX != 0.0D)
                && (mc.thePlayer.motionZ != 0.0D) && (this.var11) && (!mc.thePlayer.onGround)
                && (mc.thePlayer.fallDistance < 3.0F) && (mc.thePlayer.fallDistance > 0.05D)))
                && (this.var1 == 3)) {
            mc.thePlayer.motionY = -9.5D;
        }
        this.var13 += 1;
        int n = !mc.thePlayer.onGround ? ++this.var12 : 0;
        this.var12 = n;
        String currentMode = "";
        double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        this.var5 = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static Block Blockstates(AxisAlignedBB bb2) {
        int y2 = (int) bb2.minY;
        int x2 = MathHelper.floor_double(bb2.minX);
        while (x2 < MathHelper.floor_double(bb2.maxX) + 1) {
            int z2 = MathHelper.floor_double(bb2.minZ);
            while (z2 < MathHelper.floor_double(bb2.maxZ) + 1) {
                Block block = mc.theWorld.getBlockState(new BlockPos(x2, y2, z2)).getBlock();
                if (block != null) {
                    return block;
                }
                z2++;
            }
            x2++;
        }
        return null;
    }

    public static Block Block(double offset) {
        return Blockstates(mc.thePlayer.getEntityBoundingBox().offset(0.0D, offset, 0.0D));
    }

    private void combatMode() {
        for (Object o : mc.theWorld.loadedEntityList) {
            if (o instanceof EntityLivingBase) {
                if (o != mc.thePlayer) {
                    EntityLivingBase e = (EntityLivingBase) o;
                    if (mc.thePlayer.getDistanceToEntity(e) <= 3.9) {
                        mc.timer.timerSpeed = 1F;
                    }
                }
            }
        }
    }

    public void onDisable() {
        mc.timer.timerSpeed = 1F;
        mc.thePlayer.jumpMovementFactor = 0.02F;
        mc.thePlayer.speedInAir = 0.02F;
    }

    public double getBaseMoveSpeed() {
        double basevar13 = 0.2873D;
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            basevar13 *= (1.0D + 0.2D * (amplifier + 1));
        }
        return basevar13;
    }

}
