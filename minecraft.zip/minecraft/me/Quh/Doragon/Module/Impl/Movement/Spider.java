package me.Quh.Doragon.Module.Impl.Movement;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Spider extends Module {

    public Spider() {
        super("Spider", Keyboard.KEY_NONE, Category.MOVEMENT);

    }

    public void onTick() {
        if (mc.thePlayer.isCollidedHorizontally) {
            mc.thePlayer.motionY = +0.1D;
            mc.thePlayer.onGround = true;
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));

        }
    }

}
