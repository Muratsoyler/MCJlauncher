package me.Quh.Doragon.Module.Impl.Movement;

import java.util.ArrayList;

import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;

public class NoSlowDown extends Module {

	public NoSlowDown() {
		super("NoSlowDown", Keyboard.KEY_NONE,  Category.MOVEMENT);

	}

	@Override
	public void setup() {
		ArrayList<String> mode = new ArrayList();
		mode.add("Vanilla");
		mode.add("Packets");
		Doragon.settingsManager.rSetting(new Setting("NoSlowDown Mode", this, "Vanilla", mode));
	}

	public void onEvent(Event event) {
		if(event instanceof EventOnUpdate) {
			if (Doragon.settingsManager.getSettingByName("NoSlowDown Mode").getValString().equalsIgnoreCase("Vanilla")) {
				this.setSuffix(" | Vanilla");
				if (mc.thePlayer.moveForward != 0 && mc.thePlayer.isBlocking() || mc.thePlayer.isUsingItem()) {
				}

				if (mc.thePlayer.moveForward != 0 && mc.thePlayer.isBlocking() || mc.thePlayer.isUsingItem()) {
				}
			}
			if (Doragon.settingsManager.getSettingByName("NoSlowDown Mode").getValString().equalsIgnoreCase("Packets")) {
				this.setSuffix(" | Packets");
				if(!mc.thePlayer.onGround && mc.thePlayer.isBlocking() || mc.thePlayer.isUsingItem() && !mc.thePlayer.onGround){
					mc.thePlayer.onGround = true;
					for(int i = 0; i < 5; i++){
						mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
					}
					mc.thePlayer.jumpMovementFactor = 0.1F;
				}
			}
		}
	}

	public void onEnable() {
		if (mc.thePlayer.isBlocking()) {
			mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(new BlockPos(0, 0, 0), 1,
					mc.thePlayer.getCurrentEquippedItem(), 0.0F, 0.0F, 0.0F));
		}
	}

}
