package me.Quh.Doragon.Module.Impl.Movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;

public class Fly extends Module {

    public Fly() {
        super("Fly", Keyboard.KEY_NONE, Category.MOVEMENT);

    }

    public void setup() {
        ArrayList<String> mode = new ArrayList<>();
        mode.add("VanillaFly");
        mode.add("CubecraftFly");
        Doragon.settingsManager.rSetting(new Setting("Fly Mode", this, "VanillaFly", mode));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (Doragon.settingsManager.getSettingByName("Fly Mode").getValString().equalsIgnoreCase("VanillaFly")) {
                mc.thePlayer.capabilities.isFlying = true;
                mc.thePlayer.capabilities.setFlySpeed(0.1F);
            }
            if (Doragon.settingsManager.getSettingByName("Fly Mode").getValString().equalsIgnoreCase("CubecraftFly")) {
                if (mc.gameSettings.keyBindForward.pressed == true && !mc.thePlayer.onGround) {
                    mc.thePlayer.motionY = 0.0;
                    mc.thePlayer.jumpMovementFactor = 0.2F;
                }
                if (mc.thePlayer.onGround) {
                    mc.timer.timerSpeed = 1.0F;
                } else {
                    mc.timer.timerSpeed = 0.3F;
                }
                if (mc.gameSettings.keyBindJump.pressed == true) {
                    mc.thePlayer.motionY += 0.3;
                }
                if (mc.gameSettings.keyBindSneak.pressed == true) {
                    mc.thePlayer.motionY -= 0.3;
                }
            }
        }
    }

    public void onDisable() {
        mc.thePlayer.capabilities.isFlying = false;
        mc.thePlayer.speedInAir = 0.02F;
        mc.timer.timerSpeed = 1.0F;
    }

}
