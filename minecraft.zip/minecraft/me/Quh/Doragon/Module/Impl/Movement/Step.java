package me.Quh.Doragon.Module.Impl.Movement;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.TimeHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;

public class Step extends Module {

    public Step() {
        super("Step", Keyboard.KEY_NONE, Category.MOVEMENT);

    }

    TimeHelper time = new TimeHelper();

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("Step Height", this, 1.0, 1.0, 5.0, false));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if ((mc.thePlayer.isCollidedHorizontally)
                    && ((this.mc.gameSettings.keyBindForward.pressed) || (this.mc.gameSettings.keyBindBack.pressed)
                    || (this.mc.gameSettings.keyBindRight.pressed)
                    || (this.mc.gameSettings.keyBindLeft.pressed))
                    && (mc.thePlayer.onGround) && (!this.mc.thePlayer.isOnLadder())) {
                mc.thePlayer.motionY += 0.67831111D;
                mc.thePlayer.onGround = true;
            } else {
                mc.thePlayer.stepHeight = 0.5F;
            }
        }
    }

    public void onDisable() {
        mc.thePlayer.stepHeight = 0.5F;
    }
}
