package me.Quh.Doragon.Module.Impl.Movement;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;

public class Sprint extends Module {

    public Sprint() {
        super("Sprint", Keyboard.KEY_NONE, Category.MOVEMENT);

    }

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("MultiDir", this, false));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (!Doragon.settingsManager.getSettingByName("MultiDir").getValBoolean()) {
                if (mc.gameSettings.keyBindForward.pressed) {
                    mc.thePlayer.setSprinting(true);
                }
            }
        }
        if (Doragon.settingsManager.getSettingByName("MultiDir").getValBoolean()) {
            if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed || mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

}
