/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Module.Module;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class Headless extends Module{
    
    public Headless() {
        super("Derp", Keyboard.KEY_NONE, Category.FUN);
    }
    
    public void onTick(){
        mc.thePlayer.sendQueue
			.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook((float)Math
				.sin(mc.thePlayer.ticksExisted % 20 / 10d
					* Math.PI) * 180, (float)Math.sin(mc.thePlayer.ticksExisted % 20 / 10D * Math.PI) * 180,
				mc.thePlayer.onGround));
        //mc.thePlayer.sendQueue
	//		.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(mc.thePlayer.rotationYaw, 180F, mc.thePlayer.onGround));
        //mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook((float)Math
	//			.sin(mc.thePlayer.ticksExisted % 20 / 10d
	//				* Math.PI) * 180, (float)Math.sin(mc.thePlayer.ticksExisted % 20 / 10D * Math.PI) * 90, mc.thePlayer.onGround));
    }
    
}
