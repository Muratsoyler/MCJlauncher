package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Keyboard;

public class SuperBedBreaker extends Module{
    public SuperBedBreaker() {
        super("SuperBedBreaker", Keyboard.KEY_NONE, me.Quh.Doragon.Module.Category.FUN);
    }

    public boolean stop = false;

    public void onEvent(Event event){
            if(mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && mc.thePlayer.isSwingInProgress){
                BlockPos pos = mc.objectMouseOver.func_178782_a();
                if(mc.theWorld.getBlockState(pos).getBlock() == Blocks.bed){
                    for(int i = 0; i < 5; i++){
                        mc.thePlayer.motionY = 0.4;
                        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(pos.getX(),pos.getY() + 1,pos.getZ(),true));
                        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK,pos, EnumFacing.DOWN));
                    }
                }
            }
            if(stop){
                message("Bed was breaked, Module toggled off",true);
                this.toggle();
                stop = false;
            }
    }
}
