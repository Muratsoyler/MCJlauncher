package me.Quh.Doragon.Module.Impl.Fun;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;

public class SlowMotion extends Module {

    public SlowMotion() {
        super("SlowMotion", Keyboard.KEY_NONE, Category.FUN);

    }

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("SlowMotion Value", this, 0.50, 0.1, 0.99, false));
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (!mc.thePlayer.onGround) {
                mc.timer.timerSpeed = ((float) Doragon.settingsManager.getSettingByName("SlowMotion Value").getValDouble());
            } else {
                mc.timer.timerSpeed = 1F;
            }
        }
    }

    public void onDisable() {
        mc.timer.timerSpeed = 1F;
    }

}
