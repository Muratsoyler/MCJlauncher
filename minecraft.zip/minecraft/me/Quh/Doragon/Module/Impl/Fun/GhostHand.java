package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventCollideCheck;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import net.minecraft.block.*;
import org.lwjgl.input.Keyboard;

public class GhostHand extends Module{
    public GhostHand() {
        super("GhostHand", Keyboard.KEY_NONE, me.Quh.Doragon.Module.Category.FUN);
    }

    public void onEvent(Event event){
        if(event instanceof EventCollideCheck){
            EventCollideCheck ecc = (EventCollideCheck)event;
            if(!(ecc.block instanceof BlockChest) && !(ecc.block instanceof BlockEnderChest) && !(ecc.block instanceof BlockSign) && !(ecc.block instanceof BlockWorkbench) && !(ecc.block instanceof BlockDoor) && !(ecc.block instanceof BlockBed)){
                ecc.setCollide(false);
            }
        }
    }
}
