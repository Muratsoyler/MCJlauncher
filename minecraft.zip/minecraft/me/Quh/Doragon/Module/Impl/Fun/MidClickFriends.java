/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Module.Module;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class MidClickFriends extends Module{
    
    public MidClickFriends() {
        super("MidClickFriends", Keyboard.KEY_NONE, Category.FUN);
    }
    
}
