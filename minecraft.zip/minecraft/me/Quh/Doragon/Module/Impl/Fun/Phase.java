/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class Phase extends Module {

    public Phase() {
        super("Phase", Keyboard.KEY_NONE, Category.FUN);
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            BlockPos blockremove1 = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY + 1, mc.thePlayer.posZ);
            BlockPos blockremove2 = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY + 1, mc.thePlayer.posZ);
            mc.theWorld.setBlockToAir(new BlockPos(new Vec3(mc.thePlayer.posX + 1, mc.thePlayer.posY, mc.thePlayer.posZ + 1)));
            mc.theWorld.setBlockToAir(new BlockPos(new Vec3(mc.thePlayer.posX + 1, mc.thePlayer.posY + 1, mc.thePlayer.posZ + 1)));
        }
    }

}
