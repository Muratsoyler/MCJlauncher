/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class HighJump extends Module {

    public HighJump() {
        super("HighJump", Keyboard.KEY_NONE, Category.FUN);
    }

    double deltaY = 0.0D;

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (deltaY > 0.0D) {
                mc.thePlayer.motionY = mc.thePlayer.motionY + deltaY;
                if (mc.thePlayer != null && mc.thePlayer instanceof EntityPlayer) {
                    mc.thePlayer.motionY = mc.thePlayer.motionY + deltaY;
                    mc.thePlayer.velocityChanged = true;
                }
            }

            if (mc.thePlayer.onGround) {
                if (deltaY == 0.0D) {
                    deltaY = 0.5D;
                } else {
                    deltaY = 0.0D;
                }
            }
        }
    }
}
