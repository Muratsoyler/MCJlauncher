/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class Teleport extends Module {

    public Teleport() {
        super("Teleport", Keyboard.KEY_NONE, Category.FUN);
    }

    boolean hasTeleported;

    public void onEnable() {
        hasTeleported = false;
    }

    public void onEvent(Event event) {
        if (mc.thePlayer == null || mc.theWorld == null) {
            hasTeleported = true;
            return;
        }
        if (event instanceof EventOnUpdate) {
            if (mc.thePlayer.isSneaking() && !hasTeleported && mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY) {
                if(mc.thePlayer.onGround){
                    mc.thePlayer.motionY = 0.21;
                }
                double startPos[] = {mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ};
                double endPos[] = {mc.objectMouseOver.func_178782_a().getX() + 0.5, mc.objectMouseOver.func_178782_a().getY() + 1, mc.objectMouseOver.func_178782_a().getZ() + 0.5};
                //Start Teleporting
                if(!mc.thePlayer.onGround){
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] - 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1] + 1, endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] - 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 900, startPos[2], false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], false));
                }
                //mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], mc.thePlayer.onGround));
                //mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(startPos[0], startPos[1] + 50, startPos[2], mc.thePlayer.onGround));
                //mc.thePlayer.motionY = 0.20000000298023224;
                //mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(endPos[0], endPos[1], endPos[2], mc.thePlayer.onGround));
            }
        }
    }
}
