/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.Fun;

import java.util.ArrayList;
import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class GommeGod extends Module {

    public GommeGod() {
        super("GommeGod", Keyboard.KEY_NONE, Category.FUN);
    }

    public void setup() {
        ArrayList<String> mode = new ArrayList<>();
        mode.add("1");
        mode.add("2");
        Doragon.settingsManager.rSetting(new Setting("God - Mode", this, "1", mode));
    }
    
    int delay;

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (Doragon.settingsManager.getSettingByName("God - Mode").getValString().equalsIgnoreCase("1")) {
                if (mc.thePlayer.isSneaking()) {
                    mc.thePlayer.sendQueue.netManager.sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX + 20000, mc.thePlayer.posY - 20000, mc.thePlayer.posZ + 20000, false));
                }
            } else if (Doragon.settingsManager.getSettingByName("God - Mode").getValString().equalsIgnoreCase("2")) {
                ++this.delay;
                if (mc.thePlayer.isSneaking()) {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY += this.delay, mc.thePlayer.posZ, true));
                }
            }
        }
    }

    public void onEnable() {
        message("Sneak to activate the GodMode", true);
        delay = 0;
    }

}
