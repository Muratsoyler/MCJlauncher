package me.Quh.Doragon.Module.Impl.Player;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.network.play.client.C16PacketClientStatus;

public class AutoRespawn extends Module {

    public AutoRespawn() {
        super("AutoRespawn", Keyboard.KEY_NONE, Category.PLAYER);

    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if (mc.thePlayer.isDead || mc.thePlayer.getHealth() <= 0) {
                mc.thePlayer.respawnPlayer();
                mc.thePlayer.sendQueue.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.PERFORM_RESPAWN));
            }
        }
    }

}
