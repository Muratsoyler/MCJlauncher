package me.Quh.Doragon.Module.Impl.Player;

import me.Quh.Doragon.Utils.TimeHelper;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.block.Block;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class BedFucker extends Module {

    public BedFucker() {
        super("BedFucker", Keyboard.KEY_NONE, Category.PLAYER);
    }


    public TimeHelper time = new TimeHelper();

    public void onEvent(Event e) {
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
        if (e instanceof EventOnUpdate) {
            for (int xOffset = -5; xOffset < 6; xOffset += 1) {
                for (int zOffset = -5; zOffset < 6; zOffset += 1) {
                    for (int yOffset = 5; yOffset > -5; yOffset -= 1) {
                        double x = mc.thePlayer.posX + xOffset;
                        double y = mc.thePlayer.posY + yOffset;
                        double z = mc.thePlayer.posZ + zOffset;
                        BlockPos pos = new BlockPos(x, y, z);
                        int id = Block.getIdFromBlock(mc.theWorld.getBlockState(pos).getBlock());
                        if (id == 26 && time.isDelayComplete(700D)) {
                            mc.thePlayer.setSprinting(false);
                            smashBlock(new BlockPos(x, y, z));
                            mc.thePlayer.setSprinting(false);
                            time.setLastMS();
                            mc.thePlayer.setSprinting(false);
                        }
                    }
                }
            }
        }
    }

    public void smashBlock(BlockPos pos) {
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(getRotations(pos)[0], getRotations(pos)[1], mc.thePlayer.onGround));
        mc.thePlayer.swingItem();
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(getRotations(pos)[0], getRotations(pos)[1], mc.thePlayer.onGround));
        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(getRotations(pos)[0], getRotations(pos)[1], mc.thePlayer.onGround));
        mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(getRotations(pos)[0], getRotations(pos)[1], mc.thePlayer.onGround));
    }

    public static float[] getRotations(BlockPos pos) {
        if (pos == null) {
            return null;
        }
        double diffX = pos.getX() - mc.thePlayer.posX;
        double diffZ = pos.getZ() - mc.thePlayer.posZ;
        double diffY = pos.getY() - mc.thePlayer.getEyeHeight();
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (Math.atan2(diffY, dist) * 180.0 / 3.141592653589793) / (float) dist;
        return new float[]{
                mc.thePlayer.rotationYaw
                        + MathHelper.wrapAngleTo180_float(yaw - mc.getMinecraft().thePlayer.rotationYaw),
                mc.thePlayer.rotationPitch
                        + MathHelper.wrapAngleTo180_float(pitch - mc.getMinecraft().thePlayer.rotationPitch)};
    }

}
