package me.Quh.Doragon.Module.Impl.Player;

import net.minecraft.network.play.client.C0APacketAnimation;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.BlockData;
import me.Quh.Doragon.Utils.EntityHelper;
import me.Quh.Doragon.Utils.TimeHelper;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventPostMotion;
import me.Quh.Doragon.Event.Events.EventPreMotion;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

import java.util.ArrayList;

public class ScaffoldWalk extends Module {

    private BlockData blockData;
    private TimeHelper time;
    private int delay;

    public ScaffoldWalk() {
        super("ScaffoldWalk", Keyboard.KEY_NONE, Category.PLAYER);
        this.blockData = null;
        this.time = new TimeHelper();
    }

    @Override
    public void onEnable() {
        this.blockData = null;
        delay = 0;
    }

    public long LastBuild;
    public float yaw, pitch;

    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("Sneak", this, false));
        ArrayList<String> mode = new ArrayList<>();
        mode.add("Gomme");
        mode.add("Rewi");
        mode.add("Vanilla");
        Doragon.settingsManager.rSetting(new Setting("Scaffold - Mode",this, "Gomme",mode));
    }

    public void onTick() {
        if(Doragon.settingsManager.getSettingByName("Scaffold - Mode").getValString().equalsIgnoreCase("Gomme")) {
            mc.thePlayer.motionX /= 3F;
            mc.thePlayer.motionZ /= 3F;
        }else if(Doragon.settingsManager.getSettingByName("Scaffold - Mode").getValString().equalsIgnoreCase("Rewi")){
            mc.thePlayer.motionX /= 1.5F;
            mc.thePlayer.motionZ /= 1.5F;
        }else{
            mc.thePlayer.motionZ *= 1.05F;
            mc.thePlayer.motionX *= 1.05F;
        }
        if (Doragon.settingsManager.getSettingByName("Sneak").getValBoolean()) {
            BlockPos bp = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
            if (mc.theWorld.getBlockState(bp).getBlock() == Blocks.air) {
                mc.gameSettings.keyBindSneak.pressed = true;
            } else {
                if (time.isDelayComplete(350L)) {
                    mc.gameSettings.keyBindSneak.pressed = false;
                    time.setLastMS();
                    time.reset();
                }
            }
        }
    }

    public void onEvent(Event event) {
        if (this.mc.thePlayer.getCurrentEquippedItem() == null) {
            return;
        }
        if (this.mc.thePlayer.getCurrentEquippedItem().getItem() == Item.getItemById(0)) {
            return;
        }
        if (!(this.mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock)) {
            return;
        }
        if (event instanceof EventPreMotion) {
            if (mc.theWorld == null || mc.thePlayer == null) {
                return;
            }
            try {
                EventPreMotion e = (EventPreMotion) event;
                this.blockData = null;
                if (this.mc.thePlayer.getHeldItem() != null
                        && this.mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock) {
                    final BlockPos player = new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 1.0,
                            this.mc.thePlayer.posZ);
                    //if (this.mc.theWorld.getBlockState(player).getBlock() == Blocks.air) {
                        this.blockData = this.getBlockData(player);
                        float[] values = getFacingRotations(blockData.position.getX(), blockData.position.getY(), blockData.position.getZ(), blockData.face, true);
                        e.setYaw(values[0]);
                        e.setPitch(values[1]);
                        yaw = values[0];
                        pitch = values[1];
                    //}
                }
            } catch (Exception ex) {
            }
        }
        if (event instanceof EventPostMotion) {
            if (this.blockData == null) {
                return;
            }
            if (mc.theWorld == null || mc.thePlayer == null) {
                return;
            }
            if (this.time.isDelayComplete(75L)) {
                if (this.mc.playerController.func_178890_a(this.mc.thePlayer, this.mc.theWorld,
                        this.mc.thePlayer.getHeldItem(), this.blockData.position, this.blockData.face,
                        new Vec3(this.blockData.position.getX(), this.blockData.position.getY(),
                                this.blockData.position.getZ()))) {
                    LastBuild = System.currentTimeMillis();
                    //this.mc.thePlayer.swingItem();
                    mc.getNetHandler().addToSendQueue(new C0APacketAnimation());
                }
                this.time.reset();
            }
        }
        /*if (event instanceof EventSendPacket) {
            EventSendPacket e = (EventSendPacket) event;
            if (e.getPacket() instanceof C03PacketPlayer && isPressed()) {
                if (System.currentTimeMillis() - LastBuild < 310) {
                    if (!((C03PacketPlayer) e.getPacket()).isScaffoldOrTower) {
                        if (e.getPacket() instanceof C04PacketPlayerPosition) {
                            C04PacketPlayerPosition p = (C04PacketPlayerPosition) e.getPacket();
                            e.setPacket(new C06PacketPlayerPosLook(p.getPositionX(), p.getPositionY(), p.getPositionZ(),
                                    yaw, pitch, p.onGround));
                            return;
                        }
                        if (e.getPacket() instanceof C06PacketPlayerPosLook) {
                            C06PacketPlayerPosLook p = (C06PacketPlayerPosLook) e.getPacket();
                            e.setPacket(new C06PacketPlayerPosLook(p.getPositionX(), p.getPositionY(), p.getPositionZ(),
                                    yaw, pitch, p.onGround));
                            return;
                        }
                        e.setCancelled(true);
                    } else {
                        if (e.getPacket() instanceof C05PacketPlayerLook) {
                            C05PacketPlayerLook p = (C05PacketPlayerLook) e.getPacket();
                            e.setPacket(new C06PacketPlayerPosLook(mc.thePlayer.posX,
                                    mc.thePlayer.boundingBox.minY, mc.thePlayer.posZ, p.getYaw(),
                                    p.getPitch(), p.onGround));
                            return;
                        }
                    }
                }
            }
        }*/

    }

    public BlockData getBlockData(final BlockPos pos) {
        return (this.mc.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock() != Blocks.air)
                ? new BlockData(pos.add(0, -1, 0), EnumFacing.UP)
                : ((this.mc.theWorld.getBlockState(pos.add(-1, 0, 0)).getBlock() != Blocks.air)
                ? new BlockData(pos.add(-1, 0, 0), EnumFacing.EAST)
                : ((this.mc.theWorld.getBlockState(pos.add(1, 0, 0)).getBlock() != Blocks.air)
                ? new BlockData(pos.add(1, 0, 0), EnumFacing.WEST)
                : ((this.mc.theWorld.getBlockState(pos.add(0, 0, -1)).getBlock() != Blocks.air)
                ? new BlockData(pos.add(0, 0, -1), EnumFacing.SOUTH)
                : ((this.mc.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock() != Blocks.air)
                ? new BlockData(pos.add(0, 0, 1), EnumFacing.NORTH) : null))));
    }

    public static float[] getFacingRotations(final int x, final int y, final int z, final EnumFacing facing,
            final boolean real) {
        final EntitySnowball temp = new EntitySnowball(mc.theWorld);
        if (real) {
            switch (facing.getName()) {
                case "south": {
                    temp.posX = x + 0.5;
                    temp.posY = y + 0.5;
                    temp.posZ = z + 1;
                    break;
                }

                case "north": {
                    temp.posX = x + 0.5;
                    temp.posY = y + 0.5;
                    temp.posZ = z;
                    break;
                }

                case "west": {
                    temp.posX = x;
                    temp.posY = y + 0.5;
                    temp.posZ = z + 0.5;
                    break;
                }

                case "east": {
                    temp.posX = x + 1;
                    temp.posY = y + 0.5;
                    temp.posZ = z + 0.5;
                    break;
                }

                case "up": {
                    temp.posX = x + 0.5;
                    temp.posY = y + 0.5;
                    temp.posZ = z + 0.5;
                    break;
                }
            }
            return EntityHelper.getAngles(temp);
        } else {
            temp.posX = x + 0.5;
            temp.posY = y + 0.5;
            temp.posZ = z + 0.5;
            temp.posX += facing.getDirectionVec().getX() * 0.25;
            temp.posY += facing.getDirectionVec().getY() * 0.25;
            temp.posZ += facing.getDirectionVec().getZ() * 0.25;
            return EntityHelper.getAngles(temp);
        }
    }
}
