package me.Quh.Doragon.Module.Impl.Player;

import java.util.Objects;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.GUI.ClickGUI.ClickGUI;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.KeyBinding;

public class InventoryMove extends Module {
	public InventoryMove() {
		super("InventoryMove", Keyboard.KEY_NONE,  Category.PLAYER);
	}

	public void onEvent(Event event) {
		if (event instanceof EventOnUpdate) {
			try {
				KeyBinding[] moveKeys = { mc.gameSettings.keyBindRight, mc.gameSettings.keyBindLeft,
						mc.gameSettings.keyBindBack, mc.gameSettings.keyBindForward, mc.gameSettings.keyBindJump,
						mc.gameSettings.keyBindSprint };
				if ((mc.currentScreen instanceof GuiContainer || mc.currentScreen instanceof ClickGUI)) {
					KeyBinding[] array;
					int length = (array = moveKeys).length;
					for (int i = 0; i < length; i++) {
						KeyBinding key = array[i];
						key.pressed = Keyboard.isKeyDown(key.getKeyCode());
					}
				} else if (Objects.isNull(mc.currentScreen)) {
					KeyBinding[] array2;
					int length2 = (array2 = moveKeys).length;
					for (int j = 0; j < length2; j++) {
						KeyBinding bind = array2[j];
						if (!Keyboard.isKeyDown(bind.getKeyCode())) {
							KeyBinding.setKeyBindState(bind.getKeyCode(), false);
						}
						mc.getMinecraft();
						if ((mc.currentScreen instanceof GuiContainer)) {
							if (Keyboard.isKeyDown(200)) {
								mc.thePlayer.rotationPitch -= 2.0F;
							}
							if (Keyboard.isKeyDown(208)) {
								mc.thePlayer.rotationPitch += 2.0F;
							}
							if (Keyboard.isKeyDown(203)) {
								mc.thePlayer.rotationYaw -= 2.0F;
							}
							if (Keyboard.isKeyDown(205)) {
								mc.thePlayer.rotationYaw += 2.0F;
							}
						}
					}
				}
			} catch (Exception ex) {
			}
		}
	}

}
