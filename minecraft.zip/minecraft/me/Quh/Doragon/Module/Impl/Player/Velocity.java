package me.Quh.Doragon.Module.Impl.Player;

import java.util.ArrayList;
import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;

public class Velocity extends Module {

    public Velocity() {
        super("Velocity", Keyboard.KEY_NONE, Category.PLAYER);
    }

    public void setup() {
        ArrayList<String> mode = new ArrayList<>();
        mode.add("No Knockback");
        mode.add("Rewinside");
        mode.add("Gomme");
        mode.add("GommeReverse");
        Doragon.settingsManager.rSetting(new Setting("Knockback Mode", this, "No Knockback", mode));
    }

    public void onTick() {
        if (Doragon.settingsManager.getSettingByName("Knockback Mode").getValString().equalsIgnoreCase("Rewinside")) {
            setSuffix(" | Rewinside");
        } else if (Doragon.settingsManager.getSettingByName("Knockback Mode").getValString().equalsIgnoreCase("No Knockback")) {
            setSuffix(" | No Knockback");
        } else if (Doragon.settingsManager.getSettingByName("Knockback Mode").getValString().equalsIgnoreCase("Gomme")) {
            setSuffix(" | Gomme");
            if (mc.thePlayer.hurtTime > 0 && mc.thePlayer.fallDistance < 3) {
                if (mc.thePlayer.moveForward == 0 && mc.thePlayer.moveStrafing == 0) {
                    mc.thePlayer.motionY -= 1.001D;
                    mc.thePlayer.motionX *= 0.2D;
                    mc.thePlayer.motionZ *= 0.2D;
                    mc.thePlayer.motionY += 1D;
                } else {
                    mc.thePlayer.motionY -= 1D;
                    mc.thePlayer.motionX *= 0.5D;
                    mc.thePlayer.motionZ *= 0.5D;
                    mc.thePlayer.motionY += 1D;
                }
            }
        } else if (Doragon.settingsManager.getSettingByName("Knockback Mode").getValString().equalsIgnoreCase("GommeReverse")) {
            if (mc.thePlayer.hurtTime > 0 && mc.thePlayer.fallDistance < 3) {
                double yaw = mc.thePlayer.rotationYawHead;
                yaw = Math.toRadians(yaw);
                double X = (-Math.sin(yaw)) * 0.6;
                double Z = Math.cos(yaw) * 0.6;
                mc.thePlayer.motionX = X;
                mc.thePlayer.motionZ = Z;
            }
        }
    }

}
