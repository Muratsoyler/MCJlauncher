package me.Quh.Doragon.Module.Impl.Player;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventPostMotion;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import net.minecraft.item.*;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

public class FastUse extends Module{
    public FastUse() {
        super("FastUse", Keyboard.KEY_NONE, Category.PLAYER);
    }

    @Override
    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("UseDelay", this, 15,1,20,false));
    }

    public void onEvent(Event event){
        if(event instanceof EventPostMotion){
            int delay = (int)Doragon.settingsManager.getSettingByName("UseDelay").getValDouble();
            if(isUsable(mc.thePlayer.getCurrentEquippedItem()) && mc.thePlayer.getItemInUseDuration() > delay * 2){
                for(int i = 0; i < 25; ++i){
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer(mc.thePlayer.onGround));
                }
                mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(0,0,0), EnumFacing.DOWN));
                mc.thePlayer.stopUsingItem();
            }
        }
    }

    public boolean isUsable(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        if (mc.thePlayer.isUsingItem()) {
            if (stack.getItem() instanceof ItemFood) {
                return true;
            }
            if (stack.getItem() instanceof ItemPotion) {
                return true;
            }
            if (stack.getItem() instanceof ItemBucketMilk) {
                return true;
            }
        }
        return false;
    }

}
