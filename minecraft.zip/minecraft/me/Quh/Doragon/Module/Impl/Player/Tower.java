package me.Quh.Doragon.Module.Impl.Player;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class Tower extends Module {

    public Tower() {
        super("Tower", Keyboard.KEY_NONE, Category.PLAYER);

    }

    public boolean dont = false;
    public int i = 0;

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            if(mc.gameSettings.keyBindSneak.pressed){
                return;
            }
            if(dont){
                return;
            }
            if(mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock){
                if(i == 0){
                    mc.timer.timerSpeed = 1.5F;
                    i = 1;
                }else{
                    mc.timer.timerSpeed = 1F;
                    i = 0;
                }
                BlockPos playerPos = new BlockPos(mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ);
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(mc.thePlayer.rotationYaw, 90F, mc.thePlayer.onGround));
                if(mc.theWorld.isAirBlock(playerPos.offsetDown()) && !mc.theWorld.isAirBlock(playerPos.offsetDown(2))){
                    if(mc.playerController.func_178890_a(mc.thePlayer, mc.theWorld,mc.thePlayer.getHeldItem(),playerPos.offsetDown(2),EnumFacing.UP, new Vec3(0.5D, 1D, 0.5D))){
                        mc.getNetHandler().addToSendQueue(new C0APacketAnimation());
                        mc.thePlayer.motionY = -0.1D;
                    }else if(mc.thePlayer.onGround){
                        mc.thePlayer.jump();
                        mc.thePlayer.motionX = (mc.thePlayer.motionZ = 0D);
                        dont = true;
                        dont = false;
                    }
                }else if(mc.thePlayer.onGround){
                        mc.thePlayer.jump();
                        mc.thePlayer.motionX = (mc.thePlayer.motionZ = 0D);
                        dont = true;
                        mc.thePlayer.onUpdate();
                        dont = false;
                }
            }
        }
    }

    public void onDisable(){
        mc.timer.timerSpeed = 1F;
    }
}
