package me.Quh.Doragon.Module.Impl.Player;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.network.play.client.C03PacketPlayer;

public class SetBack extends Module {

	public SetBack() {
		super("SetBack", Keyboard.KEY_NONE,  Category.PLAYER);

	}

	public void onEvent(Event event) {
		if (event instanceof EventOnUpdate) {
			this.setSuffix("");
			if (mc.thePlayer.fallDistance > 3.0F) {
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX,
						mc.thePlayer.posY + 0.1625F, mc.thePlayer.posZ, true));
			}
		}
	}

}
