/*
All rights goes to Quh
*/
package me.Quh.Doragon.Module.Impl.Player;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author Quh
 */
public class Scaffold extends Module {

    public Scaffold() {
        super("Scaffold", Keyboard.KEY_NONE, Category.PLAYER);
    }

    public void onEvent(Event event) {
        if (event instanceof EventOnUpdate) {
            BlockPos belowPlayer = new BlockPos(mc.thePlayer).offsetDown();
            if ((!mc.theWorld.getBlockState(belowPlayer).getBlock().getMaterial().isReplaceable()) || mc.thePlayer.getHeldItem() == null || (!(mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock))) {
                return;
            }
            placeBlockLegit(belowPlayer);
        }
    }

    public static int sneakdelay = 0;

    public static boolean placeBlockLegit(BlockPos pos) {
        Vec3 eyesPos = new Vec3(mc.thePlayer.posX,
                mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
        EnumFacing[] arrayOfEnumFacing;
        int j = (arrayOfEnumFacing = EnumFacing.values()).length;
        for (int i = 0; i < j; i++) {
            EnumFacing side = arrayOfEnumFacing[i];
            BlockPos neighbor = pos.offset(side);
            EnumFacing side2 = side.getOpposite();
            if (mc.theWorld.getBlockState(neighbor).getBlock().canCollideCheck(mc.theWorld.getBlockState(neighbor), false)) {
                Vec3 hitVec = new Vec3(neighbor.getX(), neighbor.getY(), neighbor.getZ()).addVector(0.5D, 0.5D, 0.5D).add(new Vec3(side2.getDirectionVec().getX(), side2.getDirectionVec().getY(), side2.getDirectionVec().getZ()).scale(0.5D));
                if (eyesPos.squareDistanceTo(hitVec) <= 20.0625D) {
                    faceVectorPacket(hitVec);
                    sneakdelay += 1;
                    if (sneakdelay >= 4) {
                        mc.playerController.func_178890_a(mc.thePlayer, mc.theWorld,
                                mc.thePlayer.getCurrentEquippedItem(), neighbor, side2, hitVec);
                        mc.rightClickDelayTimer = 4;
                        mc.thePlayer.swingItem();
                        sneakdelay = 0;
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private static void faceVectorPacket(Vec3 vec) {
        double diffX = vec.xCoord - mc.thePlayer.posX;
        double diffY = vec.yCoord - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double diffZ = vec.zCoord - mc.thePlayer.posZ;

        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, dist));

        mc.getNetHandler()
                .addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(yaw, pitch, mc.thePlayer.onGround));
    }

}
