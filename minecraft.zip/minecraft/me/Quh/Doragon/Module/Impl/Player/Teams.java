package me.Quh.Doragon.Module.Impl.Player;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.ScorePlayerTeam;

public class Teams extends Module {
	public Teams() {
		super("Teams", Keyboard.KEY_NONE,  Category.PLAYER);
	}

	public static boolean enabled;

	public static boolean isinTeam(EntityLivingBase entityplayer) {
		return Doragon.moduleManager.getModule(Teams.class).isEnabled() && entityplayer instanceof EntityPlayer
				&& getTeamColor((EntityPlayer) entityplayer) == getTeamColor(mc.thePlayer);
	}

	public static boolean isenabled(){
		return enabled;
	}

	public static int getTeamColor(EntityPlayer player) {
		int color = 16777215;
		ScorePlayerTeam scoreplayerteam = (ScorePlayerTeam) player.getTeam();
		if (scoreplayerteam != null) {
			String s = FontRenderer.getFormatFromString(scoreplayerteam.getColorPrefix());
			if (s.length() >= 2) {
				color = mc.fontRendererObj.func_175064_b(s.charAt(1));
			}
		}

		return color;
	}
}
