package me.Quh.Doragon.Module.Impl.Player;

import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnUpdate;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import org.lwjgl.input.Keyboard;

public class FastLadder extends Module{
    public FastLadder() {
        super("FastLadder", Keyboard.KEY_NONE, me.Quh.Doragon.Module.Category.PLAYER);
    }

    public void onEvent(Event event){
        if(event instanceof EventOnUpdate){
            if(mc.thePlayer.isOnLadder() && !mc.gameSettings.keyBindSneak.pressed){
                mc.thePlayer.motionY = 0.17;
            }else if(mc.thePlayer.isOnLadder() && mc.gameSettings.keyBindSneak.pressed){
                mc.thePlayer.setPosition(mc.thePlayer.posX,mc.thePlayer.posY - 0.17,mc.thePlayer.posZ);
            }
        }
    }
}
