package me.Quh.Doragon.Module.Impl.Player;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventBlockBreaking;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.TimeHelper;
import net.minecraft.block.Block;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;

public class SpeedMine extends Module{

    public SpeedMine() {
        super("SpeedMine", Keyboard.KEY_NONE, Category.PLAYER);
    }

    TimeHelper time = new TimeHelper();

    @Override
    public void setup() {
        Doragon.settingsManager.rSetting(new Setting("Instant",this,false));
        Doragon.settingsManager.rSetting(new Setting("AutoTool",this,false));
        Doragon.settingsManager.rSetting(new Setting("BlockDelay", this, 3, 0, 5, false));
        Doragon.settingsManager.rSetting(new Setting("BreakMultiplier", this, 3, 1, 5, false));
    }

    public void onEvent(Event event){
        if(event instanceof EventBlockBreaking){
            boolean shouldSend = true;
            EventBlockBreaking e = (EventBlockBreaking)event;
            if(e.getState() == EventBlockBreaking.EnumBlock.CLICK){
                time.setLastMS();
                shouldSend = true;
                if(Doragon.settingsManager.getSettingByName("AutoTool").getValBoolean()){
                    bestTool(e.getPos().getX(),e.getPos().getY(),e.getPos().getZ());
                }
            }
            if(time.hasReached(55L)){
                shouldSend = false;
            }
            if(Doragon.settingsManager.getSettingByName("Instant").getValBoolean()){
                if(mc.gameSettings.keyBindAttack.pressed && time.hasReached(25L) && shouldSend){
                    mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, e.getPos(), e.getSide()));
                }
            }else{
                e.setDelay((int)Doragon.settingsManager.getSettingByName("BlockDelay").getValDouble());
                e.setMultiplier((int)Doragon.settingsManager.getSettingByName("BreakMultiplier").getValDouble());
            }
        }
    }

    public static void bestTool(final int x, final int y, final int z) {
        final int blockId = Block.getIdFromBlock(mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock());
        int bestSlot = 0;
        float f = -1.0f;
        for (int i1 = 36; i1 < 45; ++i1) {
            try {
                final ItemStack curSlot = mc.thePlayer.inventoryContainer.getSlot(i1).getStack();
                if ((curSlot.getItem() instanceof ItemTool || curSlot.getItem() instanceof ItemSword || curSlot.getItem() instanceof ItemShears) && curSlot.getStrVsBlock(Block.getBlockById(blockId)) > f) {
                    bestSlot = i1 - 36;
                    f = curSlot.getStrVsBlock(Block.getBlockById(blockId));
                }
            }
            catch (Exception ex) {}
        }
        if (f != -1.0f) {
            mc.thePlayer.inventory.currentItem = bestSlot;
            mc.playerController.updateController();
        }
    }
    
}
