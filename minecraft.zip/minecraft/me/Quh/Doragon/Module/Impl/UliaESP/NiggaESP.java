/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Module.Impl.UliaESP;

import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Event.Event;
import me.Quh.Doragon.Event.Events.EventOnRender;
import me.Quh.Doragon.Utils.ImageESPUtil;
import org.lwjgl.input.Keyboard;

/**
 *
 * @author admin
 */
public class NiggaESP extends Module{
    
    public NiggaESP() {
        super("NiggaESP", Keyboard.KEY_NONE, Category.ULIAESP);
    }
    
    public void onEvent(Event event){
        if(event instanceof EventOnRender){
            ImageESPUtil.onRenderMethod("Doragon/ESP/Nigga.jpg");
        }
    }
    
}
