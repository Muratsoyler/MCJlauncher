package me.Quh.Doragon.Module;

public enum Category {

	MOVEMENT, COMBAT, RENDER, CONFIG, PLAYER, FUN, GUI, ULIAESP

}
