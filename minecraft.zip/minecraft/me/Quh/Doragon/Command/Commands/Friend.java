/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Command.Commands;

import me.Quh.Doragon.Command.Command;
import me.Quh.Doragon.Friend.FriendUtil;
import net.minecraft.util.ChatComponentText;

/**
 *
 * @author admin
 */
@Command.CommandInformation(name = "Friend",aliases = "F")
public class Friend implements Command{

    @Override
    public void execute(String[] args) {
      if(args.length == 0 || args.length == 1){
          chat.printChatMessage(new ChatComponentText(prefix + ".Friend <Add/Del> <Name>"));
          return;
      }
      if(args.length == 2){
          if(args[0].equalsIgnoreCase("add")){
              if(!FriendUtil.isAFriend(args[1])){
                  FriendUtil.addWithoutAlias(args[1]);
                  chat.printChatMessage(new ChatComponentText(prefix + "Added " + args[1] + "as Friend."));
                  return;
              }
          }else if(args[0].equalsIgnoreCase("del")){
              if(FriendUtil.isAFriend(args[1])){
                  FriendUtil.removeFriend(args[1]);
                  chat.printChatMessage(new ChatComponentText(prefix + "Removed " + args[1] + "as Friend."));
                  return;
              }
          }
      }
    }
    
}
