/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Command.Commands;

import me.Quh.Doragon.Command.Command;
import me.Quh.Doragon.Command.CommandManager;
import net.minecraft.util.ChatComponentText;

/**
 *
 * @author admin
 */
@Command.CommandInformation(name = "Help",aliases = "H")
public class Help implements Command{

    @Override
    public void execute(String[] args) {
        chat.printChatMessage(new ChatComponentText(prefix + "All Commands: "));
        for(Command c : CommandManager.commands){
            chat.printChatMessage(new ChatComponentText(prefix + "." + getName(c)));
        }
    }
    
    public String getName(Command c){
       if(c.getClass().isAnnotationPresent(CommandInformation.class)){
           return c.getClass().getAnnotation(CommandInformation.class).name();
       }
       return null;
   }
    
}
