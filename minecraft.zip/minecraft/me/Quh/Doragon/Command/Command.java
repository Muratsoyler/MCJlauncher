/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Command;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import me.Quh.Doragon.Doragon;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiNewChat;

/**
 *
 * @author admin
 */
public interface Command {

    Minecraft mc = Minecraft.getMinecraft();
    GuiNewChat chat = Minecraft.getMinecraft().ingameGUI.getChatGUI();
    
    String prefix = Doragon.clientPrefix;

    void execute(String[] args);

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    @interface CommandInformation {
        String name();
        String[] aliases();
    }
    
   
}
