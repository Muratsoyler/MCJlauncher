/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Command;

import java.util.ArrayList;
import java.util.List;
import me.Quh.Doragon.Command.Commands.*;

/**
 *
 * @author admin
 */
public class CommandManager {

    public static List<Command> commands = new ArrayList<>();

    public CommandManager() {
        add(new Help());
        add(new Friend());
    }

    public void add(Command c) {
        commands.add(c);
    }

    public boolean execute(String rawText) {
        if (!rawText.startsWith(".")) {
            return false;
        }
        rawText = rawText.substring(1);
        for (Command cmd : commands) {
            if (cmd.getClass().isAnnotationPresent(Command.CommandInformation.class)) {
                Command.CommandInformation information = cmd.getClass().getAnnotation(Command.CommandInformation.class);

                String[] args = rawText.split(" ");

                List<String> activatoras = new ArrayList<>();
                activatoras.add(information.name());
                for (String str : information.aliases()) {
                    activatoras.add(str);
                }
                for (String str : activatoras) {
                    if (args[0].equalsIgnoreCase(str)) {
                        String[] argsNew = new String[args.length - 1];
                        System.arraycopy(args, 1, argsNew, 0, args.length - 1);
                        cmd.execute(argsNew);
                    }
                }
            }
        }
        return true;
    }

}
