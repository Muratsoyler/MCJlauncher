package me.Quh.Doragon.GUI.TabGui;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class TabGuiKey {

    public void onKeyPress() throws InterruptedException {
        int keyPressed = Keyboard.getEventKey();
        if (keyPressed == 208) {
            Doragon.tabGui.down();
        }
        if (keyPressed == 200) {
            Doragon.tabGui.up();
        }
        if (keyPressed == 203) {
            Doragon.tabGui.left();
        }
        if (keyPressed == 205) {
            Doragon.tabGui.right();
        }
        if (keyPressed == 28) {
            Doragon.tabGui.enter();
        }
    }
}
