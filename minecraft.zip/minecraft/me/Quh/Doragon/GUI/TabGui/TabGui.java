package me.Quh.Doragon.GUI.TabGui;

import java.awt.Font;
import java.util.ArrayList;

import me.Quh.Doragon.TTF.FontUtils;
import net.minecraft.client.gui.FontRenderer;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Category;
import me.Quh.Doragon.Module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

public class TabGui{

    private ArrayList<String> category = new ArrayList();
    private FontRenderer fr;
    private int selectedTab;
    private int selectedMod;
    int borderUnten;
    public static TabGuiKey tabGuiKey = new TabGuiKey();
    public static int categoryXSize = 55;
    int cSlide;
    int mSlide;
    int borderOben;
    private boolean mainMenu;
    private int modBorder1;
    private int modBorder2;
    private int index;

    private FontUtils font = new FontUtils("Comfortaa Bold", Font.BOLD,20);

    public TabGui() {
        this.fr = Minecraft.getMinecraft().fontRendererObj;
        this.borderUnten = 21;
        this.cSlide = 0;
        this.mSlide = 0;
        this.borderOben = 33;
        this.mainMenu = true;
        this.modBorder1 = 8;
        this.modBorder2 = 20;
        this.index = 0;
        Category[] arrayOfCategory = {Category.COMBAT, Category.CONFIG, Category.FUN, Category.MOVEMENT, Category.PLAYER, Category.RENDER};
        int j = arrayOfCategory.length;
        int i = 0;
        while (i < j) {
            Category mc = arrayOfCategory[i];
            this.category.add(String.valueOf(mc.toString().substring(0, 1)) + mc.toString().substring(1, mc.toString().length()).toLowerCase());
            ++i;
        }
    }

    public void drawTabGui() {
        int color = 0xff990000;
        int categoryCount = 0;
        if (this.cSlide < 0) {
            ++this.cSlide;
            ++this.cSlide;
        } else if (this.cSlide > 0) {
            --this.cSlide;
            --this.cSlide;
        }
        Gui.drawRect(2, 61, categoryXSize + 20, 61 + this.category.size() * 11, -251658240);
        Gui.drawRect(1, this.borderUnten + this.cSlide - 1 + 40, 76, this.borderOben + this.cSlide + 40, color);
        for (String s : this.category) {
            font.drawStringWithShadow(categoryCount == this.selectedTab ? s : s, 6.0f, 60 + categoryCount * 11, -1);
            ++categoryCount;
        }
        if (!this.mainMenu) {
            if (this.mSlide < 0) {
                ++this.mSlide;
                ++this.mSlide;
            } else if (this.mSlide > 0) {
                --this.mSlide;
                --this.mSlide;
            }
            Gui.drawRect(78, 61, 100 + this.getLongestModWidth(), 62 + this.getModsForCategory().size() * 11, -251658240);
            int modCount = 0;
            Gui.drawRect(77, this.modBorder1 + this.mSlide - 1 + 53, 101 + this.getLongestModWidth(), this.modBorder2 + this.mSlide + 53, color);
            for (Module mod : this.getModsForCategory()) {
                String name = mod.isEnabled() ? mod.getName() : (modCount == this.selectedMod ? mod.getName() : mod.getName());
                font.drawStringWithShadow(name, 82.0f, 60 + modCount * 11, mod.isEnabled() ? -1 : 8421504);
                ++modCount;
            }
        }
    }

    public void down() throws InterruptedException {
        if (this.mainMenu) {
            if (this.selectedTab >= this.category.size() - 1) {
                this.selectedTab = -1;
                this.borderUnten = 10;
                this.borderOben = 22;
            }
            ++this.selectedTab;
            this.cSlide = -10;
            this.mSlide = 0;
            this.borderUnten += 11;
            this.borderOben += 11;
        } else {
            if (this.selectedMod >= this.getModsForCategory().size() - 1) {
                this.selectedMod = -1;
                this.modBorder1 = -3;
                this.modBorder2 = 9;
            }
            ++this.selectedMod;
            this.mSlide = -10;
            this.modBorder1 += 11;
            this.modBorder2 += 11;
        }
    }

    public void up() {
        if (this.mainMenu) {
            if (this.selectedTab <= 0) {
                this.selectedTab = this.category.size();
                this.borderUnten = 87;
                this.borderOben = 99;
            }
            --this.selectedTab;
            this.cSlide = 10;
            this.borderUnten -= 11;
            this.borderOben -= 11;
        } else {
            if (this.selectedMod <= 0) {
                this.selectedMod = this.getModsForCategory().size();
                this.modBorder1 = 9 + this.getModsForCategory().size() * 11;
                this.modBorder2 = 20 + this.getModsForCategory().size() * 11;
            }
            --this.selectedMod;
            this.mSlide = 10;
            this.modBorder1 -= 11;
            this.modBorder2 -= 11;
        }
    }

    public void left() {
        this.mSlide = 0;
        this.cSlide = 0;
        this.mainMenu = true;
        this.modBorder1 = 8;
        this.modBorder2 = 20;
    }

    public void right() {
        if (!this.mainMenu) {
            this.getModsForCategory().get(this.selectedMod).toggle();
        } else {
            this.selectedMod = 0;
            this.mainMenu = false;
        }
    }

    public void enter() {
        if (!this.mainMenu) {
            this.getModsForCategory().get(this.selectedMod).toggle();
        }else {
            this.selectedMod = 0;
            this.mainMenu = false;
        }
    }

    private ArrayList<Module> getModsForCategory() {
        ArrayList<Module> mods = new ArrayList<Module>();
        for (Module mod : Doragon.moduleManager.getModules()) {
            if (mod.getCategory() != Category.valueOf(this.category.get(this.selectedTab).toUpperCase())) continue;
            mods.add(mod);
        }
        return mods;
    }

    private int getLongestModWidth() {
        int longest = 0;
        for (Module mod : this.getModsForCategory()) {
            if (this.fr.getStringWidth(String.valueOf(mod.getName()) + " <") <= longest) continue;
            longest = this.fr.getStringWidth(String.valueOf(mod.getName()) + " <");
        }
        return longest;
    }

}
