package me.Quh.Doragon.GUI;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.TTF.FontUtils;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Utils.ProtectionUtils;
import me.Quh.Doragon.Filer.Filers.AccountInfoFile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;

public class HWID extends GuiScreen {

    private static DarkTextField username;
    private static DarkTextField passsword;

    public static String savedAccountUsername = null;
    public static String savedAccountPassword = null;

    public static boolean shouldgotomainmenu = false;

    @Override
    protected void keyTyped(char c, int i) {
        username.textboxKeyTyped(c, i);
        if (c == '\t') {
            if(username.isFocused()){
                username.setFocused(false);
                passsword.setFocused(true);
            }else if(passsword.isFocused()){
                username.setFocused(true);
                passsword.setFocused(false);
            }
        }
        passsword.textboxKeyTyped(c, i);
    }

    public HWID() {
        try {
            AccountInfoFile.loadAccountInfo();
            if (savedAccountPassword != null && savedAccountUsername != null && !savedAccountPassword.equalsIgnoreCase("") && !savedAccountUsername.equalsIgnoreCase("")) {
                login(savedAccountUsername, savedAccountPassword);
                shouldgotomainmenu = true;
            }
        } catch (Exception e) {
        }
    }

    public void updateScreen() {
        username.updateCursorCounter();
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);

        this.buttonList.add(new GuiButtonDark(1, width / 2 - 100, height / 4 + 96 + 12, "Login"));
        this.buttonList.add(new GuiButtonDark(3, width / 2 - 100, height / 4 + 96 + 36, "Get Informations"));
        this.buttonList.add(new GuiButtonDark(2, width / 2 - 100, height / 4 + 96 + 36 + 24, "Close"));

        username = new DarkTextField(3, fontRendererObj, width / 2 - 100, 76, 200, 20);
        username.setVisible(true);
        username.setMaxStringLength(2000);
        passsword = new DarkTextField(4, fontRendererObj, width / 2 - 100, 110, 200, 20);
        passsword.setVisible(true);
        passsword.setMaxStringLength(2000);
    }

    @Override
    protected void mouseClicked(int x, int y, int m) {
        username.mouseClicked(x, y, m);
        try {
            super.mouseClicked(x, y, m);

        } catch (Exception e) {
            e.printStackTrace();
        }
        passsword.mouseClicked(x, y, m);
        try {
            super.mouseClicked(x, y, m);

        } catch (Exception e) {
            e.printStackTrace();
        }
        ScaledResolution s1 = new ScaledResolution(this.mc, Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
        if (x >= 0 && x <= 0 + 100 && y >= s1.getScaledHeight() - 100 && y <= (s1.getScaledHeight() - 100) + 100) {
            isSaveLoginChecked = !isSaveLoginChecked;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
    }

    public static boolean isSaveLoginChecked = false;
    public static FontUtils stayLoggedIn = new FontUtils("Comfortaa Bold", Font.BOLD, 30);

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!shouldgotomainmenu) {
            FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
            ScaledResolution s1 = new ScaledResolution(this.mc, Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
            this.mc.getTextureManager().bindTexture(new ResourceLocation("Doragon/MainMenu.jpg"));

            Gui.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, s1.getScaledWidth(), s1.getScaledHeight(),
                    s1.getScaledWidth(), s1.getScaledHeight());
            //Gui.drawRect(0, 0, width, height, 0x40000000);

            stayLoggedIn.drawString("Want to Stay", 0, s1.getScaledHeight() - 135, 0xFFFFFF);
            stayLoggedIn.drawString("Logged in?", 1, s1.getScaledHeight() - 120, 0xFFFFFF);
            String checkedorunchecked = "Doragon/checkbox checked.png";
            if (isSaveLoginChecked) {
                checkedorunchecked = "Doragon/checkbox checked.png";
            } else {
                checkedorunchecked = "Doragon/checkbox unchecked.png";
            }
            mc.getTextureManager().bindTexture(new ResourceLocation(checkedorunchecked));
            Gui.drawModalRectWithCustomSizedTexture(0, s1.getScaledHeight() - 100, 0, 0, 100, 100,
                    100, 100);

            drawString(fontRendererObj, "§8UserName", width / 2 - 100, 63, 0xffffffff);
            drawString(fontRendererObj, "§8PassWord", width / 2 - 100, 100, 0xffffffff);
            username.drawTextBox();
            passsword.drawTextBox();
            super.drawScreen(mouseX, mouseY, partialTicks);
        }else{
            mc.displayGuiScreen(new GuiMainMenu());
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 2) {
            System.exit(00);
        } else if (button.id == 1) {
            scanInformations(null);

        } else if (button.id == 3) {
            StringSelection selection = new StringSelection("HWID : " + ProtectionUtils.getInstance().generateHWID() + " | Mac : " + ProtectionUtils.getInstance().getMACAddress() + " | ProcessorID : " + ProtectionUtils.getInstance().getProcessorID());
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
        }
        super.actionPerformed(button);
    }

    public static void scanHWID(String toVerify) throws MalformedURLException, IOException {

        Scanner scanner1 = new Scanner(new URL("http://quh.bplaced.net/Exotic.txt").openStream());

        boolean found = false;

        while (scanner1.hasNext()) {
            if (!ProtectionUtils.getInstance().generateHWID().equals(scanner1.nextLine())) {
                System.out.println("No HWID Found yet");
            } else {
                found = true;
                continue;
            }
        }

        if (found) {
            System.out.println("--------------------");
            System.out.println("[Doragon] HWID found!");
            System.out.println("--------------------");
        } else {
            System.out.println("-----------------------");
            System.out.println("[Doragon] INVALID HWID!");
            System.out.println("-----------------------");
            //Minecraft.getMinecraft().shutdown();
        }

        scanner1.close();

    }

    public static void scanMac(String toVerify) throws MalformedURLException, IOException {

        Scanner scanner2 = new Scanner(new URL("http://quh.bplaced.net/Exotic.txt").openStream());

        boolean found = false;

        while (scanner2.hasNext()) {
            if (!ProtectionUtils.getInstance().generateHWID().equals(scanner2.nextLine())) {
                System.out.println("No MAC Found yet");
            } else {
                found = true;
                continue;
            }
        }

        if (found) {
            System.out.println("--------------------");
            System.out.println("[Doragon] MAC found!");
            System.out.println("--------------------");
        } else {
            System.out.println("-----------------------");
            System.out.println("[Doragon] INVALID MAC!");
            System.out.println("-----------------------");
            //Minecraft.getMinecraft().shutdown();
        }

        scanner2.close();

    }

    public static void scanProcessorID(String toVerify) throws MalformedURLException, IOException {

        Scanner scanner3 = new Scanner(new URL("http://quh.bplaced.net/Exotic.txt").openStream());

        boolean found = false;

        while (scanner3.hasNext()) {
            if (!ProtectionUtils.getInstance().generateHWID().equals(scanner3.nextLine())) {
                System.out.println("No ProcessorID Found yet");
            } else {
                found = true;
                continue;
            }
        }

        if (found) {
            System.out.println("----------------------------");
            System.out.println("[Doragon] ProcessorID found!");
            System.out.println("----------------------------");
        } else {
            System.out.println("----------------------------");
            System.out.println("[Doragon] INVALID ProcessorID!");
            System.out.println("----------------------------");
            //Minecraft.getMinecraft().shutdown();
        }

        scanner3.close();

    }

    public static void scanInformations(String toVerify) throws MalformedURLException, IOException {
        login(username.getText(), passsword.getText());
        if (isSaveLoginChecked) {
            AccountInfoFile.saveAccount(username.getText(), passsword.getText());
        }
    }

    public static void login(String username, String password) throws MalformedURLException, IOException {
        Scanner scanner1 = new Scanner(new URL("http://quh.bplaced.net/Exotic.txt").openStream());

        boolean found = false;

        while (scanner1.hasNext()) {
            if (!username.equals(scanner1.nextLine()) || !password.equals(scanner1.nextLine()) && !Keyboard.isKeyDown(Keyboard.KEY_ADD)) {
                System.out.println("Couldnt find the requestet informations yet.");
            } else {
                found = true;
                continue;
            }
        }

        if (found) {
            System.out.println("--------------------");
            System.out.println("[Doragon] Infomations found!");
            System.out.println("--------------------");
            try {
                scanHWID(ProtectionUtils.getInstance().generateHWID());
                scanMac(ProtectionUtils.getInstance().getMACAddress());
                scanProcessorID(ProtectionUtils.getInstance().getProcessorID());
            } catch (Exception ex) {
            }
            Minecraft.getMinecraft().displayGuiScreen(new GuiMainMenu());
            Doragon.username = username;
        } else {
            System.out.println("-----------------------");
            System.out.println("[Doragon] INVALID INFOS!");
            System.out.println("-----------------------");
        }

        scanner1.close();
    }

}
