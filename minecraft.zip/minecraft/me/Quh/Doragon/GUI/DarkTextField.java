/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.GUI;

import java.awt.Font;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import static net.minecraft.client.gui.Gui.drawRect;
import net.minecraft.client.gui.GuiTextField;
import me.Quh.Doragon.TTF.FontUtils;
import net.minecraft.client.Minecraft;

/**
 *
 * @author admin
 */
public class DarkTextField extends GuiTextField {

    public DarkTextField(int p_i45542_1_, FontRenderer p_i45542_2_, int p_i45542_3_, int p_i45542_4_, int p_i45542_5_, int p_i45542_6_) {
        super(p_i45542_1_, p_i45542_2_, p_i45542_3_, p_i45542_4_, p_i45542_5_, p_i45542_6_);
    }

    private static FontUtils font = new FontUtils("Comfortaa Bold", Font.BOLD, 25);

    public void drawTextBox() {
        if (this.getVisible()) {
            Gui.drawRect(this.xPosition - 1, this.yPosition - 1, this.xPosition + this.width + 1,
                    this.yPosition + this.height + 1, -0x80000000);

            int var1 = this.isEnabled ? this.enabledColor : this.disabledColor;
            int var2 = this.cursorPosition - this.lineScrollOffset;
            int var3 = this.selectionEnd - this.lineScrollOffset;
            String var4 = Minecraft.getMinecraft().fontRendererObj
                    .trimStringToWidth(this.text.substring(this.lineScrollOffset), this.getWidth());
            boolean var5 = var2 >= 0 && var2 <= var4.length();
            boolean var6 = this.isFocused && this.cursorCounter / 6 % 2 == 0 && var5;
            int var7 = this.enableBackgroundDrawing ? this.xPosition + 4 : this.xPosition;
            int var8 = this.enableBackgroundDrawing ? this.yPosition + (this.height - 8) / 2 : this.yPosition;
            int var9 = var7;

            if (var3 > var4.length()) {
                var3 = var4.length();
            }

            if (var4.length() > 0) {
                String var10 = var5 ? var4.substring(0, var2) : var4;
                var9 = Minecraft.getMinecraft().fontRendererObj.drawString(var10, var7, var8, var1);
            }

            boolean var13 = this.cursorPosition < this.text.length() || this.text.length() >= this.getMaxStringLength();
            int var11 = var9;

            if (!var5) {
                var11 = var2 > 0 ? var7 + this.width : var7;
            } else if (var13) {
                var11 = var9 - 1;
                --var9;
            }

            if (var4.length() > 0 && var5 && var2 < var4.length()) {
                var9 = Minecraft.getMinecraft().fontRendererObj.drawString(var4.substring(var2), var9, var8, var1);
            }

            if (var6) {
                if (var13) {
                    Gui.drawRect(var11, var8 - 1, var11 + 1,
                            var8 + 1 + Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT, -3092272);
                } else {
                    Minecraft.getMinecraft().fontRendererObj.drawString("_", var11, var8, var1);
                }
            }
            if (var3 != var2) {
                int var12 = var7 + Minecraft.getMinecraft().fontRendererObj.getStringWidth(var4.substring(0, var3));
                this.drawCursorVertical(var11, var8 - 1, var12 - 1,
                        var8 + 1 + Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT);
            }
        }
    }
}
