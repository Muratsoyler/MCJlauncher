package me.Quh.Doragon.GUI.Setting;

import java.util.ArrayList;

import me.Quh.Doragon.Module.Module;

public class Setting {

	private String name;
	private Module parent;
	private String mode;

	private String sval;
	private ArrayList<String> options;

	private boolean bval;

	private double dval;
	private double min;
	private double max;
	private boolean onlyint = false;

	public Setting(String iname, Module iparent, String isval, ArrayList<String> ioptions) {
		name = iname;
		parent = iparent;
		sval = isval;
		options = ioptions;
		mode = "Combo";
	}

	public Setting(String iname, Module iparent, boolean ibval) {
		name = iname;
		parent = iparent;
		bval = ibval;
		mode = "Check";
	}

	public Setting(String iname, Module iparent, double idval, double imin, double imax, boolean ionlyint) {
		name = iname;
		parent = iparent;
		dval = idval;
		min = imin;
		max = imax;
		onlyint = ionlyint;
		mode = "Slider";
	}

	public String getName() {
		return name;
	}

	public Module getParentMod() {
		return parent;
	}

	public String getValString() {
		return sval;
	}

	public void setValString(String in) {
		sval = in;
	}

	public ArrayList<String> getOptions() {
		return options;
	}

	public boolean getValBoolean() {
		return bval;
	}

	public void setValBoolean(boolean in) {
		bval = in;
	}

	public double getValDouble() {
		if (onlyint) {
			dval = (int) dval;
		}
		return dval;
	}

	public void setValDouble(double in) {
		dval = in;
	}

	public double getMin() {
		return min;
	}

	public double getMax() {
		return max;
	}

	public boolean isCombo() {
		return mode.equalsIgnoreCase("Combo") ? true : false;
	}

	public boolean isCheck() {
		return mode.equalsIgnoreCase("Check") ? true : false;
	}

	public boolean isSlider() {
		return mode.equalsIgnoreCase("Slider") ? true : false;
	}

	public boolean onlyInt() {
		return onlyint;
	}
}
