package me.Quh.Doragon.GUI.ClickGUI.Elements.Menu;

import me.Quh.Doragon.GUI.ClickGUI.FontUtils;
import me.Quh.Doragon.GUI.ClickGUI.Elements.Element;
import me.Quh.Doragon.GUI.ClickGUI.Elements.ModuleButton;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Utils.ColorUtils;
import me.Quh.Doragon.Utils.RenderUtils;
import me.Quh.Doragon.Filer.Filers.SettingsComboBoxFile;

public class ElementCheckBox extends Element {

    /*
	 * Konstrukor
     */
    public ElementCheckBox(ModuleButton iparent, Setting iset) {
        parent = iparent;
        set = iset;
    }

    /*
	 * Rendern des Elements 
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        /*
		 * Richtig positionieren! Offset wird von ClickGUI aus bestimmt, sodass
		 * nichts ineinander gerendert wird
         */
        x = parent.x + parent.width + 3;
        y = parent.y + offset;
        width = parent.width + 10;
        height = 15;

        /*
		 * Title der Box bestimmen und falls nötig die Breite der CheckBox
		 * erweitern
         */
        String sname = set.getName();
        String setstrg = sname.substring(0, 1).toUpperCase() + sname.substring(1, sname.length());
        float textx = x + width - FontUtils.getStringWidth(setstrg);
        if (textx < x + 1) {
            width += (x + 1) - textx + 1;
        }

        /*
		 * Die Box und Umrandung rendern
         */
        RenderUtils.drawRect(x, y - 0.50, x + width + 0.25, y + height + 0.60, 0xbb151515);
        //RenderUtils.drawRect(x, y, x + width, y + height, 0xDD0f0f0f);

        /*
		 * Titel und Checkbox rendern.
         */
        FontUtils.drawCustomString(setstrg, x + width - 1 - FontUtils.getCustonStringWidth(setstrg), y + FontUtils.getFontHeight() / 4.3F - 0.5F, ColorUtils.RGBtoHEX(112, 119, 119, 501));
        FontUtils.drawCustomString("x", x + 3, y + 1.5F, set.getValBoolean() ? 0xff990000 : ColorUtils.RGBtoHEX(112, 119, 119, 502));
        if (isCheckHovered(mouseX, mouseY)) {
            FontUtils.drawCustomString("x", x + 3, y + 1.5F, set.getValBoolean() ? 0xff990000 : 0xff990000);
        }
    }

    /*
	 * 'true' oder 'false' bedeutet hat der Nutzer damit interagiert und
	 * sollen alle anderen Versuche der Interaktion abgebrochen werden?
     */
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && isCheckHovered(mouseX, mouseY)) {
            set.setValBoolean(!set.getValBoolean());
            SettingsComboBoxFile.saveState();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    /*
	 * Einfacher HoverCheck, benötigt damit die Value geändert werden kann
     */
    public boolean isCheckHovered(int mouseX, int mouseY) {
        return mouseX >= x + 1 && mouseX <= x + 12 && mouseY >= y + 2 && mouseY <= y + 13;
    }
}
