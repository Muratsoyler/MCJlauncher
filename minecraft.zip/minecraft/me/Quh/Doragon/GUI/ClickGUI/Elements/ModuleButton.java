package me.Quh.Doragon.GUI.ClickGUI.Elements;

import java.awt.Font;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.lwjgl.input.Keyboard;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.ClickGUI.FontUtils;
import me.Quh.Doragon.GUI.ClickGUI.Panel;
import me.Quh.Doragon.GUI.ClickGUI.Elements.Menu.ElementCheckBox;
import me.Quh.Doragon.GUI.ClickGUI.Elements.Menu.ElementComboBox;
import me.Quh.Doragon.GUI.ClickGUI.Elements.Menu.ElementSlider;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Utils.ColorUtils;
import me.Quh.Doragon.Utils.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class ModuleButton {
	public Module mod;
	public ArrayList<Element> menuelements;
	public Panel parent;
	public float x;
	public float y;
	public float width;
	public float height;
	public boolean extended = false;
	public boolean listening = false;
	private TimeHelper delay = new TimeHelper();

	/*
	 * Konstrukor
	 */
	public ModuleButton(Module imod, Panel pl) {
		mod = imod;
		height = Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT + 2;
		parent = pl;
		menuelements = new ArrayList<Element>();
		/*
		 * Settings wurden zuvor in eine ArrayList eingesetKeyBintragen dieses
		 * SettingSystem hat 3 Konstruktoren je nach verwendetem Konstruktor
		 * ndert sich die Value bei .isCheck() usw. so kann man ganz einfach
		 * ohne irgendeinen Aufwand bestimmen welches Element
		 * 
		 */
		if (Doragon.settingsManager.getSettingsByMod(imod) != null)
			for (Setting s : Doragon.settingsManager.getSettingsByMod(imod)) {
				if (s.isCheck()) {
					menuelements.add(new ElementCheckBox(this, s));
				} else if (s.isSlider()) {
					menuelements.add(new ElementSlider(this, s));
				} else if (s.isCombo()) {
					menuelements.add(new ElementComboBox(this, s));
				}
			}

	}

	/*
	 * Rendern des Elements
	 */
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		/*
		 * Ist das Module an, wenn ja dann soll #ein neues Rechteck in Gre des
		 * Buttons den Knopf als Toggled kennzeichnen #sich der Text anders
		 * frben
		 */

		String modname = mod.name;

		/*
		 * Den Namen des Modules in die Mitte (x und y) rendern
		 */
		FontUtils.drawCustomTotalCenteredString(modname, x + width / 2 + 3, y + 1 + height / 2 - 2,
				ColorUtils.RGBtoHEX(112, 119, 119, 500));

		if (menuelements.size() != 0) {
			FontUtils.drawCustomCenteredString(".", x + width - 2, y + height - 13,
					ColorUtils.RGBtoHEX(112, 119, 119, 500));
		}

		if (mod.toggled) {
			FontUtils.drawCustomTotalCenteredString(modname, x + width / 2 + 3, y + 1 + height / 2 - 2, 0xff990000);
		}

		/*
		 * Ist die Maus ber dem Element, wenn ja dann soll der Button sich
		 * anders frben
		 */
		if (isHovered(mouseX, mouseY) && (mod.toggled)) {
			FontUtils.drawCustomTotalCenteredString(modname, x + width / 2 + 3, y + 1 + height / 2 - 2,
					ColorUtils.RGBtoHEX(112, 119, 119, 500));
		}

		if (isHovered(mouseX, mouseY) && !(mod.toggled)) {
			FontUtils.drawCustomTotalCenteredString(modname, x + width / 2 + 3, y + 1 + height / 2 - 2, 0xff990000);

			Collections.sort(Doragon.moduleManager.getModules(), new Comparator<Module>() {

				@Override
				public int compare(Module mod1, Module mod2) {
					if (FontUtils.getCustonStringWidth(mod1.getName()) > FontUtils
							.getCustonStringWidth(mod2.getName())) {
						return -1;
					}
					if (FontUtils.getCustonStringWidth(mod1.getName()) < FontUtils
							.getCustonStringWidth(mod2.getName())) {

						return 1;

					}
					return 0;
				}

			});

		}

	}

	/*
	 * 'true' oder 'false' bedeutet hat der Nutzer damit interagiert und sollen
	 * alle anderen Versuche der Interaktion abgebrochen werden?
	 */
	public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
		if (delay.isDelayComplete(10)) {
			mod.setSuffix("");
			delay.setLastMS();
		}
		if (!isHovered(mouseX, mouseY))
			return false;

		/*
		 * Rechtsklick, wenn ja dann Module togglen,
		 */
		if (mouseButton == 0) {
			mod.toggle();
			Minecraft.getMinecraft().thePlayer.playSound("random.click", 0.5f, 0.5f);
		} else if (mouseButton == 1) {
			/*
			 * Wenn ein Settingsmenu existiert dann sollen alle Settingsmenus
			 * geschlossen werden und dieses geffnet/geschlossen werden
			 */
			if (menuelements != null && menuelements.size() > 0) {
				boolean b = !this.extended;
				Doragon.clickGui.closeAllSettings();
				this.extended = b;
				if (extended)
					Minecraft.getMinecraft().thePlayer.playSound("tile.piston.out", 1f, 1f);
				else
					Minecraft.getMinecraft().thePlayer.playSound("tile.piston.in", 1f, 1f);
			}
		} else if (mouseButton == 2) {
			/*
			 * MidClick => Set keybind (wait for next key)
			 */
			listening = true;
		}
		return true;
	}

	public boolean keyTyped(char typedChar, int keyCode) throws IOException {
		/*
		 * Wenn listening, dann soll der nchster Key (abgesehen 'ESCAPE') als
		 * Keybind fr mod danach soll nicht mehr gewartet werden!
		 */
		if (listening) {
			if (keyCode != Keyboard.KEY_ESCAPE) {
				Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(
						"Bound '" + mod.name + "'" + " to '" + Keyboard.getKeyName(keyCode) + "'"));
				mod.setKeyBind(keyCode);
			} else {
				Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("Unbound '" + mod.name + "'"));
				mod.setKeyBind(0);
			}
			listening = false;
			return true;
		}
		return false;
	}

	public boolean isHovered(int mouseX, int mouseY) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}

}
