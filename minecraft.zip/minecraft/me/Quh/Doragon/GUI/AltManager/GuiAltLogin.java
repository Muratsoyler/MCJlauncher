package me.Quh.Doragon.GUI.AltManager;

import me.Quh.Doragon.GUI.GuiButtonDark;
import me.Quh.Doragon.Utils.AltManagerUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiAltLogin extends GuiScreen{

    private GuiTextField email;
    private GuiTextField password;
    private GuiTextField emailpassword;

    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        this.buttonList.clear();
        this.buttonList.add(new GuiButtonDark(1, width / 2 - 100, height / 4 + 96 + 18, 200,20, I18n.format("Login", new Object[0])));
        this.buttonList.add(new GuiButtonDark(2, width / 2 - 100, height / 4 + 96 + 42, 200,20,I18n.format("Cancel", new Object[0])));
        this.email = new GuiTextField(0, this.fontRendererObj, width / 2 - 100, 66, 200, 20);
        this.password = new GuiTextField(1, this.fontRendererObj, width / 2 - 100, 101, 200, 20);
        this.emailpassword = new GuiTextField(2, this.fontRendererObj, width / 2 - 100, 151, 200, 20);
    }

    protected void actionPerformed(GuiButton par1GuiButton) {
        if(par1GuiButton.id == 1) {
            if(this.email.getText().length() > 0) {
                if(this.password.getText().length() > 0) {
                    AltManagerUtils.login(this.email.getText(), this.password.getText());
                } else {
                    AltManagerUtils.loginCracked(this.email.getText());
                }
            } else if(this.password.getText().length() <= 0 && this.emailpassword.getText().length() > 0 && this.emailpassword.getText().contains(":")) {
                AltManagerUtils.login(this.emailpassword.getText().split(":")[0], this.emailpassword.getText().split(":")[1]);
            }
        } else if(par1GuiButton.id == 2) {
            this.mc.displayGuiScreen(new GuiAltManager());
        }

    }

    public void updateScreen() {
        this.emailpassword.setMaxStringLength(100);
        this.email.setMaxStringLength(100);
        this.password.setMaxStringLength(100);
        this.email.updateCursorCounter();
        this.password.updateCursorCounter();
        this.emailpassword.updateCursorCounter();
    }

    public void mouseClicked(int x, int y, int b) {
        this.email.mouseClicked(x, y, b);
        this.password.mouseClicked(x, y, b);
        this.emailpassword.mouseClicked(x, y, b);

        try {
            super.mouseClicked(x, y, b);
        } catch (IOException var5) {
            var5.printStackTrace();
        }

    }

    public void keyTyped(char ch, int key) {
        if(key == 1) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiMainMenu());
        }

        this.email.textboxKeyTyped(ch, key);
        this.password.textboxKeyTyped(ch, key);
        this.emailpassword.textboxKeyTyped(ch, key);
        if(key == 28) {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }

        if(key == 13) {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }

        ((GuiButton)this.buttonList.get(0)).enabled = this.email.getText().length() > 0 || this.emailpassword.getText().length() > 0;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        try {
            this.email.drawTextBox();
            this.password.drawTextBox();
            this.emailpassword.drawTextBox();
            if(!this.email.isFocused() && this.email.getText().length() <= 0) {
                this.drawString(this.fontRendererObj, "Email", width / 2 - 100 + 4, 72, 10526880);
            }

            if(!this.password.isFocused() && this.password.getText().length() <= 0) {
                this.drawString(this.fontRendererObj, "Password", width / 2 - 100 + 4, 107, 10526880);
            }

            if(!this.emailpassword.isFocused() && this.emailpassword.getText().length() <= 0) {
                this.drawString(this.fontRendererObj, "Email:Password", width / 2 - 100 + 4, 157, 10526880);
            }
        } catch (Exception var5) {
            var5.printStackTrace();
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
