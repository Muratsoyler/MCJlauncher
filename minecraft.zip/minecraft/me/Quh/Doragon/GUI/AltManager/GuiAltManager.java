package me.Quh.Doragon.GUI.AltManager;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Filer.Filers.AltFile;
import me.Quh.Doragon.GUI.GuiButtonDark;
import me.Quh.Doragon.Utils.AltManagerUtils;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.Random;

public class GuiAltManager extends GuiScreen {

    private GuiButtonDark login;
    private GuiButtonDark remove;
    private GuiButtonDark rename;
    private int offset;
    public Alt selectedAlt;


    public GuiAltManager() {
        this.selectedAlt = null;
        Doragon.altManager.getAlts().clear();
        AltFile.loadAlts();
    }

    public void actionPerformed(GuiButton button) {
        if (button.id == 1) {
            GuiAltManager.mc.displayGuiScreen(new GuiMainMenu());
        }
        if (button.id == 2) {
            String user = this.selectedAlt.getUsername();
            String pass = this.selectedAlt.getPassword();
            if (pass.equalsIgnoreCase("")) {
                AltManagerUtils.loginCracked(user);
            } else {
                AltManagerUtils.login(user, pass);
            }
        }
        if (button.id == 3) {
            Doragon.altManager.removeAlt(selectedAlt);
            this.selectedAlt = null;
        }
        if (button.id == 4) {
            GuiAltManager.mc.displayGuiScreen(new GuiAddAlt(this));
        }
        if (button.id == 5) {
            GuiAltManager.mc.displayGuiScreen(new GuiAltLogin());
        }
        if (button.id == 6) {
            if(Doragon.altManager.getAlts().isEmpty() || Doragon.altManager.getAlts().size() == 1){
                return;
            }
            Alt randomAlt = Doragon.altManager.getAlts().get(new Random().nextInt(Doragon.altManager.getAlts().size()));
            String user = randomAlt.getUsername();
            String pass = randomAlt.getPassword();
            if (pass.equalsIgnoreCase("")) {
                AltManagerUtils.loginCracked(user);
            } else {
                AltManagerUtils.login(user, pass);
            }
        }
        if (button.id == 7) {
            GuiAltManager.mc.displayGuiScreen(new GuiRenameAlt(this));
        }
    }

    @Override
    public void drawScreen(int par1, int par2, float par3) {
        if (Mouse.hasWheel()) {
            int wheel = Mouse.getDWheel();
            if (wheel < 0) {
                this.offset += 26;
                if (this.offset < 0) {
                    this.offset = 0;
                }
            } else if (wheel > 0) {
                this.offset -= 26;
                if (this.offset < 0) {
                    this.offset = 0;
                }
            }
        }
        this.drawDefaultBackground();
        this.drawString(this.fontRendererObj, GuiAltManager.mc.session.getUsername(), 10, 10, -7829368);
        this.drawCenteredString(this.fontRendererObj, "Account Manager - " + Doragon.altManager.getAlts().size() + " Alts", this.width / 2, 10, -1);
        RenderHelper.drawBorderedRect(50.0f, 33.0f, this.width - 50, this.height - 50, 1.0f, -16777216, Integer.MIN_VALUE);
        GL11.glPushMatrix();
        this.prepareScissorBox(0.0f, 33.0f, this.width, this.height - 50);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        int y = 38;
        for (Alt alt : Doragon.altManager.getAlts()) {
            if (!this.isAltInArea(y)) {
                continue;
            }
            String name;
            if (alt.getMask().equals("")) {
                name = alt.getUsername();
            } else {
                name = alt.getMask();
            }
            String pass;
            if (alt.getPassword().equals("")) {
                pass = "§cCracked";
            } else {
                pass = alt.getPassword().replaceAll(".", "*");
            }
            if (alt == this.selectedAlt) {
                if (this.isMouseOverAlt(par1, par2, y - this.offset) && Mouse.isButtonDown(0)) {
                    RenderHelper.drawBorderedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f, -16777216, -2142943931);
                } else if (this.isMouseOverAlt(par1, par2, y - this.offset)) {
                    RenderHelper.drawBorderedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f, -16777216, -2142088622);
                } else {
                    RenderHelper.drawBorderedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f, -16777216, -2144259791);
                }
            } else if (this.isMouseOverAlt(par1, par2, y - this.offset) && Mouse.isButtonDown(0)) {
                RenderHelper.drawBorderedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f, -16777216, -2146101995);
            } else if (this.isMouseOverAlt(par1, par2, y - this.offset)) {
                RenderHelper.drawBorderedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f, -16777216, -2145180893);
            }
            this.drawCenteredString(this.fontRendererObj, name, this.width / 2, y - this.offset, -1);
            this.drawCenteredString(this.fontRendererObj, pass, this.width / 2, y - this.offset + 10, 5592405);
            y += 26;
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glPopMatrix();
        super.drawScreen(par1, par2, par3);
        if (this.selectedAlt == null) {
            this.login.enabled = false;
            this.remove.enabled = false;
            this.rename.enabled = false;
        } else {
            this.login.enabled = true;
            this.remove.enabled = true;
            this.rename.enabled = true;
        }
        if (Keyboard.isKeyDown(200)) {
            this.offset -= 26;
            if (this.offset < 0) {
                this.offset = 0;
            }
        } else if (Keyboard.isKeyDown(208)) {
            this.offset += 26;
            if (this.offset < 0) {
                this.offset = 0;
            }
        }
    }

    @Override
    public void initGui() {
        this.buttonList.add(new GuiButtonDark(1, this.width / 2 + 4 + 76, this.height - 24, 75, 20, "Cancel"));
        this.buttonList.add(this.login = new GuiButtonDark(2, this.width / 2 - 154, this.height - 48, 100, 20, "Login"));
        this.buttonList.add(this.remove = new GuiButtonDark(3, this.width / 2 - 74, this.height - 24, 70, 20, "Remove"));
        this.buttonList.add(new GuiButtonDark(4, this.width / 2 + 4 + 50, this.height - 48, 100, 20, "Add"));
        this.buttonList.add(new GuiButtonDark(5, this.width / 2 - 50, this.height - 48, 100, 20, "Direct Login"));
        this.buttonList.add(new GuiButtonDark(6, this.width / 2 - 154, this.height - 24, 70, 20, "Random"));
        this.buttonList.add(this.rename = new GuiButtonDark(7, this.width / 2 + 4, this.height - 24, 70, 20, "Rename"));
        this.login.enabled = false;
        this.remove.enabled = false;
        this.rename.enabled = false;
    }

    private boolean isAltInArea(int y) {
        return y - this.offset <= this.height - 50;
    }

    private boolean isMouseOverAlt(int x, int y, int y1) {
        return x >= 52 && y >= y1 - 4 && x <= this.width - 52 && y <= y1 + 20 && x >= 0 && y >= 33 && x <= this.width && y <= this.height - 50;
    }

    @Override
    protected void mouseClicked(int par1, int par2, int par3) {
        if (this.offset < 0) {
            this.offset = 0;
        }
        int y = 38 - this.offset;
        for (Alt alt : Doragon.altManager.getAlts()) {
            if (this.isMouseOverAlt(par1, par2, y)) {
                if (alt == this.selectedAlt) {
                    this.actionPerformed((GuiButton) this.buttonList.get(1));
                    return;
                }
                this.selectedAlt = alt;
            }
            y += 26;
        }
        try {
            super.mouseClicked(par1, par2, par3);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void prepareScissorBox(float x, float y, float x2, float y2) {
        int factor = RenderHelper.getScaledRes().getScaleFactor();
        GL11.glScissor((int) (x * factor), (int) ((RenderHelper.getScaledRes().getScaledHeight() - y2) * factor), (int) ((x2 - x) * factor), (int) ((y2 - y) * factor));
    }
}
