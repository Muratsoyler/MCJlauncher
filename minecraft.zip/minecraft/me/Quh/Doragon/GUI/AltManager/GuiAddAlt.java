package me.Quh.Doragon.GUI.AltManager;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.GuiButtonDark;
import me.Quh.Doragon.Utils.AltManagerUtils;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiAddAlt extends GuiScreen {

    private GuiAltManager manager;
    private GuiTextField user;
    private GuiTextField pw;

    public GuiAddAlt(GuiAltManager manager) {
        this.manager = manager;
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            if(!user.getText().isEmpty()){
                if(pw.getText().isEmpty()){
                    Doragon.altManager.addAlt(new Alt(user.getText(),""));
                }else{
                    Doragon.altManager.addAlt(new Alt(user.getText(),pw.getText()));
                }
            }

        }
        if (button.id == 2) {
            mc.displayGuiScreen(manager);
        }
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        this.buttonList.clear();
        this.buttonList.add(new GuiButtonDark(1, this.width / 2 - 100, this.height / 4 + 92 + 12, 200, 20, "Login"));
        this.buttonList.add(new GuiButtonDark(2, this.width / 2 - 100, this.height / 4 + 116 + 12, 200, 20, "Back"));
        user = new GuiTextField(1, mc.fontRendererObj, this.width / 2 - 100, 60, 200, 20);
        pw = new GuiTextField(2, mc.fontRendererObj, this.width / 2 - 100, 100, 200, 20);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        user.textboxKeyTyped(typedChar, keyCode);
        pw.textboxKeyTyped(typedChar,keyCode);
        if (typedChar == '\t') {
            if (user.isFocused) {
                user.setFocused(false);
                pw.setFocused(true);
            } else if (pw.isFocused) {
                pw.setFocused(false);
                user.setFocused(true);
            }
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        user.mouseClicked(mouseX,mouseY,mouseButton);
        pw.mouseClicked(mouseX,mouseY,mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        user.drawTextBox();
        pw.drawTextBox();
        this.drawCenteredString(this.fontRendererObj,"Add Alt",this.width / 2,20, -1);
        if(user.getText().isEmpty()){
            this.drawString(mc.fontRendererObj, "E-Mail/Username", this.width / 2 - 96, 66, 0xFFFFFFFF);
        }
        if(pw.getText().isEmpty()){
            this.drawString(mc.fontRendererObj, "Password", this.width / 2 - 96, 106, 0xFFFFFFFF);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
