package me.Quh.Doragon.GUI.AltManager;

public class Alt {

    private String mask;
    private String username;
    private String password;

    public Alt(String username,String password){
        this(username,password,"");
    }

    public Alt(String username,String password,String mask){
        this.mask = mask;
        this.username = username;
        this.password = password;
    }

    public String getMask() {
        return mask;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
