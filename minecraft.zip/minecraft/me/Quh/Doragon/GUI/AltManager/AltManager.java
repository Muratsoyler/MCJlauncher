package me.Quh.Doragon.GUI.AltManager;

import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import me.Quh.Doragon.Filer.Filers.AltFile;

import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;

public class AltManager {

    private List<Alt> alts;
    private Alt lastAlt;

    public Alt getLastAlt() {
        return lastAlt;
    }

    public void setLastAlt(Alt lastAlt) {
        this.lastAlt = lastAlt;
    }

    public AltManager(){
        alts = new ArrayList<Alt>();
    }

    public List<Alt> getAlts() {
        return alts;
    }

    public void addAlt(Alt alt){
        YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
        YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication)service.createUserAuthentication(Agent.MINECRAFT);
        auth.setUsername(alt.getUsername());
        auth.setPassword(alt.getPassword());
        try{
            auth.logIn();
            this.alts.add(alt);
            AltFile.saveAlts();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void removeAlt(Alt alt){
        this.alts.remove(alt);
        AltFile.saveAlts();
    }
}
