package me.Quh.Doragon.GUI.AltManager;

import me.Quh.Doragon.Filer.Filers.AltFile;
import me.Quh.Doragon.GUI.GuiButtonDark;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;

public class GuiRenameAlt extends GuiScreen {

    private final GuiAltManager manager;
    private GuiTextField nameField;

    public GuiRenameAlt(final GuiAltManager manager) {
        this.manager = manager;
    }

    public void actionPerformed(GuiButton button) {
        if (button.id == 1) {
            this.manager.selectedAlt.setMask(this.nameField.getText());
            AltFile.saveAlts();
        }
        if (button.id == 2) {
            this.mc.displayGuiScreen(this.manager);
        }
    }

    @Override
    public void drawScreen(final int par1, final int par2, final float par3) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "Rename Alt", this.width / 2, 10, -1);
        this.nameField.drawTextBox();
        super.drawScreen(par1, par2, par3);
    }

    @Override
    public void initGui() {
        this.buttonList.add(new GuiButtonDark(1, this.width / 2 - 100, this.height / 4 + 92 + 12, 200, 20, "Rename"));
        this.buttonList.add(new GuiButtonDark(2, this.width / 2 - 100, this.height / 4 + 116 + 12, 200, 20, "Cancel"));
        this.nameField = new GuiTextField(1, this.fontRendererObj, this.width / 2 - 100, 76, 200, 20);
    }

    @Override
    protected void keyTyped(final char par1, final int par2) {
        this.nameField.textboxKeyTyped(par1, par2);
        if (par1 == '\t' && this.nameField.isFocused()) {
            this.nameField.setFocused(!this.nameField.isFocused());
        }
        if (par1 == '\r') {
            this.actionPerformed((GuiButton) this.buttonList.get(0));
        }
    }

    @Override
    protected void mouseClicked(final int par1, final int par2, final int par3) {
        this.nameField.mouseClicked(par1, par2, par3);
    }
}
