package me.Quh.Doragon.Utils;

import java.net.*;
import java.util.*;
import java.util.List;
import java.awt.*;
import java.awt.datatransfer.*;
import sun.misc.*;
import java.io.*;

public class ProtectionUtils
{
    public static ProtectionUtils getInstance() {
        return new ProtectionUtils();
    }
    
    public String getMACAddress() {
        try {
            final InetAddress ip = InetAddress.getLocalHost();
            final Enumeration<NetworkInterface> networks = NetworkInterface.getNetworkInterfaces();
            while (networks.hasMoreElements()) {
                final NetworkInterface network = networks.nextElement();
                final byte[] mac = network.getHardwareAddress();
                if (mac != null) {
                    final StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < mac.length; ++i) {
                        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
                    }
                    return sb.toString();
                }
            }
        }
        catch (UnknownHostException ex) {}
        catch (SocketException ex2) {}
        return "";
    }
    
    public String getProcessorID() {
        try {
            final Process process = Runtime.getRuntime().exec(new String[] { "wmic", "cpu", "get", "ProcessorID" });
            process.getOutputStream().close();
            final Scanner sc = new Scanner(process.getInputStream());
            final String property = sc.next();
            final String serial = sc.next();
            return serial;
        }
        catch (IOException ex) {
            return "0-0";
        }
    }
    
  
    
    public String generateHWID() {
        final String prefix = "-#-#-#";
        final String username = System.getProperty("user.name");
        final String pcversion = System.getProperty("os.name");
        final String amd = System.getProperty("os.arch");
        final String hardwareid = String.valueOf(prefix) + username + pcversion + amd;
        try {
            final String rez = new BASE64Encoder().encode(hardwareid.getBytes("UTF-8"));
            return new BASE64Encoder().encode(rez.getBytes("UTF-8"));
        }
        catch (UnsupportedEncodingException ex) {
            return "nohwid";
        }
    }
}
