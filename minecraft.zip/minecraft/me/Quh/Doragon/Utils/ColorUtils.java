package me.Quh.Doragon.Utils;

import java.awt.Color;

public class ColorUtils {

	public static Color rainbow(long offset, float fade) {
		float hue = (float) (System.nanoTime() + offset) / 1.0E10F % 1.0F;
		long color = Long.parseLong(Integer.toHexString(Integer.valueOf(Color.HSBtoRGB(hue, 1.0F, 1.0F)).intValue()),
				16);
		Color c = new Color((int) color);
		return new Color(c.getRed() / 255.0F * fade, c.getGreen() / 255.0F * fade, c.getBlue() / 255.0F * fade,
				c.getAlpha() / 255.0F);
	}


	public static int getRainbow(int speed, int offset) {
		float hue = (System.currentTimeMillis() + offset) % speed;
		hue /= speed;
		Color c = Color.getHSBColor(hue, 1f, 1f);
		int r = c.getRed();
		int g = c.getGreen();
		int b = c.getBlue();
		r = (r << 16) & 0x00FF0000;
		g = (g << 8) & 0x0000FF00;
		b = b & 0x000000FF;
		return 0x000000 | r | g | b;
	}

	public static int RGBtoHEX(int r, int g, int b, int a) {
		return (a << 24) + (r << 16) + (g << 8) + b;
	}
}
