package me.Quh.Doragon.Utils;

import net.minecraft.util.*;

public class BlockData
{
    public BlockPos position;
    public EnumFacing face;
    
    public BlockData(final BlockPos position, final EnumFacing face) {
        this.position = position;
        this.face = face;
    }
}
