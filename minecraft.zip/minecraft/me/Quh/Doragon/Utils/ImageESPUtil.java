/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/**
 *
 * @author admin
 */
public class ImageESPUtil {

    private static float scaleF = 0.5f;

    public static void draw(float partialTicks, String location) {
        for (Object o : Minecraft.getMinecraft().theWorld.playerEntities) {
            EntityPlayer e = (EntityPlayer) o;
            if (e.equals(Minecraft.getMinecraft().thePlayer)) {
                continue;
            }
            double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * partialTicks - Minecraft.getMinecraft().getRenderManager().renderPosX;
            double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * partialTicks - Minecraft.getMinecraft().getRenderManager().renderPosY
                    + e.height;
            double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * partialTicks - Minecraft.getMinecraft().getRenderManager().renderPosZ;
            float f = (Minecraft.getMinecraft().thePlayer.getDistanceToEntity(e) * scaleF) * 0.007f;

            GlStateManager.pushMatrix();
            {
                GlStateManager.disableDepth();
                GlStateManager.translate(x, y, z);
                GL11.glNormal3f(0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(-Minecraft.getMinecraft().getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(Minecraft.getMinecraft().getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
                GlStateManager.scale(-f, -f, f);
                GlStateManager.disableLighting();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                GlStateManager.func_179098_w();
                renderImage(new ResourceLocation(location), -24, 0, 48f, 48f);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            }
            GL11.glColor4f(1, 1, 1, 1);
            GlStateManager.popMatrix();

        }
    }

    public static void onRenderMethod(String location) {
        if ((Minecraft.getMinecraft().thePlayer == null) || (Minecraft.getMinecraft().theWorld == null)) {
            return;
        }
        for (Object o : Minecraft.getMinecraft().theWorld.playerEntities) {
            EntityPlayer p = (EntityPlayer) o;
            if ((p != Minecraft.getMinecraft().func_175606_aa()) && (p.isEntityAlive()) && p.getName() != "§3Dealer") {
                Minecraft.getMinecraft().getRenderManager();
                double pX = p.lastTickPosX + (p.posX - p.lastTickPosX) * Minecraft.getMinecraft().timer.renderPartialTicks
                        - RenderManager.renderPosX;
                Minecraft.getMinecraft().getRenderManager();
                double pY = p.lastTickPosY + (p.posY - p.lastTickPosY) * Minecraft.getMinecraft().timer.renderPartialTicks
                        - RenderManager.renderPosY;
                Minecraft.getMinecraft().getRenderManager();
                double pZ = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * Minecraft.getMinecraft().timer.renderPartialTicks
                        - RenderManager.renderPosZ;

                draw(1F,location);
            }
        }
    }

    public static void renderImage(ResourceLocation resourceLocation, float posX, float posY, float width, float height) {
        float f = (width + height) / 2;
        int i = Math.round(f);
        GL11.glEnable(GL11.GL_BLEND);
        Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2d(0d, 0d);
        GL11.glVertex2d((double) posX, (double) posY);
        GL11.glTexCoord2d(0d, (double) (f / i));
        GL11.glVertex2d((double) posX, (double) (posY + height));
        GL11.glTexCoord2d(1d, (double) (f / i));
        GL11.glVertex2d((double) (posX + width), (double) (posY + height));
        GL11.glTexCoord2d(1d, 0d);
        GL11.glVertex2d((double) (posX + width), (double) posY);
        GL11.glEnd();
        GL11.glDisable(GL11.GL_BLEND);
    }

}
