package me.Quh.Doragon.Utils;

public class TimeHelper {

	private static long lastMS = 0L;

	public boolean isDelayComplete(float f) {
		if (System.currentTimeMillis() - this.lastMS >= f) {
			return true;
		}
		return false;
	}

	public static long getCurrentMs() {
		return System.nanoTime() / 10000L;
	}

	public void setLastMS() {
		this.lastMS = System.currentTimeMillis();
	}

	public boolean isDelayComplete(double delay) {
		return System.currentTimeMillis() - this.lastMS >= delay;
	}

	public static boolean hasReached(long milliseconds) {
		return getCurrentMs() - lastMS >= milliseconds;
	}

	public static void reset() {
		lastMS = getCurrentMs();
}

}
