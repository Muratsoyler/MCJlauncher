package me.Quh.Doragon.Utils;

import java.net.Proxy;

import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class AltManagerUtils {

   public static String login(String Username, String Password) {
     if(Username.equals("")) {
         return "§cLogin Failed.";
      } else if(Password.equals("")) {
         return "§cLogin Failed.";
      } else {
         YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
         YggdrasilUserAuthentication user = new YggdrasilUserAuthentication(service, Agent.MINECRAFT);
         user.setUsername(Username);
         user.setPassword(Password);

         try {
            user.logIn();
            String ex = user.getSelectedProfile().getName();
            String playerID = user.getSelectedProfile().getId().toString();
            String token = user.getAuthenticatedToken();
            Minecraft.getMinecraft().session = new Session(ex, playerID, token, "mojang");
            return "§cLogged in.§f";
         } catch (Exception var7) {
            return "§cLogin Failed.";
         }
      }
   }

   public static String loginCracked(String Username) {
      Minecraft.getMinecraft().session = new Session(Username, "", "", "mojang");
      return "§cLogged in.";
   }
   
}