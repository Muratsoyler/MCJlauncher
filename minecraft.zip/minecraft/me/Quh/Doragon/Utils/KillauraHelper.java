package me.Quh.Doragon.Utils;

import com.google.common.collect.Multimap;
import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Friend.FriendUtil;
import me.Quh.Doragon.Module.Impl.Combat.TestAura;
import me.Quh.Doragon.Module.Impl.Player.Teams;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.*;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;

import java.util.Iterator;
import java.util.Map;

public class KillauraHelper {

    public static Minecraft mc = Minecraft.getMinecraft();

    public static int getBeastWeapon(Entity player) {
        int originalSlot = mc.thePlayer.inventory.currentItem;
        int weaponSlot = -1;
        float weaponDamage = 1F;
        for (int slot = 0; slot < 9; ++slot) {
            mc.thePlayer.inventory.currentItem = slot;
            ItemStack itemStack = mc.thePlayer.getHeldItem();
            if (itemStack != null) {
                float damage = getItemDamage(itemStack);
                damage += EnchantmentHelper.func_152377_a(itemStack, EnumCreatureAttribute.UNDEFINED);
                if (damage > weaponDamage) {
                    weaponDamage = damage;
                    weaponSlot = slot;
                }
            }
        }
        if (weaponSlot != -1) {
            return weaponSlot;
        }
        return originalSlot;
    }

    public static void findTargets() {
        mc.theWorld.loadedEntityList.stream().filter((entity) -> {
            return entity instanceof EntityLivingBase;
        }).filter((entity) -> {
            return check((EntityLivingBase) entity);
        }).forEach((entity) -> {
            TestAura.targets.add((EntityLivingBase) entity);
        });
    }

    public static float getItemDamage(ItemStack itemStack) {
        Multimap multimap = itemStack.getAttributeModifiers();
        if (!multimap.isEmpty()) {
            Iterator iterator = multimap.entries().iterator();
            if (iterator.hasNext()) {
                Map.Entry entry = (Map.Entry) iterator.next();
                AttributeModifier attributeModifier = (AttributeModifier) entry.getValue();
                double damage;
                if (attributeModifier.getOperation() != 1 && attributeModifier.getOperation() != 2) {
                    damage = attributeModifier.getAmount();
                } else {
                    damage = attributeModifier.getAmount() * 100;
                }
                if (attributeModifier.getAmount() > 1) {
                    return 1F + (float) damage;
                }
                return 1F;
            }
        }
        return 1F;
    }

    public static void filterTargets() {
        EntityLivingBase first;
        first = (EntityLivingBase) TestAura.targets.stream().sorted((entity1, entity2) -> {
            float yaw = EntityHelper.getYawChangeToEntity((Entity) entity1);
            float pitch = EntityHelper.getPitchChangeToEntity((Entity) entity1);
            float firstEntityDistance = (yaw + pitch) / 2.0F;
            yaw = EntityHelper.getYawChangeToEntity((Entity) entity2);
            pitch = EntityHelper.getPitchChangeToEntity((Entity) entity2);
            float secondEntityDistance = (yaw + pitch) / 2.0F;
            return firstEntityDistance > secondEntityDistance ? 1 : (secondEntityDistance > firstEntityDistance ? -1 : 0);
        }).findFirst().get();
        if (check(first)) {
            TestAura.target = first;
        } else {
            TestAura.targets.remove(first);
        }

    }

    public static void burst(Entity entity) {
        ItemStack currentItem = mc.thePlayer.inventory.getCurrentItem();
        boolean wasSneaking = mc.thePlayer.isSneaking();
        boolean wasBlocking = currentItem != null && currentItem.getItem().getItemUseAction(currentItem) == EnumAction.BLOCK && mc.thePlayer.isBlocking();
        if(wasSneaking) {
            mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }

        if(wasBlocking) {
            mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(net.minecraft.network.play.client.C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }

        for(int i = 0; i < 6; ++i) {
            mc.thePlayer.attackTargetEntityWithCurrentItem(entity);
            mc.getNetHandler().addToSendQueue(new C0APacketAnimation());
            mc.getNetHandler().getNetworkManager().sendPacket(new C02PacketUseEntity(entity, net.minecraft.network.play.client.C02PacketUseEntity.Action.ATTACK));
            mc.thePlayer.attackTargetEntityWithCurrentItem(entity);
        }

        if(wasSneaking) {
            mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }

        if(wasBlocking) {
            mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(currentItem));
        }

        mc.thePlayer.setSneaking(wasSneaking);
        if(wasBlocking) {
            mc.thePlayer.setItemInUse(currentItem, 100);
        }

    }

    public static boolean check(Entity entity) {
        if (entity == null) {
            return false;
        } else if(entity instanceof EntityPlayerSP){
            return false;
        } else if (!entity.isEntityAlive()) {
            return false;
        } else if (mc.thePlayer.getDistanceToEntity(entity) > Doragon.settingsManager.getSettingByName("TestRange").getValDouble()) {
            return false;
        } else if (Teams.isenabled() && entity instanceof EntityPlayer && Teams.isinTeam((EntityLivingBase) entity)) {
            return false;
        } else if (Doragon.settingsManager.getSettingByName("TestIgnoreInvisibles").getValBoolean() && entity.isInvisible()) {
            return false;
        }else if(!entity.getDisplayName().getUnformattedText().startsWith("§")){
         return false;
        }else if (entity instanceof EntityPlayer && FriendUtil.isAFriend(entity.getName())) {
            return false;
        } else if (entity instanceof IAnimals) {
            if (!(entity instanceof EntityHorse) && !(entity instanceof EntityPig)) {
                return true;
            } else {
                EntityHorse horse = (EntityHorse) entity;
                EntityPig pig = (EntityPig)entity;
                if (horse.riddenByEntity == mc.thePlayer || pig.riddenByEntity == mc.thePlayer) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        return true;
    }

    public static void attack(Entity entity){
        ItemStack currentItem = mc.thePlayer.inventory.getCurrentItem();
        boolean autosword = Doragon.settingsManager.getSettingByName("TestAutosword").getValBoolean();
        boolean wasSneaking = mc.thePlayer.isSneaking();
        boolean wasBlocking = currentItem != null && currentItem.getItem() instanceof ItemSword && currentItem.getItem().getItemUseAction(currentItem) == EnumAction.BLOCK && mc.thePlayer.isBlocking();
        if(autosword){
            mc.thePlayer.inventory.currentItem = KillauraHelper.getBeastWeapon(entity);
        }
        if(wasSneaking){
            mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }
        if(wasBlocking){
            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }
        if(Doragon.settingsManager.getSettingByName("TestCrack").getValBoolean()){
            for(double i = 0; i <= Doragon.settingsManager.getSettingByName("TestCrackAmount").getValDouble(); i++){
                mc.effectRenderer.func_178926_a(entity, EnumParticleTypes.CRIT);
            }
        }
        mc.thePlayer.swingItem();
        try{
            mc.playerController.attackEntity(mc.thePlayer,entity);
        }catch (Exception e){
            e.printStackTrace();
        }
        if(wasSneaking){
            mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }
        if(wasBlocking){
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(currentItem));
            mc.thePlayer.setItemInUse(currentItem, currentItem.getMaxItemUseDuration());
        }
        mc.thePlayer.setSneaking(wasSneaking);
    }

    public static float[] rotations(EntityPlayer player, Entity target){
        double posX = target.posX - player.posX;
        double posY = target.posX - player.posX;
        double posZ = target.posX - player.posX;
        float yaw = (float)(Math.atan2(posZ,posX) * 180F / 3.141592653589793) - 90F;
        float pitch = (float)(-(Math.atan2(posY, MathHelper.sqrt_double(posX * posX + posZ * posZ)) * 180 / 3.141592653589793));
        return new float[]{yaw,pitch};
    }

}