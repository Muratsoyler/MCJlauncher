package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Filer.Filer;

public class ModuleFile {

    private static Filer ModuleList = new Filer("Modules", "Doragon");

    public ModuleFile() {
        try {
            loadModules();
        } catch (Exception e) {
        }
    }

    public static void saveModules() {
        try {
            ModuleList.clear();
            for (Module module : Doragon.moduleManager.modules) {
                String line = (module.getName() + ":" + String.valueOf(module.getState()));
                ModuleList.write(line);
            }
        } catch (Exception e) {
        }
    }

    public static void loadModules() {
        try {
            for (String s : ModuleList.read()) {
                for (Module module : Doragon.moduleManager.modules) {
                    String name = s.split(":")[0];
                    boolean toggled = Boolean.parseBoolean(s.split(":")[1]);
                    if (module.getName().equalsIgnoreCase(name)) {
                        module.setToggled(toggled);
                        module.setSuffix("");
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
