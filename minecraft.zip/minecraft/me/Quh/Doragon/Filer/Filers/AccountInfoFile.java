/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Filer.Filer;
import me.Quh.Doragon.GUI.HWID;

/**
 *
 * @author admin
 */
public class AccountInfoFile {

    private static Filer accountInfoFile = new Filer("AccountInfo", "Doragon");

    public AccountInfoFile() {
        try {
            loadAccountInfo();
        } catch (Exception e) {
        }
    }

    public static void saveAccount(String username, String password) {
        try {
            accountInfoFile.clear();
            accountInfoFile.write(username + ":" + password);
        } catch (Exception e) {
        }
    }

    public static void loadAccountInfo() {
        try {
            for (String s : accountInfoFile.read()) {
                HWID.savedAccountUsername = s.split(":")[0];
                HWID.savedAccountPassword = s.split(":")[1];
            }
        } catch (Exception e) {
        }
    }

}
