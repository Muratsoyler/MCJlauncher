package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Filer.Filer;

public class SettingsComboBoxFile {

    private static Filer ComboSetting = new Filer("ComboBox", "Doragon");

    public SettingsComboBoxFile() {
        try {
            loadState();
        } catch (Exception e) {
        }
    }

    public static void saveState() {
        try {
            ComboSetting.clear();
            for (Setting setting : Doragon.settingsManager.getSettings()) {
                String line = (setting.getName() + ":" + String.valueOf(setting.getValString()));
                ComboSetting.write(line);
            }
        } catch (Exception e) {
        }
    }

    public static void loadState() {
        try {
            for (String s : ComboSetting.read()) {
                for (Setting setting : Doragon.settingsManager.getSettings()) {
                    String name = s.split(":")[0];
                    String Setting = String.valueOf(s.split(":")[1]);
                    if (setting.getName().equalsIgnoreCase(name)) {
                        setting.setValString(Setting);
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
