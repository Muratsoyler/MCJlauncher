package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Filer.Filer;

public class SettingsSliderFile {

    private static Filer SliderValue = new Filer("Slider", "Doragon");

    public SettingsSliderFile() {
        try {
            loadState();
        } catch (Exception e) {
        }
    }

    public static void saveState() {
        try {
            SliderValue.clear();
            for (Setting setting : Doragon.settingsManager.getSettings()) {
                String line = (setting.getName() + ":" + String.valueOf(setting.getValDouble()));
                SliderValue.write(line);
            }
        } catch (Exception e) {
        }
    }

    public static void loadState() {
        try {
            for (String s : SliderValue.read()) {
                for (Setting setting : Doragon.settingsManager.getSettings()) {
                    String name = s.split(":")[0];
                    double value = Double.parseDouble(s.split(":")[1]);
                    if (setting.getName().equalsIgnoreCase(name)) {
                        setting.setValDouble(value);
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
