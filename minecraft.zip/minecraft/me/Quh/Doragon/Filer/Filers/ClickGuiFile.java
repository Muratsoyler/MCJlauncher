package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.GUI.ClickGUI.ClickGUI;
import me.Quh.Doragon.GUI.ClickGUI.Panel;
import me.Quh.Doragon.Filer.Filer;

public class ClickGuiFile {

    private static Filer clickGuiCoord = new Filer("ClickGui", "Doragon");

    public ClickGuiFile() {
        try {
            loadClickGui();
        } catch (Exception e) {
        }
    }

    public static void saveClickGui() {
        try {
            clickGuiCoord.clear();
            for (Panel panel : ClickGUI.rpanels) {
                clickGuiCoord.write(panel.title + ":" + panel.x + ":" + panel.y + ":" + panel.extended);
            }
        } catch (Exception e) {
        }
    }

    public static void loadClickGui() {
        try {
            for (String s : clickGuiCoord.read()) {
                String panelName = s.split(":")[0];
                float panelCoordX = Float.parseFloat(s.split(":")[1]);
                float panelCoordY = Float.parseFloat(s.split(":")[2]);
                boolean extended = Boolean.parseBoolean(s.split(":")[3]);
                for (Panel panel : ClickGUI.rpanels) {
                    if (panel.title.equalsIgnoreCase(panelName)) {
                        panel.x = (int) panelCoordX;
                        panel.y = (int) panelCoordY;
                        panel.extended = extended;
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
