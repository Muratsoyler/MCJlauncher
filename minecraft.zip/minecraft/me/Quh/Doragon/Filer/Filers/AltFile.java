package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Filer.Filer;
import me.Quh.Doragon.GUI.AltManager.Alt;
import me.Quh.Doragon.GUI.ClickGUI.ClickGUI;
import me.Quh.Doragon.GUI.ClickGUI.Panel;

public class AltFile {

    private static Filer altFile = new Filer("Alt", "Doragon");

    public AltFile() {
        try {
            loadAlts();
        } catch (Exception e) {
        }
    }

    public static void saveAlts() {
        try {
            altFile.clear();
            for(Alt alt : Doragon.altManager.getAlts()){
                altFile.write(alt.getUsername() + ":" + alt.getPassword() + ":" + alt.getMask());
            }
        } catch (Exception e) {
        }
    }

    public static void loadAlts() {
        try {
            for (String s : altFile.read()) {
                String username = s.split(":")[0];
                String pw = s.split(":")[1];
                Doragon.altManager.getAlts().add(new Alt(username,pw,""));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
