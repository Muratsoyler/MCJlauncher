package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.GUI.Setting.Setting;
import me.Quh.Doragon.Filer.Filer;

public class SettingsButtonFile {

    private static Filer ButtonList = new Filer("Buttons", "Doragon");

    public SettingsButtonFile() {
        try {
            loadState();
        } catch (Exception e) {
        }
    }

    public static void saveState() {
        try {
            ButtonList.clear();
            for (Setting setting : Doragon.settingsManager.getSettings()) {
                String line = (setting.getName() + ":" + String.valueOf(setting.getValBoolean()));
                ButtonList.write(line);
            }
        } catch (Exception e) {
        }
    }

    public static void loadState() {
        try {
            for (String s : ButtonList.read()) {
                for (Setting setting : Doragon.settingsManager.getSettings()) {
                    String name = s.split(":")[0];
                    boolean toggled = Boolean.parseBoolean(s.split(":")[1]);
                    if (setting.getName().equalsIgnoreCase(name)) {
                        setting.setValBoolean(toggled);
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
