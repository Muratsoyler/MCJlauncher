package me.Quh.Doragon.Filer.Filers;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;
import me.Quh.Doragon.Filer.Filer;

public class KeybindFile {

    private static Filer bindList = new Filer("Keybinds", "Doragon");

    public KeybindFile() {
        try {
            loadKeybinds();
        } catch (Exception e) {
        }
    }

    public static void saveKeybinds() {
        try {
            bindList.clear();
            for (Module module : Doragon.moduleManager.modules) {
                String line = (module.getName() + ":" + String.valueOf(module.getKeyBind()));
                bindList.write(line);
            }
        } catch (Exception e) {
        }
    }

    public static void loadKeybinds() {
        try {
            for (String s : bindList.read()) {
                for (Module module : Doragon.moduleManager.modules) {
                    String name = s.split(":")[0];
                    int key = Integer.parseInt(s.split(":")[1]);
                    if (module.getName().equalsIgnoreCase(name)) {
                        module.setKeyBind(key);
                    }
                }
            }
        } catch (Exception e) {
        }
    }
}
