package me.Quh.Doragon.Friend;

import java.util.ArrayList;

public class FriendUtil {

    private static ArrayList<Friend> friends;

    public static void setup() {
        friends = new ArrayList();
    }

    public static void addWithoutAlias(String name) {
        friends.add(new Friend(name, name));
    }

    public static void removeFriend(String name) {
        if (!friends.isEmpty() &&
                isAFriend(name)) {
            friends.remove(getFriend(name));
        }
    }

    public static Friend getFriend(String name) {
        Friend friend = null;
        if (!friends.isEmpty()) {
            for (Friend friend2 : friends) {
                if (friend2.getName().equals(name)) {
                    friend = friend2;
                }
            }
        }
        return friend;
    }

    public static boolean isAFriend(String name) {
        if (!friends.isEmpty()) {
            for (Friend friend : friends) {
                if (friend.getName().equals(name)) {
                    return true;
                }
            }
        }
        return false;
    }

}
