package me.Quh.Doragon.Event.Events;

import me.Quh.Doragon.Event.Event;
import net.minecraft.block.Block;

public class EventCollideCheck extends Event{

    public boolean collide;
    public Block block;

    public EventCollideCheck(boolean collide, Block block){
        this.collide = collide;
        this.block = block;
    }

    public void setCollide(boolean collide) {
        this.collide = collide;
    }

    public boolean isCollide() {
        return collide;
    }
}
