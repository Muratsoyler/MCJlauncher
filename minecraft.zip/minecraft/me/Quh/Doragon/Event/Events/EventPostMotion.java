package me.Quh.Doragon.Event.Events;

import me.Quh.Doragon.Event.Event;

public class EventPostMotion extends Event {

	public float yaw, pitch;
	public boolean onGround;
	public double posY;

	public EventPostMotion(double posY, float yaw, float pitch, boolean onGround) {
		this.yaw = yaw;
		this.pitch = pitch;
		this.posY = posY;
		this.onGround = onGround;
	}

	public float getPitch() {
		return this.pitch;
	}

	public float getYaw() {
		return this.yaw;
	}

	public void setPitch(float pitch) {
		this.pitch = pitch;
	}

	public void setYaw(float yaw) {
		this.yaw = yaw;
	}

	public void setOnGround(boolean onGround) {
		this.onGround = onGround;
	}

	public void setPosY(double posY) {
		this.posY = posY;
	}

	public boolean isOnGround() {
		return onGround;
	}

	public double getPosY() {
		return posY;
	}

}
