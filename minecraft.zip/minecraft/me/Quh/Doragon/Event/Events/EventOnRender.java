package me.Quh.Doragon.Event.Events;

import me.Quh.Doragon.Event.Event;

public class EventOnRender extends Event {

    public EventOnRender(float partialticks) {
        this.partialticks = partialticks;
    }

    public float partialticks;

    public boolean Cancellable;

    public boolean isCancellable() {
        return Cancellable;
    }

    public void setCancellable(boolean cancellable) {
        Cancellable = cancellable;
    }

}
