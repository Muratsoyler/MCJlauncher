package me.Quh.Doragon.Event.Events;

import me.Quh.Doragon.Event.Event;
import net.minecraft.network.*;

public class EventSendPacket extends Event {
	
	private Packet packet;

	public EventSendPacket(final Packet packet) {
        	this.packet = packet;
    	}

	public Packet getPacket() {
		return this.packet;
	}

	public void setPacket(final Packet packet) {
		this.packet = packet;
	}
}