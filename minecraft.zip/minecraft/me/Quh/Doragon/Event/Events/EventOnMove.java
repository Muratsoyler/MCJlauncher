package me.Quh.Doragon.Event.Events;

import me.Quh.Doragon.Event.Event;

public class EventOnMove extends Event {
	
	public static double x;
	public static double y;
	public static double z;
	
	public EventOnMove(double x, double y, double z) {
		EventOnMove.x = x;
		EventOnMove.y = y;
		EventOnMove.z = z;
		
	}

	public static double getX() {
		return x;
	}

	public static void setX(double x) {
		EventOnMove.x = x;
	}

	public static double getY() {
		return y;
	}

	public static void setY(double y) {
		EventOnMove.y = y;
	}

	public static double getZ() {
		return z;
	}

	public static void setZ(double z) {
		EventOnMove.z = z;
	}
	
}
