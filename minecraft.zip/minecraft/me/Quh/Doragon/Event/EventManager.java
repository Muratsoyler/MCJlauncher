package me.Quh.Doragon.Event;

import me.Quh.Doragon.Doragon;
import me.Quh.Doragon.Module.Module;

public class EventManager {
	
	public static void register(Event event) {
		for(Module module : Doragon.moduleManager.getModules()) {
			if(module.isEnabled()) {
				module.onEvent(event);
			}
		}
	}

}
