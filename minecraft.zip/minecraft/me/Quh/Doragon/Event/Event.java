package me.Quh.Doragon.Event;

public abstract class Event {
	
	private boolean cancelled;
	
	public void call() {
		EventManager.register(this);
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}

}
