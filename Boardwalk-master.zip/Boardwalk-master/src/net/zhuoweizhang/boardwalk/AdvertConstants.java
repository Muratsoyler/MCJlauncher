package net.zhuoweizhang.boardwalk;

public class AdvertConstants {
	public static final String DEVICE_ID_TESTER = "DF28838C26BDFAE7EB063BFEB7A241D3";
	public static final String DEVICE_ID_TESTER_L = "8B9CCC92576D636B40F47DCB2931EA76";
	public static final String DEVICE_ID_TESTER_NEW = "C0ABF0B025E43414E6EF63D720DCEFDE";
}
