package net.zhuoweizhang.boardwalk.model;

import java.util.Map;

public class MinecraftAssets {
	public Map<String, MinecraftAssetInfo> objects;
}
