package net.zhuoweizhang.boardwalk.model;

public class DependentLibrary {
	public String name;
}
