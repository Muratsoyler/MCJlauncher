package net.zhuoweizhang.boardwalk.model;

public class MinecraftAssetInfo {
	public String hash;
	public int size;
}
