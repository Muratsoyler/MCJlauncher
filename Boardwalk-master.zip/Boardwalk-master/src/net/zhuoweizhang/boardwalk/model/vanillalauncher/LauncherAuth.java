package net.zhuoweizhang.boardwalk.model.vanillalauncher;

public class LauncherAuth {
	public String username;
	public String accessToken;
	public String userId;
	public String uuid;
	public String displayName;
}
