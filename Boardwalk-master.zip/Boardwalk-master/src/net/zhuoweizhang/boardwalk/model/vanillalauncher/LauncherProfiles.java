package net.zhuoweizhang.boardwalk.model.vanillalauncher;

import java.util.*;

public class LauncherProfiles {
	//public LauncherProfile[] profiles;
	public String selectedProfile;
	public UUID clientToken;
	public Map<String, LauncherAuth> authenticationDatabase;
	public String selectedUser;
}
