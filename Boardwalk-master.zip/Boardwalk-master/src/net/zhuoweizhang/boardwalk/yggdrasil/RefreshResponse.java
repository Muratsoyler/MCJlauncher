package net.zhuoweizhang.boardwalk.yggdrasil;

import java.util.UUID;

public class RefreshResponse {
	public String accessToken;
	public UUID clientToken;
	public Profile selectedProfile;
}
