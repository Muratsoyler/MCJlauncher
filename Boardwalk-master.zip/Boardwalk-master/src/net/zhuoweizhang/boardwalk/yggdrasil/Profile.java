package net.zhuoweizhang.boardwalk.yggdrasil;

public class Profile {
	public String id;
	public String name;
	public boolean legacy;
}
