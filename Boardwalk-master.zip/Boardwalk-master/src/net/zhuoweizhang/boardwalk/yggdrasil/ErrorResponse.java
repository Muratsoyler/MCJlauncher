package net.zhuoweizhang.boardwalk.yggdrasil;

public class ErrorResponse {
	public String error;
	public String errorMessage;
	public String cause;
}
