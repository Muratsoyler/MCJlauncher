package paulscode.sound.libraries;
import paulscode.sound.*;
public class LibraryLWJGLOpenAL extends Library {
	public LibraryLWJGLOpenAL() throws SoundSystemException {
	}
}
